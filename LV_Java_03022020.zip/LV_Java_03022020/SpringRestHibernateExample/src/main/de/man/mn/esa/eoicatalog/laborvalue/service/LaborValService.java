package de.man.mn.esa.eoicatalog.laborvalue.service;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import de.man.mn.esa.eoicatalog.laborvalue.helper.ILaborValHelper;
import de.man.mn.esa.eoicatalog.laborvalue.helper.LaborValHelper;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchChildVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchMostValidWPAttributesVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.RangeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

@Service
public class LaborValService implements ILaborValService {

	private static final Logger LOGGER = Logger
			.getLogger(LaborValService.class);
	
	@Autowired
	private ILaborValHelper laborValHelper;

	//private String hostMailServer;

	//public String getHostMailServer() {
	//	return hostMailServer;
	//}

	//public void setHostMailServer(String hostMailServer) {
	//	this.hostMailServer = hostMailServer;
	//}

	public ILaborValHelper getLaborValHelper() {
		return laborValHelper;
	}

	public void setLaborValHelper(ILaborValHelper laborValHelper) {
		this.laborValHelper = laborValHelper;
	}

	public List fetchRangeList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		return laborValHelper.fetchRangeList(rangeVO, userVO);
	}

	public String fetchUnit(UserVO userVO) throws EOIException {
		return laborValHelper.fetchUnit(userVO);
	}

	public WorkProcessVO fetchValidObjCode(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		return laborValHelper.fetchValidObjCode(userVO, workProcessVO, nodeVO);
	}

	public boolean isValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException {
		return laborValHelper.isValidObjCode(userVO, workProcessVO, nodeVO);
	}

	public boolean isValidWPAttributeCombination(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		return laborValHelper.isValidWPAttributeCombination(userVO,
				workProcessVO, nodeVO);
	}

	public List fetchVariantList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		return laborValHelper.fetchVariantList(rangeVO, userVO);
	}

	public List fetchRootNodes(UserVO userVO) throws EOIException {
		return laborValHelper.fetchRootNodes(userVO);
	}

	public String fetchLanguage(String spras) throws EOIException {
		return laborValHelper.fetchLanguage(spras);
	}

	public List fetchChildNodes(FetchChildVO fetchChildVO) throws EOIException {
		return laborValHelper.fetchChildNodes(fetchChildVO);
		/*
		 * userVO.setModel("TGA"); workProcessVO.setOBJCD1("031");
		 * workProcessVO.setOBJCD2("A"); workProcessVO.setOBJCD3("020");
		 * workProcessVO.setACTIVITY("60C"); workProcessVO.setVERSION("RN");
		 * workProcessVO.setLOCATION("SA"); workProcessVO.setINSTALL_CON("00");
		 * workProcessVO.setJOBTYPE("0"); List workProcessVOList =
		 * fetchIncludedWPList(userVO, workProcessVO, nodeVO); for(int
		 * i=0;i<workProcessVOList.size();i++){ WorkProcessVO valueWorkProcessVO
		 * = (WorkProcessVO)workProcessVOList.get(i);
		 * System.out.println("VALUE : " + valueWorkProcessVO.toSting()); }
		 */
		/*
		 * workProcessVO.setOBJCD1("320"); workProcessVO.setOBJCD2("A");
		 * workProcessVO.setOBJCD3("010"); workProcessVO.setACTIVITY("39A");
		 * workProcessVO.setVERSION("Y7"); workProcessVO.setLOCATION("00");
		 * workProcessVO.setINSTALL_CON("00"); workProcessVO.setJOBTYPE("0");
		 * HashMap hMap = fetchNotIncludedWPWithDetailsList(userVO,
		 * workProcessVO, nodeVO); Iterator iterator =
		 * hMap.entrySet().iterator(); while(iterator.hasNext()){ Map.Entry me =
		 * (Map.Entry)iterator.next(); WorkProcessVO keyWorkProcessVO =
		 * (WorkProcessVO)me.getKey(); List workProcessVOList =
		 * (List)me.getValue(); System.out.println("KEY : " +
		 * keyWorkProcessVO.toSting()); for(int
		 * i=0;i<workProcessVOList.size();i++){ WorkProcessVO valueWorkProcessVO
		 * = (WorkProcessVO)workProcessVOList.get(i);
		 * System.out.println("VALUE : " + valueWorkProcessVO.toSting()); }
		 * System.out.println("----------------------------"); }
		 * 
		 * return returnList;
		 */
	}

	public PaginationVO fetchWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		return laborValHelper.fetchWPList(fetchMostValidWPAttributesVO);
	}

	public List fetchIncludedWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		return laborValHelper
				.fetchIncludedWPList(fetchMostValidWPAttributesVO);
	}

	public PaginationVO fetchWPSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException {
		LOGGER.info("Received message to fetch work processes at Service Layer");
		return laborValHelper.fetchWPSearchList(searchText, objectCode, userVO,
				paginationVO);
	}

	public PaginationVO fetchObjectSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValHelper.fetchObjectSearchList(searchText, objectCode,
				userVO, paginationVO);
	}

	public PaginationVO fetchActivitySearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValHelper.fetchActivitySearchList(searchText, activityCode,
				userVO, paginationVO);
	}

	public PaginationVO fetchVersionSearchList(String searchText,
			String versionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValHelper.fetchVersionSearchList(searchText, versionCode,
				userVO, paginationVO);
	}

	public PaginationVO fetchLocationSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValHelper.fetchLocationSearchList(searchText, locationCode,
				userVO, paginationVO);
	}

	public PaginationVO fetchConditionSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValHelper.fetchConditionSearchList(searchText,
				conditionCode, userVO, paginationVO);
	}

	@SuppressWarnings("rawtypes")
	public List<WorkProcessVO> fetchNotIncludedWPWithDetailsList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		return laborValHelper.fetchNotIncludedWPWithDetailsList(fetchMostValidWPAttributesVO);
	}

	public boolean isWPHavingNotIncludedWPList(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		return laborValHelper.isWPHavingNotIncludedWPList(userVO,
				workProcessVO, nodeVO);
	}

	public boolean isValidSearch(UserVO userVO, String text, Integer textId)
			throws EOIException {
		// TODO Auto-generated method stub
		return laborValHelper.isValidSearch(userVO, text, textId);
	}

	public String fetchCodeText(UserVO userVO, String text, 
			Integer textId) throws EOIException {
		return laborValHelper.fetchCodeText(userVO, text, textId);
	}
	
	public WorkProcessVO fetchMostValidWPAttributes(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		return laborValHelper.fetchMostValidWPAttributes(fetchMostValidWPAttributesVO);
	}
}
