package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

public class FetchSearchVO extends BaseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new node vo.
	 */
	public FetchSearchVO() {

	}
	/**
	 * 
	 */
	private UserVO userVO;
	/**
	 * 
	 */
	private PaginationVO paginationVO;
	/**
	 * 
	 */
	private String searchText;
	/**
	 * 
	 */
	private String code;
	
	public UserVO getUserVO() {
		return userVO;
	}
	public PaginationVO getPaginationVO() {
		return paginationVO;
	}
	public void setPaginationVO(PaginationVO paginationVO) {
		this.paginationVO = paginationVO;
	}
	public String getSearchText() {
		return searchText;
	}
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}
	
}
