package de.man.mn.esa.eoicatalog.laborvalue.service;

import java.util.HashMap;
import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.vo.FetchChildVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchMostValidWPAttributesVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.RangeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

public interface ILaborValService {
	WorkProcessVO fetchValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException;

	boolean isValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException;

	boolean isValidWPAttributeCombination(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException;

	List fetchRangeList(RangeVO rangeVO, UserVO userVO) throws EOIException;

	String fetchLanguage(String spras) throws EOIException;

	String fetchUnit(UserVO userVO) throws EOIException;

	List fetchVariantList(RangeVO rangeVO, UserVO userVO) throws EOIException;

	List fetchRootNodes(UserVO userVO) throws EOIException;

	List fetchChildNodes(FetchChildVO fetchChildVO) throws EOIException;

	PaginationVO fetchWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException;

	List fetchIncludedWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException;

	PaginationVO fetchWPSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException;

	PaginationVO fetchObjectSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException;

	PaginationVO fetchActivitySearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException;

	PaginationVO fetchVersionSearchList(String searchText, String versionCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException;

	PaginationVO fetchLocationSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException;

	PaginationVO fetchConditionSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException;

	List<WorkProcessVO> fetchNotIncludedWPWithDetailsList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException;

	boolean isWPHavingNotIncludedWPList(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException;
	
	boolean isValidSearch(UserVO userVO,String text,Integer textId) throws EOIException;

	String fetchCodeText(UserVO userVO, String text, 
			Integer textId) throws EOIException;
	
	public WorkProcessVO fetchMostValidWPAttributes(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException ;
}
