/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRACTT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBROBJT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRVAL;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRVRST;
import de.man.mn.esa.eoicatalog.share.common.vo.ActivityVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchChildVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchMostValidWPAttributesVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.ObjectCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.RangeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.VersionLocationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO;
import de.man.mn.esa.eoicatalog.share.constants.AppConstants;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;
import de.man.mn.esa.eoicatalog.ui.util.UIUtil;

/**
 * The Class LaborValHelper.
 * 
 * Author: Yuvraj Patil
 */
@Repository
public class LaborValHelper implements ILaborValHelper {

	/** The hibernate template. */
	@Autowired
	private HibernateTemplate hibernateTemplate;

	/** The error messages. */
	@Autowired
	private ErrorMessages errorMessages;

	/** The error msg. */
	private String errorMsg = "";

	/** The error code. */
	private String errorCode = "";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(LaborValHelper.class);

	// EOIGWTI18NConstants cONSTANTS = EOIGWTI18NConstants.CONSTANTS;
	/**
	 * Sets the session factory.
	 * 
	 * @param sessionFactory
	 *            the new session factory
	 */
	/*public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}*/

	/**
	 * Sets the error messages.
	 * 
	 * @param errorMessages
	 *            the new error messages
	 */
	/*public void setErrorMessages(ErrorMessages errorMessages) {
		this.errorMessages = errorMessages;
	}*/

	/**
	 * Fetch valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the work process vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public WorkProcessVO fetchValidObjCode(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		workProcessVO.setoBJCD1(objCD1);
		workProcessVO.setoBJCD2(objCD2);
		workProcessVO.setoBJCD3(objCD3);
		try {
			while (nodeVO.getCode().length() > 0) {
				if (isValidObjCode(userVO, workProcessVO, nodeVO)) {
					String nodeCode = nodeVO.getCode();
					if (nodeCode.length() >= 3) {
						objCD1 = nodeCode.substring(0, 3);
					} else {
						objCD1 = nodeCode.substring(0, nodeCode.length());
					}

					if (nodeCode.length() >= 4) {
						objCD2 = nodeCode.substring(3, 4);
					}

					if (nodeCode.length() >= 5) {
						objCD3 = nodeCode.substring(4, nodeCode.length());
					}
					workProcessVO.setoBJCD1(objCD1);
					workProcessVO.setoBJCD2(objCD2);
					workProcessVO.setoBJCD3(objCD3);
					return workProcessVO;
				} else {
					nodeVO.setCode(nodeVO.getCode().substring(0,
							(nodeVO.getCode().length() - 1)));
				}
			}
		} catch (Exception e) {
			errorCode = "e001";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return workProcessVO;
	}

	/**
	 * Checks if is valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid obj code
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException {
		List result = null;
		try {
			String code = nodeVO.getCode();
			result = hibernateTemplate
					.find("SELECT LABVAL FROM WSGLBRVAL WHERE PRCSTAT = 'A' AND RANGE like '"
							+ userVO.getModel()
							+ "' "
							+ "AND LBR_VARIANT in ('"
							+ userVO.getVariant()
							+ "','*') AND ACTIVITY NOT IN ('0','00','000') AND LABVAL like '"
							+ code + "%'");

			if (result.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			errorCode = "e002";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return false;
	}

	/**
	 * Checks if is valid wp attribute combination.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid wp attribute combination
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidWPAttributeCombination(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		List result = null;

		try {
			result = hibernateTemplate
					.find("SELECT LABVAL FROM WSGLBRVAL WHERE PRCSTAT = 'A' AND RANGE like '"
							+ userVO.getModel()
							+ "' "
							+ "AND LBR_VARIANT in ('"
							+ userVO.getVariant()
							+ "','*') AND ACTIVITY NOT IN ('0','00','000') AND LABVAL like '"
							+ nodeVO.getCode() + "%'");

			if (result.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			errorCode = "e003";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return false;
	}

	/**
	 * Fetch root nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchRootNodes(UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			result = hibernateTemplate
					.find("FROM WSGLBROBJT where PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = '"
							+ userVO.getLanguage()
							+ "' "
							+ "AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,1)) from WSGLBRVAL where "
							+ "PRCSTAT = 'A' AND RANGE = '"
							+ userVO.getModel()
							+ "' "
							+ "AND LBR_VARIANT in ('"
							+ userVO.getVariant()
							+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY OBJCD1");

			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				node.setHasChildren(true);
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e004";
			e.printStackTrace();
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;

	}

	/**
	 * Fetch range list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchRangeList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		List result = null;
		List<RangeVO> returnRangeList = new ArrayList<RangeVO>();
		try {
			String qry = formQryOfRange(rangeVO, userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				RangeVO range = new RangeVO();
				range.setModel(result.get(i) + "");
				returnRangeList.add(range);
			}
		} catch (Exception e) {
			errorCode = "e005";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return returnRangeList;
	}

	/**
	 * Fetch unit.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	public String fetchUnit(UserVO userVO) throws EOIException {
		List result = null;
		String UOMT = "";
		try {
			String qry = formQryOfUnit(userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				UOMT = result.get(i) + "";
			}
			userVO.setUnit(UOMT);
		} catch (Exception e) {
			errorCode = "e006";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return UOMT;
	}

	/**
	 * Fetch language.
	 * 
	 * @param spras
	 *            the spras
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	public String fetchLanguage(String spras) throws EOIException {
		List result = null;
		String lang = "";
		try {
			String qry = formQryForLang(spras);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				lang = result.get(i) + "";
			}
		} catch (Exception e) {
			errorCode = "e007";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error(
					"Message: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return lang;
	}

	/**
	 * Fetch variant list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchVariantList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		List result = null;
		List<RangeVO> returnVariantList = new ArrayList<RangeVO>();
		try {
			String qry = formQryOfVariant(rangeVO, userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				RangeVO range = new RangeVO();
				range.setVariant(result.get(i) + "");
				returnVariantList.add(range);
			}
		} catch (Exception e) {
			errorCode = "e008";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return returnVariantList;
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildNodes(FetchChildVO fetchChildVO) throws EOIException {
		List returnNodes = new ArrayList();
		if (fetchChildVO.getNodeVO().getType() == AppConstants.Node.OBJECT) {
			if (fetchChildVO.getNodeVO().getLevel() >= 1 & fetchChildVO.getNodeVO().getLevel() <= 4) {
				List actNodes = fetchChildActivities(fetchChildVO.getWorkProcessVO(),fetchChildVO.getNodeVO(),fetchChildVO.getUserVO());
				returnNodes.addAll(actNodes);
				List objNodes = fetchChildObjects(fetchChildVO.getWorkProcessVO(),fetchChildVO.getNodeVO(),fetchChildVO.getUserVO());
				returnNodes.addAll(objNodes);
			} else if (fetchChildVO.getNodeVO().getLevel() == 5) {
				List actNodes = fetchChildActivities(fetchChildVO.getWorkProcessVO(),fetchChildVO.getNodeVO(),fetchChildVO.getUserVO());
				returnNodes.addAll(actNodes);
			}
		} else if (fetchChildVO.getNodeVO().getType() == AppConstants.Node.ACTIVITY) {
			List versionNodes = fetchChildVersions(fetchChildVO.getWorkProcessVO(),fetchChildVO.getNodeVO(),fetchChildVO.getUserVO());
			returnNodes.addAll(versionNodes);
		}
		return returnNodes;
	}

	/**
	 * Fetch child objects.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	private List fetchChildObjects(WorkProcessVO workProcessVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			String qry = formQryOfChildObjects(workProcessVO, nodeVO, userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(true);
				if (nodeVO.getLevel() == 1) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 2) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 3) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD2());
				} else if (nodeVO.getLevel() == 4) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ UIUtil.formCodeOfNLength(
									((WSGLBROBJT) result.get(i)).getOBJCD2(), 1)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD3());
				}
				node.setLevel(nodeVO.getLevel() + 1);
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e009";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;

	}

	/**
	 * Fetch child activities.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	private List fetchChildActivities(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			String qry = formQryOfChildActivities(workProcessVO, nodeVO, userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ActivityVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 7)
						+ ((WSGLBRACTT) result.get(i)).getACTIVITY());
				node.setLevel(nodeVO.getLevel());
				if (isActivityHavingChildNodes(workProcessVO, node, userVO)) {
					node.setChildNodesHaveBeenFetched(false);
					node.setHasChildren(true);
				} else {
					node.setHasChildren(false);
				}
				node.setName(((WSGLBRACTT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e010";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;
	}

	/**
	 * Test fetching child activities.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public void testFetchingChildActivities(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) throws EOIException {
		String qry1 = formHqlQryOfChildActivities(workProcessVO, nodeVO, userVO);
		String qry2 = "FROM WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
				+ "AND ACTIVITY IN (:activityList) ORDER BY ACTIVITY";
		List list1 = null;
		if (nodeVO.getLevel() == 1) {
			Query query1 = hibernateTemplate.getSessionFactory().openSession()
					.createQuery(qry1);
			query1.setParameter("code", nodeVO.getCode());
			query1.setParameter("model", userVO.getModel());
			query1.setParameter("variant", userVO.getVariant());
			list1 = query1.list();

		} else if (nodeVO.getLevel() == 2) {
			Query query1 = hibernateTemplate.getSessionFactory().openSession()
					.createQuery(qry1);
			query1.setParameter("code", nodeVO.getCode());
			query1.setParameter("model", userVO.getModel());
			query1.setParameter("variant", userVO.getVariant());
			list1 = query1.list();

		} else if (nodeVO.getLevel() == 3) {
			Query query1 = hibernateTemplate.getSessionFactory().openSession()
					.createQuery(qry1);
			query1.setParameter("code", nodeVO.getCode());
			query1.setParameter("model", userVO.getModel());
			query1.setParameter("variant", userVO.getVariant());
			list1 = query1.list();
		} else if (nodeVO.getLevel() == 4) {
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			Query query1 = hibernateTemplate.getSessionFactory().openSession()
					.createQuery(qry1);
			query1.setParameter("code1", workProcessVO.getoBJCD1());
			query1.setParameter("code2", workProcessVO.getoBJCD2());
			query1.setParameter("model", userVO.getModel());
			query1.setParameter("variant", userVO.getVariant());
			list1 = query1.list();
		} else if (nodeVO.getLevel() == 5) {
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
			Query query1 = hibernateTemplate.getSessionFactory().openSession()
					.createQuery(qry1);
			query1.setParameter("code1", workProcessVO.getoBJCD1());
			query1.setParameter("code2", workProcessVO.getoBJCD2());
			query1.setParameter("code3", workProcessVO.getoBJCD3());
			query1.setParameter("model", userVO.getModel());
			query1.setParameter("variant", userVO.getVariant());
			list1 = query1.list();
		}
		Query query2 = hibernateTemplate.getSessionFactory().openSession()
				.createQuery(qry2);
		query2.setParameter("language", userVO.getLanguage());
		query2.setParameterList("activityList", list1);
		List list2 = query2.list();
	}

	/**
	 * Form hql qry of child activities.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formHqlQryOfChildActivities(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) {
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			qry = "SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = :code "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = :model "
					+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000')";
		} else if (nodeVO.getLevel() == 2) {
			qry = "SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = :code "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = :model "
					+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000')";
		} else if (nodeVO.getLevel() == 3) {
			qry = "SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = :code "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = :model "
					+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000')";
		} else if (nodeVO.getLevel() == 4) {
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			qry = "SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = :model "
					+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000')";
		} else if (nodeVO.getLevel() == 5) {
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
			qry = "SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND OBJCD3 = :code3 AND PRCSTAT = 'A' AND RANGE = :model "
					+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000')";
		}
		return qry;
	}

	/**
	 * Fetch child versions.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	private List fetchChildVersions(WorkProcessVO workProcessVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			String qry = formQryOfChildVersions(workProcessVO, nodeVO, userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new VersionLocationVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 10)
						+ (((WSGLBRVRST) result.get(i)).getVERSION()));
				node.setLevel(nodeVO.getLevel());
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(false);
				node.setName(((WSGLBRVRST) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e011";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;
	}

	/**
	 * Checks if is activity having child nodes.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return true, if is activity having child nodes
	 * @throws EOIException
	 *             the eOI exception
	 */
	private boolean isActivityHavingChildNodes(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) throws EOIException {
		List result = fetchChildVersions(workProcessVO, nodeVO, userVO);
		if (result.size() > 0) {
			return true;
		}
		return false;
	}

	/**
	 * Fetch wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		List result = null;
		PaginationVO paginationVO = fetchMostValidWPAttributesVO.getPaginationVO();
		UserVO userVO = fetchMostValidWPAttributesVO.getUserVO();
		WorkProcessVO workProcessVO = fetchMostValidWPAttributesVO.getWorkProcessVO();
		NodeVO nodeVO = fetchMostValidWPAttributesVO.getNodeVO();
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formWPListQry(userVO, workProcessVO, nodeVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formWPListQry(userVO, workProcessVO, nodeVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			} else {
				qry = formWPListQry(userVO, workProcessVO, nodeVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);
		} catch (Exception e) {
			errorCode = "e012";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Fetch included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchIncludedWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		List result = null;
		List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
		WorkProcessVO workProcessVO = fetchMostValidWPAttributesVO.getWorkProcessVO();
		UserVO userVO = fetchMostValidWPAttributesVO.getUserVO();
		NodeVO nodeVO = fetchMostValidWPAttributesVO.getNodeVO();
		try {
			String qry = "";
			qry = formIncludedWPListQry(userVO, workProcessVO, nodeVO);
			result = hibernateTemplate
					.getSessionFactory()
					.openSession()
					.createSQLQuery(qry)
					.setResultTransformer(
							Transformers.aliasToBean(WSGLBRVAL.class)).list();
			populateIncludedWPDataInVO(result, voList);
		} catch (Exception e) {
			errorCode = "e013";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return voList;
	}

	/**
	 * Checks if is wP having not included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is wP having not included wp list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isWPHavingNotIncludedWPList(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		boolean returnVal = false;
		List result = null;
		try {
			String qry = "";
			qry = formNotIncludedWPListQry(userVO, workProcessVO, nodeVO);
			result = hibernateTemplate
					.getSessionFactory()
					.openSession()
					.createSQLQuery(qry)
					.setResultTransformer(
							Transformers.aliasToBean(WSGLBRVAL.class)).list();
			if (result.size() > 0) {
				returnVal = true;
			}
		} catch (Exception e) {
			errorCode = "e014";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return returnVal;
	}

	/**
	 * Fetch not included wp with details list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the hash map
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchNotIncludedWPWithDetailsList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		List result = null;
		List topWPList = new ArrayList<WorkProcessVO>();
		HashMap hMap = new HashMap();
		List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
		WorkProcessVO workProcessVO = fetchMostValidWPAttributesVO.getWorkProcessVO();
		UserVO userVO = fetchMostValidWPAttributesVO.getUserVO();
		NodeVO nodeVO = fetchMostValidWPAttributesVO.getNodeVO();
		try {
			String qry = "";
			qry = formNotIncludedWPListQry(userVO, workProcessVO, nodeVO);
			result = hibernateTemplate
					.getSessionFactory()
					.openSession()
					.createSQLQuery(qry)
					.setResultTransformer(
							Transformers.aliasToBean(WSGLBRVAL.class)).list();
			populateIncludedWPDataInVO(result, voList);
			result = null;
			for (int i = 0; i < voList.size(); i++) {
				WorkProcessVO vo = (WorkProcessVO) voList.get(i);
				qry = formNotIncludedWPDetailsQry(userVO, vo, nodeVO);
				List<WorkProcessVO> voDetailsList = new ArrayList<WorkProcessVO>();
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
				populateNotIncludedWPDetailsDataInVO(result, voDetailsList);
				vo.setnOOFNOTINCLUDEDWP(Integer
						.valueOf(voDetailsList.size()));
				if (voDetailsList.size() == 1) {
					if (((WorkProcessVO) voDetailsList.get(0)).getlBRVALUE()
							.equalsIgnoreCase("****")) {
						vo.setnOOFNOTINCLUDEDWP(Integer.valueOf(2));
					}
				}
				vo.setSubWorkProcessVOs(voDetailsList);
				topWPList.add(vo);
			}
		} catch (Exception e) {
			errorCode = "e015";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return topWPList;
	}
	/**
	 * Fetch wp search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchWPSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchWPSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryToFetchWPSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			} else {
				qry = formQryToFetchWPSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e016";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Fetch object search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchObjectSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchObjSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryToFetchObjSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			} else {
				qry = formQryToFetchObjSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e017";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Fetch activity search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchActivitySearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchActSearchList(searchText, activityCode,
						userVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryToFetchActSearchList(searchText, activityCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			} else {
				qry = formQryToFetchActSearchList(searchText, activityCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e018";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Fetch version search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchVersionSearchList(String searchText,
			String versionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchVerSearchList(searchText, versionCode,
						userVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryToFetchVerSearchList(searchText, versionCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			} else {
				qry = formQryToFetchVerSearchList(searchText, versionCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e019";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Fetch location search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchLocationSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchLocSearchList(searchText, locationCode,
						userVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryToFetchLocSearchList(searchText, locationCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			} else {
				qry = formQryToFetchLocSearchList(searchText, locationCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e020";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Fetch condition search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchConditionSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchConSearchList(searchText, conditionCode,
						userVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryToFetchConSearchList(searchText, conditionCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			} else {
				qry = formQryToFetchConSearchList(searchText, conditionCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRVAL.class))
						.list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e021";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Populate wp data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateWPDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			WorkProcessVO vo = new WorkProcessVO();
			vo.setrANGE(((WSGLBRVAL) result.get(i)).getRANGE());
			vo.setlBRVARIANT(((WSGLBRVAL) result.get(i)).getLBR_VARIANT());
			vo.setoBJCD1(((WSGLBRVAL) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRVAL) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRVAL) result.get(i)).getOBJCD3());
			vo.setaCTIVITY(((WSGLBRVAL) result.get(i)).getACTIVITY());
			vo.setvERSION(((WSGLBRVAL) result.get(i)).getVERSION());
			vo.setlOCATION(((WSGLBRVAL) result.get(i)).getLOCATION());
			vo.setiNSTALLCON(((WSGLBRVAL) result.get(i)).getINSTALL_CON());
			vo.setjOBTYPE(((WSGLBRVAL) result.get(i)).getJOBTYPE());
			vo.setlBRVALUE(((WSGLBRVAL) result.get(i)).getLBR_VALUE());
			vo.setlABVAL(((WSGLBRVAL) result.get(i)).getLABVAL());
			vo.settEXT(((WSGLBRVAL) result.get(i)).getTEXT());
			if (((WSGLBRVAL) result.get(i)).getNO_OF_INCLUDEDWP() != null) {
				vo.setnOOFINCLUDEDWP(Integer.valueOf(((WSGLBRVAL) result.get(i))
						.getNO_OF_INCLUDEDWP().intValue()));
			}
			if (((WSGLBRVAL) result.get(i)).getNO_OF_NOTINCLUDEDWP() != null) {
				vo.setnOOFNOTINCLUDEDWP(Integer.valueOf(((WSGLBRVAL) result
						.get(i)).getNO_OF_NOTINCLUDEDWP().intValue()));
			}

			voList.add(vo);
		}
	}

	/**
	 * Populate included wp data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateIncludedWPDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			WorkProcessVO vo = new WorkProcessVO();
			vo.setlABVAL(((WSGLBRVAL) result.get(i)).getLABVAL());
			vo.setoBJCD1(((WSGLBRVAL) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRVAL) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRVAL) result.get(i)).getOBJCD3());
			vo.setaCTIVITY(((WSGLBRVAL) result.get(i)).getACTIVITY());
			vo.setvERSION(((WSGLBRVAL) result.get(i)).getVERSION());
			vo.setlOCATION(((WSGLBRVAL) result.get(i)).getLOCATION());
			vo.setiNSTALLCON(((WSGLBRVAL) result.get(i)).getINSTALL_CON());
			vo.settEXT(((WSGLBRVAL) result.get(i)).getTEXT());
			voList.add(vo);
		}
	}

	/**
	 * Populate not included wp details data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateNotIncludedWPDetailsDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			WorkProcessVO vo = new WorkProcessVO();
			vo.setlABVAL(((WSGLBRVAL) result.get(i)).getLABVAL());
			vo.setoBJCD1(((WSGLBRVAL) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRVAL) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRVAL) result.get(i)).getOBJCD3());
			vo.setaCTIVITY(((WSGLBRVAL) result.get(i)).getACTIVITY());
			vo.setvERSION(((WSGLBRVAL) result.get(i)).getVERSION());
			vo.setlOCATION(((WSGLBRVAL) result.get(i)).getLOCATION());
			vo.setiNSTALLCON(((WSGLBRVAL) result.get(i)).getINSTALL_CON());
			vo.settEXT(((WSGLBRVAL) result.get(i)).getTEXT());
			vo.setlBRVALUE(((WSGLBRVAL) result.get(i)).getLBR_VALUE());
			voList.add(vo);
		}
	}

	/**
	 * Form qry of range.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfRange(RangeVO rangeVO, UserVO userVO) {
		String qry = "";
		qry = "SELECT DISTINCT RANGE FROM WSGLBRRAN WHERE PRCSTAT = 'A' ORDER BY RANGE";
		return qry;
	}

	/**
	 * Form qry of unit.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfUnit(UserVO userVO) {
		String qry = "";
		qry = "SELECT MSEH3 FROM UOMT WHERE SPRAS = '" + userVO.getLanguage()
				+ "'" + " AND MSEHI = 'AW'";
		return qry;
	}

	/**
	 * Form qry for lang.
	 * 
	 * @param spras
	 *            the spras
	 * @return the string
	 */
	private String formQryForLang(String spras) {
		String qry = "";
		qry = "SELECT SPTXT FROM LANG WHERE SPRAS = '" + spras + "'";
		return qry;
	}

	/**
	 * Form qry of variant.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfVariant(RangeVO rangeVO, UserVO userVO) {
		String qry = "";
		qry = "SELECT DISTINCT(VARIANTE) FROM WSGLBRRAN WHERE PRCSTAT = 'A' AND RANGE LIKE '"
				+ rangeVO.getModel() + "' ORDER BY VARIANTE";
		return qry;
	}

	/**
	 * Form qry to fetch wp search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchWPSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
				+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END "
				+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END || ' ' || L.TEXT || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || C.TEXT AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L, WSGLBRACTT A, WSGLBRVRST V, WSGLBRCONT C  "
				+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
				+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
				+ "AND C.PRCSTAT = 'A'  AND RANGE = '"
				+ userVO.getModel()
				+ "' AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND L.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND A.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND V.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND C.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND UPPER(O1.TEXT || O2.TEXT || O3.TEXT || L.TEXT || A.TEXT || V.TEXT || C.TEXT)  like UPPER('"
				+ searchText
				+ "') "
				+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE '"
				+ objectCode
				+ "' ORDER BY LV.OBJCD1, LV.OBJCD2, LV.OBJCD3) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Form qry to fetch obj search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchObjSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) AS LABVAL, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, "
				+ "O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3 "
				+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ (objectCode.endsWith("%") ? "AND JOBTYPE <> 'H' " : " ")
				+ "AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' "
				+ "AND RANGE = '"
				+ userVO.getModel()
				+ "' AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND UPPER(O1.TEXT || O2.TEXT || O3.TEXT ) like UPPER('"
				+ searchText
				+ "') "
				+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE '"
				+ objectCode
				+ "' ORDER BY LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Form qry to fetch act search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchActSearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.ACTIVITY), "
				+ "A.TEXT AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBRACTT A "
				+ "WHERE LV.ACTIVITY = A.ACTIVITY "
				+ (activityCode.endsWith("%") ? "AND JOBTYPE <> 'H' " : " ")
				+ "AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND A.PRCSTAT = 'A' "
				+ "AND RANGE = '"
				+ userVO.getModel()
				+ "' AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND A.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND UPPER(A.TEXT)  like UPPER('"
				+ searchText
				+ "') "
				+ "AND LV.ACTIVITY LIKE '"
				+ activityCode
				+ "' ORDER BY LV.ACTIVITY) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Form qry to fetch ver search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchVerSearchList(String searchText,
			String versionCode, UserVO userVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.VERSION), "
				+ "V.TEXT AS TEXT " + "FROM WSGLBRVAL LV, WSGLBRVRST V  "
				+ "WHERE LV.VERSION = V.VERSION "
				+ (versionCode.endsWith("%") ? "AND JOBTYPE <> 'H' " : " ")
				+ "AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND V.PRCSTAT = 'A' " + "AND RANGE = '"
				+ userVO.getModel() + "' AND LBR_VARIANT in ('"
				+ userVO.getVariant() + "','*') " + "AND V.SPRAS = '"
				+ userVO.getLanguage() + "' "
				+ "AND UPPER(V.TEXT)  like UPPER('" + searchText + "') "
				+ "AND LV.VERSION LIKE '" + versionCode
				+ "' ORDER BY LV.VERSION) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Form qry to fetch loc search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchLocSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.LOCATION), "
				+ "L.TEXT AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBRLOCT L  "
				+ "WHERE LV.LOCATION = L.LOCATION "
				+ (locationCode.endsWith("%") ? "AND JOBTYPE <> 'H' " : " ")
				+ "AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND L.PRCSTAT = 'A' "
				+ "AND RANGE = '"
				+ userVO.getModel()
				+ "' AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND L.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND UPPER(L.TEXT)  like UPPER('"
				+ searchText
				+ "') "
				+ "AND LV.LOCATION LIKE '"
				+ locationCode
				+ "' ORDER BY LV.LOCATION) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Form qry to fetch con search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchConSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.INSTALL_CON), "
				+ "C.TEXT AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBRCONT C  "
				+ "WHERE LV.INSTALL_CON = C.INSTALL_CON "
				+ (conditionCode.endsWith("%") ? "AND JOBTYPE <> 'H' " : " ")
				+ "AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND C.PRCSTAT = 'A'  "
				+ "AND RANGE = '"
				+ userVO.getModel()
				+ "' AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND C.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND UPPER(C.TEXT)  like UPPER('"
				+ searchText
				+ "') "
				+ "AND LV.INSTALL_CON LIKE '"
				+ conditionCode
				+ "' ORDER BY LV.INSTALL_CON) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Form qry of child objects.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildObjects(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) {
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			qry = "FROM WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND OBJCD1 IN (SELECT DISTINCT(SUBSTR(LABVAL,1,2)) FROM WSGLBRVAL WHERE OBJCD1 like '"
					+ nodeVO.getCode()
					+ "%' "
					+ "AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL) ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 2) {
			qry = "FROM WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND OBJCD1 IN (SELECT DISTINCT(SUBSTR(LABVAL,1,3)) FROM WSGLBRVAL WHERE OBJCD1 like '"
					+ nodeVO.getCode()
					+ "%' "
					+ "AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL) ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 3) {
			qry = "FROM WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD3 IS NULL AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' AND OBJCD2 IN (SELECT DISTINCT(SUBSTR(LABVAL,4,1)) FROM WSGLBRVAL "
					+ "WHERE OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL) ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 4) {
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			qry = "FROM WSGLBROBJT WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND OBJCD1 = '"
					+ workProcessVO.getoBJCD1()
					+ "' AND OBJCD2 = '"
					+ workProcessVO.getoBJCD2()
					+ "'  AND OBJCD3 IN "
					+ "(SELECT DISTINCT(SUBSTR(LABVAL,5,3)) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1()
					+ "' "
					+ "AND OBJCD2 = '"
					+ workProcessVO.getoBJCD2()
					+ "' AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL) ORDER BY OBJCD1, OBJCD2, OBJCD3";
		}
		return qry;
	}

	/**
	 * Form qry of child activities.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildActivities(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) {
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			qry = "FROM WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND ACTIVITY IN (SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY ACTIVITY";
		} else if (nodeVO.getLevel() == 2) {
			qry = "FROM WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY ACTIVITY";
		} else if (nodeVO.getLevel() == 3) {
			qry = "FROM WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY ACTIVITY";
		} else if (nodeVO.getLevel() == 4) {
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			qry = "FROM WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1()
					+ "' "
					+ "AND OBJCD2 = '"
					+ workProcessVO.getoBJCD2()
					+ "' AND OBJCD3 = null AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY ACTIVITY";
		} else if (nodeVO.getLevel() == 5) {
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
			qry = "FROM WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1() + "' " + "AND OBJCD2 = '"
					+ workProcessVO.getoBJCD2() + "' AND OBJCD3 = '"
					+ workProcessVO.getoBJCD3() + "' AND PRCSTAT = 'A' "
					+ "AND RANGE = '" + userVO.getModel()
					+ "' AND LBR_VARIANT in ('" + userVO.getVariant()
					+ "','*') "
					+ "AND ACTIVITY NOT IN ('0','00','000')) ORDER BY ACTIVITY";
		}
		return qry;
	}

	/**
	 * Form qry of child versions.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildVersions(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) {
		String qry = "";
		workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
		workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
		workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
		workProcessVO.setaCTIVITY(nodeVO.getCode().substring(7, 10).trim());
		if (nodeVO.getLevel() == 1) {
			qry = "FROM WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION IN (SELECT DISTINCT(VERSION) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND ACTIVITY = '"
					+ workProcessVO.getaCTIVITY()
					+ "' AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY VERSION";
		} else if (nodeVO.getLevel() == 2) {
			qry = "FROM WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND ACTIVITY = '"
					+ workProcessVO.getaCTIVITY()
					+ "' AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY VERSION";
		} else if (nodeVO.getLevel() == 3) {
			qry = "FROM WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null  AND ACTIVITY = '"
					+ workProcessVO.getaCTIVITY()
					+ "' AND PRCSTAT = 'A' AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY VERSION";
		} else if (nodeVO.getLevel() == 4) {
			qry = "FROM WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1()
					+ "' "
					+ "AND OBJCD2 = '"
					+ workProcessVO.getoBJCD2()
					+ "' AND OBJCD3 = null  AND ACTIVITY = '"
					+ workProcessVO.getaCTIVITY()
					+ "' AND PRCSTAT = 'A' "
					+ "AND RANGE = '"
					+ userVO.getModel()
					+ "' "
					+ "AND LBR_VARIANT in ('"
					+ userVO.getVariant()
					+ "','*') AND ACTIVITY NOT IN ('0','00','000')) ORDER BY VERSION";
		} else if (nodeVO.getLevel() == 5) {
			qry = "FROM WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRVAL WHERE OBJCD1 = '"
					+ workProcessVO.getoBJCD1() + "' " + "AND OBJCD2 = '"
					+ workProcessVO.getoBJCD2() + "' AND OBJCD3 = '"
					+ workProcessVO.getoBJCD3() + "' AND ACTIVITY = '"
					+ workProcessVO.getaCTIVITY() + "' "
					+ "AND PRCSTAT = 'A' AND RANGE = '" + userVO.getModel()
					+ "' AND LBR_VARIANT in ('" + userVO.getVariant()
					+ "','*') "
					+ "AND ACTIVITY NOT IN ('0','00','000')) ORDER BY VERSION";
		}
		return qry;
	}

	/**
	 * Form wp list qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formWPListQry(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
				+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END "
				+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L, WSGLBRACTT A, WSGLBRVRST V, WSGLBRCONT C  "
				+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
				+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
				+ "AND C.PRCSTAT = 'A'  AND RANGE = '"
				+ userVO.getModel()
				+ "' AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND L.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND A.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND V.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND C.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND LABVAL LIKE '"
				+ ((null != workProcessVO.getlABVAL()) ? workProcessVO
						.getlABVAL().trim() : nodeVO.getCode().trim())
				+ "%' ORDER BY LABVAL) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT FETCHEDWPDATA.R_NUM, FETCHEDWPDATA.RANGE, FETCHEDWPDATA.LBR_VARIANT, FETCHEDWPDATA.OBJCD1, FETCHEDWPDATA.OBJCD2, "
					+ "FETCHEDWPDATA.OBJCD3, FETCHEDWPDATA.ACTIVITY, FETCHEDWPDATA.VERSION, FETCHEDWPDATA.LOCATION, FETCHEDWPDATA.INSTALL_CON, FETCHEDWPDATA.JOBTYPE, "
					+ "FETCHEDWPDATA.LBR_VALUE, FETCHEDWPDATA.LABVAL, FETCHEDWPDATA.TEXT, SUM(CASE WHEN TEXT.TXT_TYPE = 1 THEN 1 ELSE 0 END) NO_OF_INCLUDEDWP, "
					+ "SUM(CASE WHEN TEXT.TXT_TYPE = 2 THEN 1 ELSE 0 END) NO_OF_NOTINCLUDEDWP FROM (SELECT * FROM ( "
					+ qry
					+ ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum()
					+ " "
					+ "AND R_NUM <= "
					+ paginationVO.getEndRowNum()
					+ " ) FETCHEDWPDATA LEFT JOIN WSGLBRTEXT TEXT ON FETCHEDWPDATA.RANGE = TEXT.RANGE AND "
					+ "FETCHEDWPDATA.LBR_VARIANT = TEXT.LBR_VARIANT AND FETCHEDWPDATA.OBJCD1 || FETCHEDWPDATA.OBJCD2 || FETCHEDWPDATA.OBJCD3 = "
					+ "TEXT.OBJCD1 || TEXT.OBJCD2 || TEXT.OBJCD3 AND FETCHEDWPDATA.ACTIVITY = TEXT.ACTIVITY AND FETCHEDWPDATA.VERSION = TEXT.VERSION AND "
					+ "FETCHEDWPDATA.LOCATION = TEXT.LOCATION AND FETCHEDWPDATA.INSTALL_CON = TEXT.INSTALL_CON AND FETCHEDWPDATA.JOBTYPE = TEXT.JOBTYPE AND "
					+ "TEXT.PRCSTAT = 'A' AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL OR "
					+ "RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) GROUP BY FETCHEDWPDATA.R_NUM, FETCHEDWPDATA.RANGE,FETCHEDWPDATA.LBR_VARIANT, "
					+ "FETCHEDWPDATA.OBJCD1, FETCHEDWPDATA.OBJCD2, FETCHEDWPDATA.OBJCD3, FETCHEDWPDATA.ACTIVITY, FETCHEDWPDATA.VERSION, FETCHEDWPDATA.LOCATION, "
					+ "FETCHEDWPDATA.INSTALL_CON, FETCHEDWPDATA.JOBTYPE, FETCHEDWPDATA.LBR_VALUE,FETCHEDWPDATA.LABVAL, FETCHEDWPDATA.TEXT ORDER BY FETCHEDWPDATA.R_NUM";
		}

		return qry;
	}

	/**
	 * Form wp list qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formWPListQry1(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO, PaginationVO paginationVO) {
		String qry = "";
		workProcessVO.setoBJCD1("");
		workProcessVO.setoBJCD2("");
		workProcessVO.setoBJCD3("");

		if (null != workProcessVO.getlABVAL()) {
			if (workProcessVO.getlABVAL().length() >= 3) {
				workProcessVO.setoBJCD1(workProcessVO.getlABVAL().substring(0,
						3));
			} else {
				workProcessVO.setoBJCD1(workProcessVO.getlABVAL().substring(0,
						workProcessVO.getlABVAL().length()));
			}

			if (workProcessVO.getlABVAL().length() >= 4) {
				workProcessVO.setoBJCD2(workProcessVO.getlABVAL().substring(3,
						4));
			}

			if (workProcessVO.getlABVAL().length() >= 5) {
				if (workProcessVO.getlABVAL().length() >= 7) {
					workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
							.substring(4, 7));
				} else {
					workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
							.substring(4, workProcessVO.getlABVAL().length()));
				}
			}
		} else {
			if (nodeVO.getCode().length() >= 3) {
				workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3));
			} else {
				workProcessVO.setoBJCD1(nodeVO.getCode().substring(0,
						nodeVO.getCode().length()));
			}

			if (nodeVO.getCode().length() >= 4) {
				workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4));
			}

			if (nodeVO.getCode().length() >= 5) {
				if (nodeVO.getCode().length() >= 7) {
					workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7));
				} else {
					workProcessVO.setoBJCD3(nodeVO.getCode().substring(4,
							nodeVO.getCode().length()));
				}
			}
		}
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
				+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END "
				+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L, WSGLBRACTT A, WSGLBRVRST V, WSGLBRCONT C  "
				+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
				+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
				+ "AND C.PRCSTAT = 'A'  AND RANGE = '"
				+ userVO.getModel()
				+ "' AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND L.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND A.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND V.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND C.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND LABVAL LIKE '"
				+ ((null != workProcessVO.getlABVAL()) ? workProcessVO
						.getlABVAL().trim() : nodeVO.getCode().trim())
				+ "%' "
				+ "AND "
				+ (workProcessVO.getoBJCD1().trim().equals("") ? "LV.OBJCD1 IS NULL "
						: "LV.OBJCD1 = '" + workProcessVO.getoBJCD1().trim()
								+ "' ")
				+ "AND "
				+ (workProcessVO.getoBJCD2().trim().equals("") ? "LV.OBJCD2 IS NULL "
						: "LV.OBJCD2 = '" + workProcessVO.getoBJCD2().trim()
								+ "' ")
				+ "AND "
				+ (workProcessVO.getoBJCD3().trim().equals("") ? "LV.OBJCD3 IS NULL "
						: "LV.OBJCD3 = '" + workProcessVO.getoBJCD3().trim()
								+ "' ") + "ORDER BY LABVAL) DATA ";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT FETCHEDWPDATA.R_NUM, FETCHEDWPDATA.RANGE, FETCHEDWPDATA.LBR_VARIANT, FETCHEDWPDATA.OBJCD1, FETCHEDWPDATA.OBJCD2, "
					+ "FETCHEDWPDATA.OBJCD3, FETCHEDWPDATA.ACTIVITY, FETCHEDWPDATA.VERSION, FETCHEDWPDATA.LOCATION, FETCHEDWPDATA.INSTALL_CON, FETCHEDWPDATA.JOBTYPE, "
					+ "FETCHEDWPDATA.LBR_VALUE, FETCHEDWPDATA.LABVAL, FETCHEDWPDATA.TEXT, SUM(CASE WHEN TEXT.TXT_TYPE = 1 THEN 1 ELSE 0 END) NO_OF_INCLUDEDWP, "
					+ "SUM(CASE WHEN TEXT.TXT_TYPE = 2 THEN 1 ELSE 0 END) NO_OF_NOTINCLUDEDWP FROM (SELECT * FROM ( "
					+ qry
					+ ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum()
					+ " "
					+ "AND R_NUM <= "
					+ paginationVO.getEndRowNum()
					+ " ) FETCHEDWPDATA LEFT JOIN WSGLBRTEXT TEXT ON FETCHEDWPDATA.RANGE = TEXT.RANGE AND "
					+ "FETCHEDWPDATA.LBR_VARIANT = TEXT.LBR_VARIANT AND FETCHEDWPDATA.OBJCD1 || FETCHEDWPDATA.OBJCD2 || FETCHEDWPDATA.OBJCD3 = "
					+ "TEXT.OBJCD1 || TEXT.OBJCD2 || TEXT.OBJCD3 AND FETCHEDWPDATA.ACTIVITY = TEXT.ACTIVITY AND FETCHEDWPDATA.VERSION = TEXT.VERSION AND "
					+ "FETCHEDWPDATA.LOCATION = TEXT.LOCATION AND FETCHEDWPDATA.INSTALL_CON = TEXT.INSTALL_CON AND FETCHEDWPDATA.JOBTYPE = TEXT.JOBTYPE AND "
					+ "TEXT.PRCSTAT = 'A' AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL OR "
					+ "RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) GROUP BY FETCHEDWPDATA.R_NUM, FETCHEDWPDATA.RANGE,FETCHEDWPDATA.LBR_VARIANT, "
					+ "FETCHEDWPDATA.OBJCD1, FETCHEDWPDATA.OBJCD2, FETCHEDWPDATA.OBJCD3, FETCHEDWPDATA.ACTIVITY, FETCHEDWPDATA.VERSION, FETCHEDWPDATA.LOCATION, "
					+ "FETCHEDWPDATA.INSTALL_CON, FETCHEDWPDATA.JOBTYPE, FETCHEDWPDATA.LBR_VALUE,FETCHEDWPDATA.LABVAL, FETCHEDWPDATA.TEXT ORDER BY FETCHEDWPDATA.R_NUM";
		}

		return qry;
	}

	/**
	 * Form included wp list qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the string
	 */
	private String formIncludedWPListQry(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) {
		String qry = "";
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		if (workProcessVO.getoBJCD1() != null) {
			objCD1 = workProcessVO.getoBJCD1();
		}
		if (workProcessVO.getoBJCD2() != null) {
			objCD2 = workProcessVO.getoBJCD2();
		}
		if (workProcessVO.getoBJCD3() != null) {
			objCD3 = workProcessVO.getoBJCD3();
		}
		String code = objCD1 + objCD2 + objCD3;
		qry = "SELECT ACT.TEXT, TEXT.RANGE, TEXT.LBR_VARIANT, TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 AS LABVAL, "
				+ "TEXT.RACTIVITY AS ACTIVITY, TEXT.RVERSION AS VERSION, TEXT.RLOCATION AS LOCATION, TEXT.RINSTALL_CON AS INSTALL_CON FROM WSGLBRACTT ACT, WSGLBRTEXT TEXT "
				+ "WHERE ";
		if (!objCD1.equals("")) {
			qry = qry + "OBJCD1 = '" + objCD1 + "' ";
		} else {
			qry = qry + "OBJCD1 IS NULL ";
		}
		if (!objCD2.equals("")) {
			qry = qry + "AND OBJCD2 = '" + objCD2 + "' ";
		} else {
			qry = qry + "AND OBJCD2 IS NULL ";
		}
		if (!objCD3.equals("")) {
			qry = qry + "AND OBJCD3 = '" + objCD3 + "' ";
		} else {
			qry = qry + "AND OBJCD3 IS NULL ";
		}
		qry = qry
				+ "AND TEXT.ACTIVITY = '"
				+ workProcessVO.getaCTIVITY()
				+ "' "
				+ "AND VERSION = '"
				+ workProcessVO.getvERSION()
				+ "' "
				+ "AND LOCATION = '"
				+ workProcessVO.getlOCATION()
				+ "' "
				+ "AND INSTALL_CON = '"
				+ workProcessVO.getiNSTALLCON()
				+ "' "
				+ "AND JOBTYPE = '"
				+ workProcessVO.getjOBTYPE()
				+ "' "
				+ "AND RANGE = '"
				+ userVO.getModel()
				+ "' "
				+ "AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND TXT_TYPE = '1' "
				+ "AND ACT.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL "
				+ "OR RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) "
				+ "AND TEXT.RACTIVITY = ACT.ACTIVITY AND ACT.PRCSTAT = 'A' ";
		return qry;
	}

	/**
	 * Form not included wp list qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the string
	 */
	private String formNotIncludedWPListQry(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) {
		String qry = "";
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		if (workProcessVO.getoBJCD1() != null) {
			objCD1 = workProcessVO.getoBJCD1().trim();
		}
		if (workProcessVO.getoBJCD2() != null) {
			objCD2 = workProcessVO.getoBJCD2().trim();
		}
		if (workProcessVO.getoBJCD3() != null) {
			objCD3 = workProcessVO.getoBJCD3().trim();
		}
		qry = "SELECT TEXT.RANGE, TEXT.LBR_VARIANT, ROBJCD1 AS OBJCD1, ROBJCD2 AS OBJCD2, ROBJCD3 AS OBJCD3, TEXT.RACTIVITY AS ACTIVITY, "
				+ "TEXT.RVERSION AS VERSION, TEXT.RLOCATION AS LOCATION, TEXT.RINSTALL_CON AS INSTALL_CON, O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END "
				+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END || ' ' || ACT.TEXT AS TEXT, TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 AS LABVAL "
				+ "FROM WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRACTT ACT, WSGLBRTEXT TEXT "
				+ "WHERE ";
		if (!objCD1.equals("")) {
			qry = qry + "TEXT.OBJCD1 = '" + objCD1 + "' ";
		} else {
			qry = qry + "TEXT.OBJCD1 IS NULL ";
		}
		if (!objCD2.equals("")) {
			qry = qry + "AND TEXT.OBJCD2 = '" + objCD2 + "' ";
		} else {
			qry = qry + "AND TEXT.OBJCD2 IS NULL ";
		}
		if (!objCD3.equals("")) {
			qry = qry + "AND TEXT.OBJCD3 = '" + objCD3 + "' ";
		} else {
			qry = qry + "AND TEXT.OBJCD3 IS NULL ";
		}

		qry = qry
				+ "AND TEXT.ROBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND TEXT.ACTIVITY = '"
				+ workProcessVO.getaCTIVITY()
				+ "' "
				+ "AND VERSION = '"
				+ workProcessVO.getvERSION()
				+ "' "
				+ "AND LOCATION = '"
				+ workProcessVO.getlOCATION()
				+ "' "
				+ "AND INSTALL_CON = '"
				+ workProcessVO.getiNSTALLCON()
				+ "' "
				+ "AND JOBTYPE = '"
				+ workProcessVO.getjOBTYPE()
				+ "' "
				+ "AND RANGE = '"
				+ userVO.getModel()
				+ "' "
				+ "AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND TXT_TYPE = '2' "
				+ "AND ACT.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL "
				+ "OR RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) "
				+ "AND TEXT.RACTIVITY = ACT.ACTIVITY AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND ACT.PRCSTAT = 'A' AND TEXT.PRCSTAT = 'A' "
				+ "ORDER BY RANGE, LBR_VARIANT, ACTIVITY, VERSION, LOCATION, INSTALL_CON";
		return qry;
	}

	/**
	 * Form not included wp details qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the string
	 */
	private String formNotIncludedWPDetailsQry(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) {
		String qry = "";
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		if (workProcessVO.getoBJCD1() != null) {
			objCD1 = workProcessVO.getoBJCD1();
			objCD1 = UIUtil.formCodeOfNLength(objCD1, 3);
		}
		if (workProcessVO.getoBJCD2() != null) {
			objCD2 = workProcessVO.getoBJCD2();
			objCD2 = UIUtil.formCodeOfNLength(objCD2, 1);
		}
		if (workProcessVO.getoBJCD3() != null) {
			objCD3 = workProcessVO.getoBJCD3();
			objCD3 = UIUtil.formCodeOfNLength(objCD3, 3);
		}
		String code = objCD1 + objCD2 + objCD3;
		if (workProcessVO.getaCTIVITY() == null) {
			workProcessVO.setaCTIVITY("");
		}
		if (workProcessVO.getvERSION() == null) {
			workProcessVO.setvERSION("");
		}
		if (workProcessVO.getlOCATION() == null) {
			workProcessVO.setlOCATION("");
		}
		if (workProcessVO.getiNSTALLCON() == null) {
			workProcessVO.setiNSTALLCON("");
		}

		qry = "SELECT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
				+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END "
				+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END || ' ' || L.TEXT || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || C.TEXT AS TEXT "
				+ "FROM WSGLBRVAL LV, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L, WSGLBRACTT A, WSGLBRVRST V, WSGLBRCONT C  "
				+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
				+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE = '0' AND LV.ACTIVITY NOT IN ('0','00','000')  "
				+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
				+ "AND C.PRCSTAT = 'A'  AND RANGE in ('"
				+ userVO.getModel()
				+ "','*') AND LBR_VARIANT in ('"
				+ userVO.getVariant()
				+ "','*') "
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND L.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND A.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND V.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND C.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND LV.ACTIVITY like '"
				+ workProcessVO.getaCTIVITY()
				+ "%' "
				+ "AND LV.VERSION like '"
				+ workProcessVO.getvERSION()
				+ "%' "
				+ "AND LV.LOCATION like '"
				+ workProcessVO.getlOCATION()
				+ "%' "
				+ "AND LV.INSTALL_CON like '"
				+ workProcessVO.getiNSTALLCON()
				+ "%' "
				+ "AND LV.JOBTYPE like '%' "
				+ "AND LABVAL LIKE '"
				+ code + "%' ORDER BY LABVAL ";
		return qry;
	}

	public boolean isValidSearch(UserVO userVO, String text, Integer textId)
			throws EOIException {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.man.mn.esa.eoicatalog.laborvalue.helper.ILaborValHelper#fetchCodeText
	 * (de.man.mn.esa.eoicatalog.share.common.vo.UserVO, java.lang.String,
	 * java.lang.String, java.lang.Integer)
	 */
	public String fetchCodeText(UserVO userVO, String text, Integer textId)
			throws EOIException {
		String returnText = "-1MISSINGCODE1-";
		return returnText;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.man.mn.esa.eoicatalog.laborvalue.helper.ILaborValHelper#
	 * fetchMostValidWPAttributes
	 * (de.man.mn.esa.eoicatalog.share.common.vo.UserVO,
	 * de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO,
	 * de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public WorkProcessVO fetchMostValidWPAttributes(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		// TODO Auto-generated method stub
		return null;
	}
}
