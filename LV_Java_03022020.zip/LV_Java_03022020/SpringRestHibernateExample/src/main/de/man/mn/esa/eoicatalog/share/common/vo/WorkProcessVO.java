/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;
import de.man.mn.esa.eoicatalog.ui.util.UIUtil;

/**
 * The Class WorkProcessVO.
 * 
 * Author: Yuvraj Patil
 */
public class WorkProcessVO extends BaseVO implements Comparable<WorkProcessVO> {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 77796953481239312L;

	/** The rANGE. */
	private String rANGE;

	/** The LB r_ variant. */
	private String lBRVARIANT;

	/** The OBJC d1. */
	private String oBJCD1;

	/** The OBJC d2. */
	private String oBJCD2;

	/** The OBJC d3. */
	private String oBJCD3;

	/** The vERSION. */
	private String vERSION;

	/** The lOCATION. */
	private String lOCATION;

	/** The INSTAL l_ con. */
	private String iNSTALLCON;

	/** The aCTIVITY. */
	private String aCTIVITY;

	/** The jOBTYPE. */
	private String jOBTYPE;

	/** The vKORG. */
	private String vKORG;

	/** The LB r_ value. */
	private String lBRVALUE;

	/** The lABVAL. */
	private String lABVAL;

	/** The pRCSTAT. */
	private String pRCSTAT;

	/** The tEXT. */
	private String tEXT;

	/** The TX t_ type. */
	private String tXTTYPE;

	/** The N o_ o f_ includedwp. */
	private Integer nOOFINCLUDEDWP;

	/** The N o_ o f_ notincludedwp. */
	private Integer nOOFNOTINCLUDEDWP;

	/** The pOSITIONTYPE. */
	private String pOSITIONTYPE;

	private List<WorkProcessVO> subWorkProcessVOs;
	/**
	 * To sting.
	 * 
	 * @return the string
	 */
	public String toSting() {
		return rANGE + lBRVARIANT + oBJCD1 + oBJCD2 + oBJCD3 + aCTIVITY
				+ vERSION + lOCATION + iNSTALLCON + jOBTYPE + vKORG + lBRVALUE
				+ lABVAL + pRCSTAT + tEXT + tXTTYPE + nOOFINCLUDEDWP
				+ nOOFNOTINCLUDEDWP + subWorkProcessVOs;
	}

	/**
	 * Gets the rANGE.
	 * 
	 * @return the rANGE
	 */
	public String getrANGE() {
		return rANGE;
	}

	/**
	 * Sets the rANGE.
	 * 
	 * @param rANGE
	 *            the new rANGE
	 */
	public void setrANGE(String rANGE) {
		this.rANGE = rANGE;
	}

	/**
	 * Gets the lB r_ variant.
	 * 
	 * @return the lB r_ variant
	 */
	public String getlBRVARIANT() {
		return lBRVARIANT;
	}

	/**
	 * Sets the lB r_ variant.
	 * 
	 * @param lBR_VARIANT
	 *            the new lB r_ variant
	 */
	public void setlBRVARIANT(String lBR_VARIANT) {
		lBRVARIANT = lBR_VARIANT;
	}

	/**
	 * Gets the oBJC d1.
	 * 
	 * @return the oBJC d1
	 */
	public String getoBJCD1() {
		return oBJCD1;
	}

	/**
	 * Sets the oBJC d1.
	 * 
	 * @param oBJCD1
	 *            the new oBJC d1
	 */
	public void setoBJCD1(String oBJCD1) {
		this.oBJCD1 = oBJCD1;
	}

	/**
	 * Gets the oBJC d2.
	 * 
	 * @return the oBJC d2
	 */
	public String getoBJCD2() {
		return oBJCD2;
	}

	/**
	 * Sets the oBJC d2.
	 * 
	 * @param oBJCD2
	 *            the new oBJC d2
	 */
	public void setoBJCD2(String oBJCD2) {
		this.oBJCD2 = oBJCD2;
	}

	/**
	 * Gets the oBJC d3.
	 * 
	 * @return the oBJC d3
	 */
	public String getoBJCD3() {
		return oBJCD3;
	}

	/**
	 * Sets the oBJC d3.
	 * 
	 * @param oBJCD3
	 *            the new oBJC d3
	 */
	public void setoBJCD3(String oBJCD3) {
		this.oBJCD3 = oBJCD3;
	}

	/**
	 * Gets the vERSION.
	 * 
	 * @return the vERSION
	 */
	public String getvERSION() {
		return vERSION;
	}

	/**
	 * Sets the vERSION.
	 * 
	 * @param vERSION
	 *            the new vERSION
	 */
	public void setvERSION(String vERSION) {
		this.vERSION = vERSION;
	}

	/**
	 * Gets the lOCATION.
	 * 
	 * @return the lOCATION
	 */
	public String getlOCATION() {
		return lOCATION;
	}

	/**
	 * Sets the lOCATION.
	 * 
	 * @param lOCATION
	 *            the new lOCATION
	 */
	public void setlOCATION(String lOCATION) {
		this.lOCATION = lOCATION;
	}

	/**
	 * Gets the iNSTAL l_ con.
	 * 
	 * @return the iNSTAL l_ con
	 */
	public String getiNSTALLCON() {
		return iNSTALLCON;
	}

	/**
	 * Sets the iNSTAL l_ con.
	 * 
	 * @param iNSTALL_CON
	 *            the new iNSTAL l_ con
	 */
	public void setiNSTALLCON(String iNSTALL_CON) {
		this.iNSTALLCON = iNSTALL_CON;
	}

	/**
	 * Gets the aCTIVITY.
	 * 
	 * @return the aCTIVITY
	 */
	public String getaCTIVITY() {
		return aCTIVITY;
	}

	/**
	 * Sets the aCTIVITY.
	 * 
	 * @param aCTIVITY
	 *            the new aCTIVITY
	 */
	public void setaCTIVITY(String aCTIVITY) {
		this.aCTIVITY = aCTIVITY;
	}

	/**
	 * Gets the jOBTYPE.
	 * 
	 * @return the jOBTYPE
	 */
	public String getjOBTYPE() {
		return jOBTYPE;
	}

	/**
	 * Sets the jOBTYPE.
	 * 
	 * @param jOBTYPE
	 *            the new jOBTYPE
	 */
	public void setjOBTYPE(String jOBTYPE) {
		this.jOBTYPE = jOBTYPE;
	}

	/**
	 * Gets the vKORG.
	 * 
	 * @return the vKORG
	 */
	public String getvKORG() {
		return vKORG;
	}

	/**
	 * Sets the vKORG.
	 * 
	 * @param vKORG
	 *            the new vKORG
	 */
	public void setvKORG(String vKORG) {
		this.vKORG = vKORG;
	}

	/**
	 * Gets the lB r_ value.
	 * 
	 * @return the lB r_ value
	 */
	public String getlBRVALUE() {
		return lBRVALUE;
	}

	public String getlBRVALUESepratedWithPipe() {
		String rtnValue = UIUtil.insertSepratorInLVCode(lABVAL);
		return rtnValue;
	}

	/**
	 * Sets the lB r_ value.
	 * 
	 * @param lBR_VALUE
	 *            the new lB r_ value
	 */
	public void setlBRVALUE(String lBR_VALUE) {
		this.lBRVALUE = lBR_VALUE;
	}

	/**
	 * Gets the lABVAL.
	 * 
	 * @return the lABVAL
	 */
	public String getlABVAL() {
		return lABVAL;
	}

	/**
	 * Sets the lABVAL.
	 * 
	 * @param lABVAL
	 *            the new lABVAL
	 */
	public void setlABVAL(String lABVAL) {
		this.lABVAL = lABVAL;
	}

	/**
	 * Gets the pRCSTAT.
	 * 
	 * @return the pRCSTAT
	 */
	public String getpRCSTAT() {
		return pRCSTAT;
	}

	/**
	 * Sets the pRCSTAT.
	 * 
	 * @param pRCSTAT
	 *            the new pRCSTAT
	 */
	public void setpRCSTAT(String pRCSTAT) {
		this.pRCSTAT = pRCSTAT;
	}

	/**
	 * Gets the tEXT.
	 * 
	 * @return the tEXT
	 */
	public String gettEXT() {
		return tEXT;
	}

	/**
	 * Sets the tEXT.
	 * 
	 * @param tEXT
	 *            the new tEXT
	 */
	public void settEXT(String tEXT) {
		this.tEXT = tEXT;
	}

	/**
	 * Gets the tX t_ type.
	 * 
	 * @return the tX t_ type
	 */
	public String gettXTTYPE() {
		return tXTTYPE;
	}

	/**
	 * Sets the tX t_ type.
	 * 
	 * @param tXT_TYPE
	 *            the new tX t_ type
	 */
	public void settXTTYPE(String tXT_TYPE) {
		this.tXTTYPE = tXT_TYPE;
	}

	/**
	 * Gets the n o_ o f_ includedwp.
	 * 
	 * @return the n o_ o f_ includedwp
	 */
	public Integer getnOOFINCLUDEDWP() {
		return nOOFINCLUDEDWP;
	}

	/**
	 * Sets the n o_ o f_ includedwp.
	 * 
	 * @param nO_OF_INCLUDEDWP
	 *            the new n o_ o f_ includedwp
	 */
	public void setnOOFINCLUDEDWP(Integer nO_OF_INCLUDEDWP) {
		this.nOOFINCLUDEDWP = nO_OF_INCLUDEDWP;
	}

	/**
	 * Gets the n o_ o f_ notincludedwp.
	 * 
	 * @return the n o_ o f_ notincludedwp
	 */
	public Integer getnOOFNOTINCLUDEDWP() {
		return nOOFNOTINCLUDEDWP;
	}

	/**
	 * Sets the n o_ o f_ notincludedwp.
	 * 
	 * @param nO_OF_NOTINCLUDEDWP
	 *            the new n o_ o f_ notincludedwp
	 */
	public void setnOOFNOTINCLUDEDWP(Integer nO_OF_NOTINCLUDEDWP) {
		this.nOOFNOTINCLUDEDWP = nO_OF_NOTINCLUDEDWP;
	}

	/**
	 * Gets the pOSITIONTYPE.
	 * 
	 * @return the pOSITIONTYPE
	 */
	public String getpOSITIONTYPE() {
		return pOSITIONTYPE;
	}

	/**
	 * Sets the pOSITIONTYPE.
	 * 
	 * @param pOSITIONTYPE
	 *            the new pOSITIONTYPE
	 */
	public void setpOSITIONTYPE(String pOSITIONTYPE) {
		this.pOSITIONTYPE = pOSITIONTYPE;
	}

	/**
	 * Compare to.
	 * 
	 * @param o
	 *            the o
	 * @return the int
	 */
	public int compareTo(WorkProcessVO o) {
		// TODO Auto-generated method stub
		int rtnVal = 0;
		if (this.rANGE != null && o.rANGE != null
				&& this.rANGE.compareToIgnoreCase(o.rANGE) != 0) {
			rtnVal = this.rANGE.compareToIgnoreCase(o.rANGE);
		} else if (this.lBRVARIANT != null && o.lBRVARIANT != null
				&& this.lBRVARIANT.compareToIgnoreCase(o.lBRVARIANT) != 0) {
			rtnVal = this.lBRVARIANT.compareToIgnoreCase(o.lBRVARIANT);
		} else if (this.aCTIVITY != null && o.aCTIVITY != null
				&& this.aCTIVITY.compareToIgnoreCase(o.aCTIVITY) != 0) {
			rtnVal = this.aCTIVITY.compareToIgnoreCase(o.aCTIVITY);
		} else if (this.vERSION != null && o.vERSION != null
				&& this.vERSION.compareToIgnoreCase(o.vERSION) != 0) {
			rtnVal = this.vERSION.compareToIgnoreCase(o.vERSION);
		} else if (this.lOCATION != null && o.lOCATION != null
				&& this.lOCATION.compareToIgnoreCase(o.lOCATION) != 0) {
			rtnVal = this.lOCATION.compareToIgnoreCase(o.lOCATION);
		} else if (this.iNSTALLCON != null && o.iNSTALLCON != null
				&& this.iNSTALLCON.compareToIgnoreCase(o.iNSTALLCON) != 0) {
			rtnVal = this.iNSTALLCON.compareToIgnoreCase(o.iNSTALLCON);
		} else if (this.lABVAL != null && o.lABVAL != null
				&& this.lABVAL.compareToIgnoreCase(o.lABVAL) != 0) {
			rtnVal = this.lABVAL.compareToIgnoreCase(o.lABVAL);
		}
		return rtnVal;
	}
    /**
     * 
     * @return
     */
	public List<WorkProcessVO> getSubWorkProcessVOs() {
		return subWorkProcessVOs;
	}
    /**
     * 
     * @param subWorkProcessVOs
     */
	public void setSubWorkProcessVOs(List<WorkProcessVO> subWorkProcessVOs) {
		this.subWorkProcessVOs = subWorkProcessVOs;
	}
}
