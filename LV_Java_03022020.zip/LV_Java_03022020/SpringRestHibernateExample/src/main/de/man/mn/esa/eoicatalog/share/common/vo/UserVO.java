/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

/**
 * The Class UserVO.
 * 
 * Author: Yuvraj Patil
 */

public class UserVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The user id. */
	private String userID;

	/** The language. */
	private String language;

	/** The model. */
	private String model;

	/** The variant. */
	private String variant;

	/** The rear axel1 type. */
	private String rearAxel1Type;

	/** The motor type. */
	private String motorType;

	/** The transmission type. */
	private String transmissionType;

	/** The catalog. */
	private String catalog;

	/** The unit. */
	private String unit;

	/** The object_code1. */
	private String objectCode1 = null;

	/** The object_code2. */
	private String objectCode2 = null;

	/** The object_code3. */
	private String objectCode3 = null;
	
	// BOC: Additional parameter DMS_Order - R4867 - 31.08.2016
	private String dmsOrder = null;
	// EOC: Additional parameter DMS_Order - R4867 - 31.08.2016

	/**
	 * Gets the user id.
	 * 
	 * @return the user id
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * Sets the user id.
	 * 
	 * @param userID
	 *            the new user id
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * Gets the language.
	 * 
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * Sets the language.
	 * 
	 * @param language
	 *            the new language
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * Gets the model.
	 * 
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * Sets the model.
	 * 
	 * @param model
	 *            the new model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * Gets the variant.
	 * 
	 * @return the variant
	 */
	public String getVariant() {
		return variant;
	}

	/**
	 * Sets the variant.
	 * 
	 * @param variant
	 *            the new variant
	 */
	public void setVariant(String variant) {
		this.variant = variant;
	}

	/**
	 * Gets the rear axel1 type.
	 * 
	 * @return the rear axel1 type
	 */
	public String getRearAxel1Type() {
		return rearAxel1Type;
	}

	/**
	 * Sets the rear axel1 type.
	 * 
	 * @param rearAxel1Type
	 *            the new rear axel1 type
	 */
	public void setRearAxel1Type(String rearAxel1Type) {
		this.rearAxel1Type = rearAxel1Type;
	}

	/**
	 * Gets the motor type.
	 * 
	 * @return the motor type
	 */
	public String getMotorType() {
		return motorType;
	}

	/**
	 * Sets the motor type.
	 * 
	 * @param motorType
	 *            the new motor type
	 */
	public void setMotorType(String motorType) {
		this.motorType = motorType;
	}

	/**
	 * Gets the transmission type.
	 * 
	 * @return the transmission type
	 */
	public String getTransmissionType() {
		return transmissionType;
	}

	/**
	 * Sets the transmission type.
	 * 
	 * @param transmissionType
	 *            the new transmission type
	 */
	public void setTransmissionType(String transmissionType) {
		this.transmissionType = transmissionType;
	}

	/**
	 * Gets the catalog.
	 * 
	 * @return the catalog
	 */
	public String getCatalog() {
		return catalog;
	}

	/**
	 * Sets the catalog.
	 * 
	 * @param catalog
	 *            the new catalog
	 */
	public void setCatalog(String catalog) {
		this.catalog = catalog;
	}

	/**
	 * Gets the unit.
	 * 
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * Sets the unit.
	 * 
	 * @param unit
	 *            the new unit
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

	/**
	 * Gets the object code1.
	 *
	 * @return the object code1
	 */
	public String getObjectCode1() {
		return objectCode1;
	}

	/**
	 * Sets the object code1.
	 *
	 * @param objectCode1 the new object code1
	 */
	public void setObjectCode1(String objectCode1) {
		this.objectCode1 = objectCode1;
	}

	/**
	 * Gets the object code2.
	 *
	 * @return the object code2
	 */
	public String getObjectCode2() {
		return objectCode2;
	}

	/**
	 * Sets the object code2.
	 *
	 * @param objectCode2 the new object code2
	 */
	public void setObjectCode2(String objectCode2) {
		this.objectCode2 = objectCode2;
	}

	/**
	 * Gets the object code3.
	 *
	 * @return the object code3
	 */
	public String getObjectCode3() {
		return objectCode3;
	}

	/**
	 * Sets the object code3.
	 *
	 * @param objectCode3 the new object code3
	 */
	public void setObjectCode3(String objectCode3) {
		this.objectCode3 = objectCode3;
	}

	// BOC: Additional parameter DMS_Order - R4867 - 31.08.2016
	/**
	 * Gets the MAN_ORDER parameter
	 * @return manOrder
	 */
	public String getDmsOrder() {
		return dmsOrder;
	}
	
	/**
	 * Sets the MAN_ORDER parameter
	 * @return
	 */
	public void setDmsOrder(String dmsOrder) {
		this.dmsOrder = dmsOrder;
	}
	// EOC: Additional parameter DMS_Order - R4867 - 31.08.2016

}
