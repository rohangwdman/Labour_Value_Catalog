/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

/**
 * The Interface INode.
 * 
 * Author: Aathavan Sivasubramonian
 */
public interface INode {

	/**
	 * Gets the type.
	 * 
	 * @return the type
	 */
	public int getType();

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode();

	/**
	 * Sets the code.
	 * 
	 * @param code
	 *            the new code
	 */
	public void setCode(String code);

	/**
	 * Gets the text.
	 * 
	 * @return the text
	 */
	public String getName();

	/**
	 * Sets the text.
	 * 
	 * @param text
	 *            the new text
	 */
	public void setName(String name);

	/**
	 * Gets the level.
	 * 
	 * @return the level
	 */
	public int getLevel();

	/**
	 * Sets the level.
	 * 
	 * @param level
	 *            the new level
	 */
	public void setLevel(int level);
}
