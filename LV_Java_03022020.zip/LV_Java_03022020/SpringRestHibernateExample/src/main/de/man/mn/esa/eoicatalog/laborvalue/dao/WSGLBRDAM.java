/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class WSGLBRDAM.
 * 
 * Author: Reena Rawat
 */
@Entity
@Table(name = "WSGLBRDAM")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class WSGLBRDAM implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The LABVAL. */
	@Id
	@Column(name = "LABVAL")
	private String LABVAL; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The OBJC d1. */
	@Column(name = "OBJCD1")
	private String OBJCD1; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The OBJC d2. */
	@Column(name = "OBJCD2")
	private String OBJCD2; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The OBJC d3. */
	@Column(name = "OBJCD3")
	private String OBJCD3; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The VERSION. */
	@Column(name = "VERSION")
	private String VERSION; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The LOCATION. */
	@Column(name = "LOCATION")
	private String LOCATION; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The DAMAGE. */
	@Column(name = "DAMAGE")
	private String DAMAGE; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The PRCSTAT. */
	@Column(name = "PRCSTAT")
	private String PRCSTAT; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The TEXT. */
	private String TEXT; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The DAMAGETEXT. */
	private String DAMAGETEXT; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The R_ num. */
	private BigDecimal R_NUM; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/**
	 * Gets the tEXT.
	 * 
	 * @return the tEXT
	 */
	public String getTEXT() {
		return TEXT;
	}

	/**
	 * Sets the tEXT.
	 * 
	 * @param tEXT
	 *            the new tEXT
	 */
	public void setTEXT(String tEXT) {
		TEXT = tEXT;
	}

	public String getDAMAGETEXT() {
		return DAMAGETEXT;
	}

	public void setDAMAGETEXT(String dAMAGETEXT) {
		DAMAGETEXT = dAMAGETEXT;
	}

	/**
	 * Gets the oBJC d1.
	 * 
	 * @return the oBJC d1
	 */
	public String getOBJCD1() {
		return OBJCD1;
	}

	/**
	 * Sets the oBJC d1.
	 * 
	 * @param oBJCD1
	 *            the new oBJC d1
	 */
	public void setOBJCD1(String oBJCD1) {
		OBJCD1 = oBJCD1;
	}

	/**
	 * Gets the oBJC d2.
	 * 
	 * @return the oBJC d2
	 */
	public String getOBJCD2() {
		return OBJCD2;
	}

	/**
	 * Sets the oBJC d2.
	 * 
	 * @param oBJCD2
	 *            the new oBJC d2
	 */
	public void setOBJCD2(String oBJCD2) {
		OBJCD2 = oBJCD2;
	}

	/**
	 * Gets the oBJC d3.
	 * 
	 * @return the oBJC d3
	 */
	public String getOBJCD3() {
		return OBJCD3;
	}

	/**
	 * Sets the oBJC d3.
	 * 
	 * @param oBJCD3
	 *            the new oBJC d3
	 */
	public void setOBJCD3(String oBJCD3) {
		OBJCD3 = oBJCD3;
	}

	/**
	 * Gets the vERSION.
	 * 
	 * @return the vERSION
	 */
	public String getVERSION() {
		return VERSION;
	}

	/**
	 * Sets the vERSION.
	 * 
	 * @param vERSION
	 *            the new vERSION
	 */
	public void setVERSION(String vERSION) {
		VERSION = vERSION;
	}

	/**
	 * Gets the lOCATION.
	 * 
	 * @return the lOCATION
	 */
	public String getLOCATION() {
		return LOCATION;
	}

	/**
	 * Sets the lOCATION.
	 * 
	 * @param lOCATION
	 *            the new lOCATION
	 */
	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}

	/**
	 * Gets the lABVAL.
	 * 
	 * @return the lABVAL
	 */
	public String getLABVAL() {
		return LABVAL;
	}

	/**
	 * Sets the lABVAL.
	 * 
	 * @param lABVAL
	 *            the new lABVAL
	 */
	public void setLABVAL(String lABVAL) {
		LABVAL = lABVAL;
	}

	/**
	 * Gets the pRCSTAT.
	 * 
	 * @return the pRCSTAT
	 */
	public String getPRCSTAT() {
		return PRCSTAT;
	}

	/**
	 * Sets the pRCSTAT.
	 * 
	 * @param pRCSTAT
	 *            the new pRCSTAT
	 */
	public void setPRCSTAT(String pRCSTAT) {
		PRCSTAT = pRCSTAT;
	}

	/**
	 * Gets the dAMAGE.
	 * 
	 * @return the dAMAGE
	 */
	public String getDAMAGE() {
		return DAMAGE;
	}

	/**
	 * Sets the dAMAGE.
	 * 
	 * @param dAMAGE
	 *            the new dAMAGE
	 */
	public void setDAMAGE(String dAMAGE) {
		DAMAGE = dAMAGE;
	}

	@Override
	public int hashCode() {
		int hash = 1;
		// hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		boolean equals = true;
		if (!(object instanceof WSGLBRDAM)) {
			return false;
		}
		WSGLBRDAM other = (WSGLBRDAM) object;

		equals = checkEqual(this.LABVAL, other.LABVAL);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.PRCSTAT, other.PRCSTAT);
		if (!equals) {
			return equals;
		}
		return equals;
	}

	/**
	 * Check equal.
	 * 
	 * @param one
	 *            the one
	 * @param two
	 *            the two
	 * @return true, if successful
	 */
	private boolean checkEqual(String one, String two) {
		boolean equals = true;
		if (one != null && two != null) {
			if (!one.equals(two)) {
				equals = false;
			}
		} else {
			if ((one == null && two != null) || (one != null && two == null)) {
				equals = false;
			}
		}
		return equals;
	}

	@Override
	public String toString() {
		return "WSGLBRDAM=" + OBJCD1 + " " + OBJCD2 + " " + OBJCD3 + " " + " "
				+ VERSION + " " + LOCATION + " " + LABVAL + " " + PRCSTAT + "]";
	}

	/**
	 * Gets the r_ num.
	 * 
	 * @return the r_ num
	 */
	public BigDecimal getR_NUM() { // NOPMD by yuvraj_patil01 on 3/19/11 10:49
									// AM
		return R_NUM;
	}

	/**
	 * Sets the r_ num.
	 * 
	 * @param r_NUM
	 *            the new r_ num
	 */
	public void setR_NUM(BigDecimal r_NUM) { // NOPMD by yuvraj_patil01 on
												// 3/19/11 10:49 AM
		R_NUM = r_NUM;
	}

}
