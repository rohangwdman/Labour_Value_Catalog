/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.service.rpc;

import java.util.List;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


import de.man.mn.esa.eoicatalog.damagecode.facade.DamageCodeFacade;
import de.man.mn.esa.eoicatalog.damagecode.facade.IDamageCodeFacade;
import de.man.mn.esa.eoicatalog.laborvalue.helper.LaborValHelper;
import de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.LVNodeSearchResultVO;
import de.man.mn.esa.eoicatalog.share.common.vo.LVNodeSearchVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

/**
 * The Class IRemoteDamageCodeServlet.
 * 
 * Author: Reena Rawat
 */
@RestController
@RequestMapping("/damage")
public class IRemoteDamageCodeServlet{

	@Autowired
	private IDamageCodeFacade facade;
	
	private static final Logger LOGGER = Logger.getLogger(IRemoteDamageCodeServlet.class);

	/**
	 * Gets the damage code facade.
	 * 
	 * @return the damage code facade
	 */

	/**
	 * Fetch parent nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	// private static final String DMGCODEFACADE = "damageCodeFacade";

	/**
	 * Fetch parent nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchParentNodes", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<NodeVO> fetchParentNodes(@RequestBody UserVO userVO) throws EOIException {
		// IDamageCodeFacade facade = (IDamageCodeFacade)
		// getContextService(DMGCODEFACADE);
		Long inTime = System.currentTimeMillis();
		List nodeVOList = facade.fetchParentNodes(userVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 10){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch parent node in stipulated time period for Damage Code Catalog");
		}
		return nodeVOList;
	}

	/**
	 * Fetch dmg codes list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchDMGCodesList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchDMGCodesList(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO node, PaginationVO paginationVO)
			throws EOIException {
		// IDamageCodeFacade facade = (IDamageCodeFacade)
		// getContextService(DMGCODEFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchDMGCodesList(userVO, damageCodeVO,
				node, paginationVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3 && pagination.getTotalRecords()< 30){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch damage code list for tabulation section in stipulated time period for Damage Code Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchChildNodes", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<NodeVO> fetchChildNodes(DamageCodeVO damageCodeVO,
			NodeVO nodeVO, UserVO userVO) throws EOIException {
		// IDamageCodeFacade facade = (IDamageCodeFacade)
		// getContextService(DMGCODEFACADE);
		Long inTime = System.currentTimeMillis();
		List nodeVOList = facade.fetchChildNodes(damageCodeVO, nodeVO,
				userVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 2){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch child nodes in stipulated time period for Damage Code Catalog");
		}
		return nodeVOList;
	}

	/**
	 * Fetch dmg search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchDMGSearchList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchDMGSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		// IDamageCodeFacade facade = (IDamageCodeFacade)
		// getContextService(DMGCODEFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchDMGSearchList(searchText, objectCode,
				userVO, paginationVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch damage code search list in stipulated time period for Damage Code Catalog");
		}
		return pagination;
	}

	/**
	 * Gets the context service.
	 * 
	 * @param serviceId
	 *            the service id
	 * @return the context service
	 *//*
	protected IDamageCodeFacade getContextService(String serviceId) {

		ServletContext context = getServletContext();

		WebApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(context);

		return (IDamageCodeFacade) applicationContext.getBean(serviceId);

	}*/

	/**
	 * Fetch child nodes.
	 * 
	 * @param nodeSearchVO
	 *            the node search vo
	 * @param userVO
	 *            the user vo
	 * @return the lV node search result vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchChildNodesForSearch", method = RequestMethod.POST, headers = "Accept=application/json")
	public LVNodeSearchResultVO fetchChildNodes(LVNodeSearchVO nodeSearchVO,
			UserVO userVO) throws EOIException {
		// IDamageCodeFacade facade = (IDamageCodeFacade)
		// getContextService(DMGCODEFACADE);
		Long inTime = System.currentTimeMillis();
		List<NodeVO> nodeList = null;
		LVNodeSearchResultVO resultVO = new LVNodeSearchResultVO();
		resultVO.setLevel(nodeSearchVO.getLevel());
		DamageCodeVO damageCode = new DamageCodeVO();
		nodeList = facade.fetchChildNodes(damageCode,
				nodeSearchVO.getNodeVO(), userVO);
		resultVO.setNodeVOList(nodeList);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 2){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch child nodes in stipulated time period for Damage Code Catalog");
		}
		return resultVO;
	}

	/**
	 * Fetch dmg codes list for defect field.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param dmgCodeVO
	 *            the dmg code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchDMGCodesListForDefectField", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchDMGCodesListForDefectField(UserVO userVO,
			DamageCodeVO dmgCodeVO, NodeVO node, PaginationVO paginationVO)
			throws EOIException {
		// IDamageCodeFacade facade = (IDamageCodeFacade)
		// getContextService(DMGCODEFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchDMGCodesListForDefectField(userVO,
				dmgCodeVO, node, paginationVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3 && pagination.getTotalRecords()< 30){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch damage code list for tabulation section in stipulated time period for Damage Code Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch valid search.
	 * 
	 * @param text
	 *            the text
	 * @return true, if successful
	 * @throws EOIException 
	 */
	@RequestMapping(value = "/fetchValidSearch", method = RequestMethod.POST, headers = "Accept=application/json")
	public boolean fetchValidSearch(UserVO userVO, String text, Integer textId)
			throws EOIException {
		// TODO Auto-generated method stub
		Long inTime = System.currentTimeMillis();
		boolean isValidSearch = facade.fetchValidSearch(userVO,text,textId);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		return isValidSearch;
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.share.service.IRemoteDamageCodeService#fetchValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	@RequestMapping(value = "/fetchValidObjCode", method = RequestMethod.POST, headers = "Accept=application/json")
	public DamageCodeVO fetchValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		Long inTime = System.currentTimeMillis();
		DamageCodeVO damageCode = facade.fetchValidObjCode(userVO, damageCodeVO, nodeVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		return damageCode;
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.share.service.IRemoteDamageCodeService#isValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	@RequestMapping(value = "/isValidObjCode", method = RequestMethod.POST, headers = "Accept=application/json")
	public boolean isValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException{
		// TODO Auto-generated method stub
		Long inTime = System.currentTimeMillis();
		boolean isValidObjCode = facade.isValidObjCode(userVO, damageCodeVO, nodeVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		return isValidObjCode;
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.share.service.IRemoteDamageCodeService#fetchMostValidWPAttributes(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	@RequestMapping(value = "/fetchMostValidDCAttributes", method = RequestMethod.POST, headers = "Accept=application/json")
	public DamageCodeVO fetchMostValidDCAttributes(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		Long inTime = System.currentTimeMillis();
		DamageCodeVO damageCode = facade.fetchMostValidDCAttributes(userVO, damageCodeVO, nodeVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		return damageCode;
	}

}
