/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.ui.constants;

/**
 * The Class UIConstants.
 * 
 * Author: Aathavan Sivasubramonian
 */
public class UIConstants {

	/**
	 * The Class WPTable.
	 * 
	 * Author: Aathavan Sivasubramonian
	 */
	public class WPTable {

		/** The Constant INFOCOLINDEX. */
		public static final int INFOCOLINDEX = 1;

	}

	/**
	 * The Class LVView.
	 * 
	 * Author: Reena Rawat
	 */
	public class LVView {

		/** The Constant OBJECTTEXTBOXID. */
		// public static final int OBJECTTEXTBOXID = 1;
		public static final int OBJECTTEXTBOX1ID = 11;
		public static final int OBJECTTEXTBOX2ID = 12;
		public static final int OBJECTTEXTBOX3ID = 13;

		/** The Constant ACTIVITYTEXTBOXID. */
		public static final int ACTIVITYTEXTBOXID = 2;

		/** The Constant VLTEXTBOXID. */
		public static final int VLTEXTBOXID = 3;

		/** The Constant PNTEXTBOXID. */
		public static final int PNTEXTBOXID = 4;

		/** The Constant CONDITIONTEXTBOXID. */
		public static final int CONDITIONTEXTBOXID = 5;

		/** The Constant WORKTYPETEXTBOXID. */
		public static final int WORKTYPETEXTBOXID = 6;
	}

	/**
	 * The Class Searchtype.
	 * 
	 * Author: Reena Rawat
	 */
	public class Searchtype {

		/** The Constant LVOBJECTSEARCH. */
		public static final int LVOBJECTSEARCH = 1;

		/** The Constant LVACTIVITYSEARCH. */
		public static final int LVACTIVITYSEARCH = 2;

		/** The Constant LVVERLOCSEARCH. */
		public static final int LVVERLOCSEARCH = 3;

		/** The Constant LVPOSNUMSEARCH. */
		public static final int LVPOSNUMSEARCH = 4;

		/** The Constant LVCONDITIONSEARCH. */
		public static final int LVCONDITIONSEARCH = 5;

		/** The Constant LVWORKPROCESSSEARCH. */
		public static final int LVWORKPROCESSSEARCH = 7;

		/** The Constant LVOBJECTCODESEARCH. */
		public static final int LVOBJECTCODESEARCH = 8;

		/** The Constant DMGOBJECTCODESEARCH. */
		public static final int DMGOBJECTCODESEARCH = 9;
		
		// BOC: Search icons on Damage Catalog - 13.January.2016 - R4867
		/** The Constant DMGOBJECTCODESEARCH */
		public static final int DMGVERLOCSEARCH = 10;
		
		/** The Constant DMGOBJECTCODESEARCH */
		public static final int DMGPOSNUMSEARCH = 11;
		
		/** The Constant DMGOBJECTCODESEARCH */
		public static final int DMGDEFTYPSEARCH = 12;
		// EOC: Search icons on Damage Catalog - 13.January.2016 - R4867

	}

	/**
	 * The Class DCView.
	 * 
	 * Author: Reena Rawat
	 */
	public class DCView {

		/** The Constant OBJECTTEXTBOXID. */
		// public static final int OBJECTTEXTBOXID = 1;
		public static final int OBJECTTEXTBOX1ID = 11;
		public static final int OBJECTTEXTBOX2ID = 12;
		public static final int OBJECTTEXTBOX3ID = 13;

		/** The Constant VLTEXTBOXID. */
		public static final int VLTEXTBOXID = 2;

		/** The Constant PNTEXTBOXID. */
		public static final int PNTEXTBOXID = 3;

		/** The Constant DEFECTTEXTBOXID. */
		public static final int DEFECTTEXTBOXID = 4;
	}

}
