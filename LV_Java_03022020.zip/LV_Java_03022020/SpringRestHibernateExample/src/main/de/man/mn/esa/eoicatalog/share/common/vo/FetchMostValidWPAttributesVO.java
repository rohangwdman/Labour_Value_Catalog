package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

public class FetchMostValidWPAttributesVO extends BaseVO{

	/**
	 * Instantiates a new node vo.
	 */
	public FetchMostValidWPAttributesVO() {

	}
	/**
	 * 
	 */
	private ObjectCodeVO nodeVO;
	/**
	 * 
	 */
	private WorkProcessVO workProcessVO;
	/**
	 * 
	 */
	private UserVO userVO;
	
	private PaginationVO paginationVO;
	
	public NodeVO getNodeVO() {
		return nodeVO;
	}
	public void setNodeVO(ObjectCodeVO nodeVO) {
		this.nodeVO = nodeVO;
	}
	public WorkProcessVO getWorkProcessVO() {
		return workProcessVO;
	}
	public void setWorkProcessVO(WorkProcessVO workProcessVO) {
		this.workProcessVO = workProcessVO;
	}
	public UserVO getUserVO() {
		return userVO;
	}
	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}
	public PaginationVO getPaginationVO() {
		return paginationVO;
	}
	public void setPaginationVO(PaginationVO paginationVO) {
		this.paginationVO = paginationVO;
	}
	
}
