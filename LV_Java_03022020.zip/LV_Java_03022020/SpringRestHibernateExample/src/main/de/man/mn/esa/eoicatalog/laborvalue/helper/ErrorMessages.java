/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.helper;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.stereotype.Service;

/**
 * The Class ErrorMessages.
 * 
 * Author: Aathavan Sivasubramonian
 */
@Service
public class ErrorMessages extends PropertyPlaceholderConfigurer {

	/** The properties map. */
	private static Map propertiesMap;

	/**
	 * Process properties.
	 * 
	 * @param beanFactory
	 *            the bean factory
	 * @param props
	 *            the props
	 * @throws BeansException
	 *             the beans exception
	 */
	@Override
	protected void processProperties(
			ConfigurableListableBeanFactory beanFactory,

			Properties props) throws BeansException {

		super.processProperties(beanFactory, props);

		propertiesMap = new HashMap<String, String>();

		for (Object key : props.keySet()) {

			String keyStr = key.toString();

			propertiesMap.put(
					keyStr,
					resolvePlaceholder(props.getProperty(keyStr), props));

		}

	}

	/**
	 * Gets the property.
	 * 
	 * @param name
	 *            the name
	 * @return the property
	 */
	public static String getProperty(String name) {

		return propertiesMap.get(name) + "";

	}
}
