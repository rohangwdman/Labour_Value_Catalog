/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.damagecode.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRDAM;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRLOCT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBROBJT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRVRST;
import de.man.mn.esa.eoicatalog.laborvalue.helper.ErrorMessages;
import de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.ObjectCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PositionNumberVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.VersionLocationVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;
import de.man.mn.esa.eoicatalog.ui.constants.UIConstants;
import de.man.mn.esa.eoicatalog.ui.util.UIUtil;

/**
 * The Class HDamageCodeHelper.
 * 
 * Author: Reena Rawat
 */
@Primary
@Repository
public class HDamageCodeHelper implements IDamageCodeHelper {

	/** The hibernate template. */
	private HibernateTemplate hibernateTemplate;

	/** The error messages. */
	@Autowired
	private ErrorMessages errorMessages;

	/** The error msg. */
	private String errorMsg = "";

	/** The error code. */
	private String errorCode = "";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger
			.getLogger(DamageCodeHelper.class);

	// private static Session damageCodeSession;

	/**
	 * Sets the session factory.
	 * 
	 * @param sessionFactory
	 *            the new session factory
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
		this.hibernateTemplate.setCacheQueries(true);
		// this.damageCodeSession =
		// this.hibernateTemplate.getSessionFactory().openSession();
	}

	/**
	 * Sets the error messages.
	 * 
	 * @param errorMessages
	 *            the new error messages
	 */
	public void setErrorMessages(ErrorMessages errorMessages) {
		this.errorMessages = errorMessages;
	}

	// ** Hibernate function 1
	/**
	 * Fetch parent nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchParentNodes(UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session damageCodeSession = null;
		try {
			// System.out
			// .println("Inside ** Hibernate Function 1 -> fetchParentNodesHibernate ");
			damageCodeSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = damageCodeSession
					.createSQLQuery("SELECT DISTINCT OBJCD1, TEXT FROM WSGLBROBJT OBJ where OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
							+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,1)) from WSGLBRDAM DAM where "
							+ "DAM.PRCSTAT = 'A'"
							+ "AND DAM.damage not like 'N%' AND DAM.damage not like 'n%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
							+ "ORDER BY OBJCD1");
			query.setParameter("language", userVO.getLanguage());
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBROBJT.class)).list();

			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e022";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return nodeList;
	}

	// ** Hibernate function 2
	/**
	 * Fetch dmg codes list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesList(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO nodeVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session damageCodeSession = null;
		try {
			// System.out
			// .println("Inside ** Hibernate Function 2 -> fetchDMGCodesListHibernate ");
			String qry = "";
			damageCodeVO.setoBJCD1("");
			damageCodeVO.setoBJCD2("");
			damageCodeVO.setoBJCD3("");

			if (null != damageCodeVO.getdAMAGECODE()) {
				if (damageCodeVO.getdAMAGECODE().length() >= 3) {
					damageCodeVO.setoBJCD1(damageCodeVO.getdAMAGECODE()
							.substring(0, 3));
				} else {
					damageCodeVO
							.setoBJCD1(damageCodeVO.getdAMAGECODE().substring(
									0, damageCodeVO.getdAMAGECODE().length()));
				}

				if (damageCodeVO.getdAMAGECODE().length() >= 4) {
					damageCodeVO.setoBJCD2(damageCodeVO.getdAMAGECODE()
							.substring(3, 4));
				}

				if (damageCodeVO.getdAMAGECODE().length() >= 5) {
					if (damageCodeVO.getdAMAGECODE().length() >= 7) {
						damageCodeVO.setoBJCD3(damageCodeVO.getdAMAGECODE()
								.substring(4, 7));
					} else {
						damageCodeVO.setoBJCD3(damageCodeVO.getdAMAGECODE()
								.substring(4,
										damageCodeVO.getdAMAGECODE().length()));
					}
				}
			} else {
				if (nodeVO.getCode().length() >= 3) {
					damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3));
				} else {
					damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0,
							nodeVO.getCode().length()));
				}

				if (nodeVO.getCode().length() >= 4) {
					damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4));
				}

				if (nodeVO.getCode().length() >= 5) {
					if (nodeVO.getCode().length() >= 7) {
						damageCodeVO
								.setoBJCD3(nodeVO.getCode().substring(4, 7));
					} else {
						damageCodeVO.setoBJCD3(nodeVO.getCode().substring(4,
								nodeVO.getCode().length()));
					}
				}
			}
			if (paginationVO.getCurrentPage() == 0) {
				qry = formCountQry(userVO, damageCodeVO, nodeVO, paginationVO);
				damageCodeSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = damageCodeSession.createSQLQuery(qry);
				if (!damageCodeVO.getoBJCD1().trim().equals("")) {
					query1.setParameter("objcd1", damageCodeVO.getoBJCD1()
							.trim());
				}
				if (!damageCodeVO.getoBJCD2().trim().equals("")) {
					query1.setParameter("objcd2", damageCodeVO.getoBJCD2()
							.trim());
				}
				if (!damageCodeVO.getoBJCD3().trim().equals("")) {
					query1.setParameter("objcd3", damageCodeVO.getoBJCD3()
							.trim());
				}
				query1.setParameter("language", userVO.getLanguage());
				// query1.setParameter("damageCodeVO",
				// damageCodeVO.getdAMAGECODE());
				if (null != damageCodeVO.getdAMAGECODE()) {
					query1.setParameter("labval", damageCodeVO.getdAMAGECODE()
							.trim());
				} else {
					query1.setParameter("node", nodeVO.getCode().trim() + "%");
					// query1.setParameter("labval", "");
				}
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());

				qry = formQry(userVO, damageCodeVO, nodeVO, paginationVO);
				Query query2 = damageCodeSession.createSQLQuery(qry);
				if (!damageCodeVO.getoBJCD1().trim().equals("")) {
					query2.setParameter("objcd1", damageCodeVO.getoBJCD1()
							.trim());
				}
				if (!damageCodeVO.getoBJCD2().trim().equals("")) {
					query2.setParameter("objcd2", damageCodeVO.getoBJCD2()
							.trim());
				}
				if (!damageCodeVO.getoBJCD3().trim().equals("")) {
					query2.setParameter("objcd3", damageCodeVO.getoBJCD3()
							.trim());
				}
				query2.setParameter("language", userVO.getLanguage());
				// query2.setParameter("node", nodeVO.getCode().trim() + "%");
				// query2.setParameter("damageCodeVO",
				// damageCodeVO.getdAMAGECODE());
				if (null != damageCodeVO.getdAMAGECODE()) {
					query2.setParameter("labval", damageCodeVO.getdAMAGECODE()
							.trim());
				} else {
					query2.setParameter("node", nodeVO.getCode().trim() + "%");
					// query2.setParameter("labval", "");
				}
				if (paginationVO.getCurrentPage() != 0) {
					query2.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query2.setParameter("endRowNum",
							paginationVO.getEndRowNum());
				}
				query2.setCacheable(true);
				query2.setCacheRegion("eoicatalog.ehcache");
				result = query2.setResultTransformer(
						Transformers.aliasToBean(WSGLBRDAM.class)).list();
			} else {
				qry = formQry(userVO, damageCodeVO, nodeVO, paginationVO);
				Query query = damageCodeSession.createSQLQuery(qry);
				if (!damageCodeVO.getoBJCD1().trim().equals("")) {
					query.setParameter("objcd1", damageCodeVO.getoBJCD1()
							.trim());
				}
				if (!damageCodeVO.getoBJCD2().trim().equals("")) {
					query.setParameter("objcd2", damageCodeVO.getoBJCD2()
							.trim());
				}
				if (!damageCodeVO.getoBJCD3().trim().equals("")) {
					query.setParameter("objcd3", damageCodeVO.getoBJCD3()
							.trim());
				}
				query.setParameter("language", userVO.getLanguage());
				// query.setParameter("node", nodeVO.getCode().trim() + "%");
				// query.setParameter("damageCodeVO",
				// damageCodeVO.getdAMAGECODE());
				if (null != damageCodeVO.getdAMAGECODE()) {
					query.setParameter("labval", damageCodeVO.getdAMAGECODE()
							.trim());
				} else {
					query.setParameter("node", nodeVO.getCode().trim() + "%");
					// query.setParameter("labval", "");
				}
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRDAM.class)).list();
			}
			List<DamageCodeVO> voList = new ArrayList<DamageCodeVO>();
			populateDamageCodeVO(result, voList);
			paginationVO.setRows(voList);
		} catch (Exception e) {
			errorCode = "e023";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	// ** Hibernate function 2_a
	/**
	 * Form qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQry(UserVO userVO, DamageCodeVO damageCodeVO,
			NodeVO node, PaginationVO paginationVO) {
		// System.out
		// .println("Inside ** Hibernate Function 2_a -> formQryHibernate ");
		String qry = "";
		damageCodeVO.setoBJCD1("");
		damageCodeVO.setoBJCD2("");
		damageCodeVO.setoBJCD3("");

		if (null != damageCodeVO.getdAMAGECODE()) {
			if (damageCodeVO.getdAMAGECODE().length() >= 3) {
				damageCodeVO.setoBJCD1(damageCodeVO.getdAMAGECODE().substring(
						0, 3));
			} else {
				damageCodeVO.setoBJCD1(damageCodeVO.getdAMAGECODE().substring(
						0, damageCodeVO.getdAMAGECODE().length()));
			}

			if (damageCodeVO.getdAMAGECODE().length() >= 4) {
				damageCodeVO.setoBJCD2(damageCodeVO.getdAMAGECODE().substring(
						3, 4));
			}

			if (damageCodeVO.getdAMAGECODE().length() >= 5) {
				if (damageCodeVO.getdAMAGECODE().length() >= 7) {
					damageCodeVO.setoBJCD3(damageCodeVO.getdAMAGECODE()
							.substring(4, 7));
				} else {
					damageCodeVO
							.setoBJCD3(damageCodeVO.getdAMAGECODE().substring(
									4, damageCodeVO.getdAMAGECODE().length()));
				}
			}
		} else {
			if (node.getCode().length() >= 3) {
				damageCodeVO.setoBJCD1(node.getCode().substring(0, 3));
			} else {
				damageCodeVO.setoBJCD1(node.getCode().substring(0,
						node.getCode().length()));
			}

			if (node.getCode().length() >= 4) {
				damageCodeVO.setoBJCD2(node.getCode().substring(3, 4));
			}

			if (node.getCode().length() >= 5) {
				if (node.getCode().length() >= 7) {
					damageCodeVO.setoBJCD3(node.getCode().substring(4, 7));
				} else {
					damageCodeVO.setoBJCD3(node.getCode().substring(4,
							node.getCode().length()));
				}
			}
		}
		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3,DAM.VERSION,DAM.LOCATION,DAM.DAMAGE,DAM.LABVAL, "
				+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END "
				+ "|| ' ' || V.TEXT || ' ' ||L.TEXT || ' ' || DMGT.TEXT AS TEXT "
				+ "FROM WSGLBRDAM DAM, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L,WSGLBRVRST V, WSGLBRDMGT DMGT  "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.LOCATION = L.LOCATION AND DAM.VERSION = V.VERSION  AND DAM.damage not like 'n%' "
				+ "AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%'"
				+ "AND DAM.DAMAGE = DMGT.DAMAGE AND DAM.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND V.PRCSTAT = 'A'  AND DMGT.PRCSTAT = 'A' "
				+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
				+ "AND O3.SPRAS = :language AND L.SPRAS = :language "
				+ "AND V.SPRAS = :language AND DMGT.SPRAS = :language "
				+ "AND LABVAL LIKE "
				+ ((null != damageCodeVO.getdAMAGECODE()) ? ":labval "
						: ":node ")
				+ "AND "
				+ (damageCodeVO.getoBJCD1().trim().equals("") ? "DAM.OBJCD1 IS NULL "
						: "DAM.OBJCD1 = :objcd1 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD2().trim().equals("") ? "DAM.OBJCD2 IS NULL "
						: "DAM.OBJCD2 = :objcd2 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD3().trim().equals("") ? "DAM.OBJCD3 IS NULL "
						: "DAM.OBJCD3 = :objcd3 ") + "ORDER BY LABVAL) DATA ";

		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	// ** Hibernate function 2_a
	/**
	 * Form count qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formCountQry(UserVO userVO, DamageCodeVO damageCodeVO,
			NodeVO node, PaginationVO paginationVO) {
		// System.out
		// .println("Inside ** Hibernate Function 2_a -> formQryHibernate ");
		String qry = "";
		damageCodeVO.setoBJCD1("");
		damageCodeVO.setoBJCD2("");
		damageCodeVO.setoBJCD3("");

		if (null != damageCodeVO.getdAMAGECODE()) {
			if (damageCodeVO.getdAMAGECODE().length() >= 3) {
				damageCodeVO.setoBJCD1(damageCodeVO.getdAMAGECODE().substring(
						0, 3));
			} else {
				damageCodeVO.setoBJCD1(damageCodeVO.getdAMAGECODE().substring(
						0, damageCodeVO.getdAMAGECODE().length()));
			}

			if (damageCodeVO.getdAMAGECODE().length() >= 4) {
				damageCodeVO.setoBJCD2(damageCodeVO.getdAMAGECODE().substring(
						3, 4));
			}

			if (damageCodeVO.getdAMAGECODE().length() >= 5) {
				if (damageCodeVO.getdAMAGECODE().length() >= 7) {
					damageCodeVO.setoBJCD3(damageCodeVO.getdAMAGECODE()
							.substring(4, 7));
				} else {
					damageCodeVO
							.setoBJCD3(damageCodeVO.getdAMAGECODE().substring(
									4, damageCodeVO.getdAMAGECODE().length()));
				}
			}
		} else {
			if (node.getCode().length() >= 3) {
				damageCodeVO.setoBJCD1(node.getCode().substring(0, 3));
			} else {
				damageCodeVO.setoBJCD1(node.getCode().substring(0,
						node.getCode().length()));
			}

			if (node.getCode().length() >= 4) {
				damageCodeVO.setoBJCD2(node.getCode().substring(3, 4));
			}

			if (node.getCode().length() >= 5) {
				if (node.getCode().length() >= 7) {
					damageCodeVO.setoBJCD3(node.getCode().substring(4, 7));
				} else {
					damageCodeVO.setoBJCD3(node.getCode().substring(4,
							node.getCode().length()));
				}
			}
		}
		qry = "SELECT COUNT(*) as TOTALCOUNT FROM (SELECT DISTINCT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3,DAM.VERSION,DAM.LOCATION,DAM.DAMAGE,DAM.LABVAL, "
				+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END "
				+ "|| ' ' || V.TEXT || ' ' ||L.TEXT || ' ' || DMGT.TEXT AS TEXT "
				+ "FROM WSGLBRDAM DAM, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L,WSGLBRVRST V, WSGLBRDMGT DMGT  "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.LOCATION = L.LOCATION AND DAM.VERSION = V.VERSION  AND DAM.damage not like 'n%' "
				+ "AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%'"
				+ "AND DAM.DAMAGE = DMGT.DAMAGE AND DAM.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND V.PRCSTAT = 'A'  AND DMGT.PRCSTAT = 'A' "
				+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
				+ "AND O3.SPRAS = :language AND L.SPRAS = :language "
				+ "AND V.SPRAS = :language AND DMGT.SPRAS = :language "
				+ "AND LABVAL LIKE "
				+ ((null != damageCodeVO.getdAMAGECODE()) ? ":labval "
						: ":node ")
				+ "AND "
				+ (damageCodeVO.getoBJCD1().trim().equals("") ? "DAM.OBJCD1 IS NULL "
						: "DAM.OBJCD1 = :objcd1 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD2().trim().equals("") ? "DAM.OBJCD2 IS NULL "
						: "DAM.OBJCD2 = :objcd2 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD3().trim().equals("") ? "DAM.OBJCD3 IS NULL "
						: "DAM.OBJCD3 = :objcd3 ") + "ORDER BY LABVAL) DATA ";
		return qry;
	}

	/**
	 * Populate damage code vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateDamageCodeVO(List result, List<DamageCodeVO> voList) {
		for (int i = 0; i < result.size(); i++) {
			DamageCodeVO vo = new DamageCodeVO();
			vo.setoBJCD1(((WSGLBRDAM) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRDAM) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRDAM) result.get(i)).getOBJCD3());
			vo.setvERLOC(((WSGLBRDAM) result.get(i)).getVERSION());
			vo.setpOSNUM(((WSGLBRDAM) result.get(i)).getLOCATION());
			vo.setdAMAGECODE(((WSGLBRDAM) result.get(i)).getLABVAL());
			vo.setdEFECT(((WSGLBRDAM) result.get(i)).getDAMAGE());
			vo.settEXT(((WSGLBRDAM) result.get(i)).getTEXT());
			voList.add(vo);
		}
	}

	// ** modified for Hibernate function calls
	/**
	 * Fetch child nodes.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildNodes(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List returnNodes = new ArrayList();
		if (nodeVO instanceof ObjectCodeVO) {
			if (nodeVO.getLevel() >= 1 & nodeVO.getLevel() <= 4) {
				List verLocNodes = fetchVerLocs(damageCodeVO, nodeVO, userVO);
				returnNodes.addAll(verLocNodes);
				List objNodes = fetchChildObjects(damageCodeVO, nodeVO, userVO);
				returnNodes.addAll(objNodes);
			} else if (nodeVO.getLevel() == 5) {
				List verLocNodes = fetchVerLocs(damageCodeVO, nodeVO, userVO);
				returnNodes.addAll(verLocNodes);
			}
		} else if (nodeVO instanceof VersionLocationVO) {
			List posNumNodes = fetchPosNum(damageCodeVO, nodeVO, userVO);
			returnNodes.addAll(posNumNodes);
		}
		return returnNodes;
	}

	// ** Hibernate function 3
	/**
	 * Fetch child objects.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildObjects(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		Query query = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session damageCodeSession = null;
		try {
			// System.out
			// .println("Inside ** Hibernate Function 3 -> fetchChildObjectsHibernate ");
			String qry = formQryOfChildObjects(damageCodeVO, nodeVO, userVO);
			damageCodeSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			if (nodeVO.getLevel() == 1) {
				query = damageCodeSession.createSQLQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode() + "%");
			} else if (nodeVO.getLevel() == 2) {
				query = damageCodeSession.createSQLQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode() + "%");
			} else if (nodeVO.getLevel() == 3) {
				query = damageCodeSession.createSQLQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode());
			} else if (nodeVO.getLevel() == 4) {
				damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
				damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
				query = damageCodeSession.createSQLQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", damageCodeVO.getoBJCD1());
				query.setParameter("code2", damageCodeVO.getoBJCD2());
			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBROBJT.class)).list();

			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(true);
				if (nodeVO.getLevel() == 1) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 2) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 3) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD2());
				} else if (nodeVO.getLevel() == 4) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ UIUtil.formCodeOfNLength(
									((WSGLBROBJT) result.get(i)).getOBJCD2(), 1)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD3());
				}
				node.setLevel(nodeVO.getLevel() + 1);
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e024";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return nodeList;
	}

	// ** Inside Hibernate function 3_a
	/**
	 * Form qry of child objects.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildObjects(DamageCodeVO damageCodeVO,
			NodeVO nodeVO, UserVO userVO) {
		// System.out
		// .println("Inside ** Hibernate Function 3_a -> formQryOfChildObjectsHibernate ");
		String qry = "";
		// System.out.println("Try 9_F");
		if (nodeVO.getLevel() == 1) {
			qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM WSGLBROBJT OBJ WHERE OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
					+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,2)) FROM WSGLBRDAM DAM WHERE OBJCD1 like :code "
					+ "AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 2) {
			qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM WSGLBROBJT OBJ WHERE OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
					+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,3)) FROM WSGLBRDAM DAM WHERE OBJCD1 like :code AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 3) {
			qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM WSGLBROBJT OBJ WHERE OBJCD3 IS NULL AND SPRAS = :language "
					+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 = :code AND OBJCD2 IN (SELECT DISTINCT(SUBSTR(LABVAL,4,1)) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 4) {
			qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM WSGLBROBJT OBJ WHERE SPRAS = :language "
					+ "AND OBJCD1 = :code1 AND OBJCD2 = :code2  AND OBJCD3 IN "
					+ "(SELECT DISTINCT(SUBSTR(LABVAL,5,3)) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		}

		return qry;
	}

	// ** Inside Hibernate function 4
	/**
	 * Fetch ver locs.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchVerLocs(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session damageCodeSession = null;
		try {
			// System.out
			// .println("Inside ** Hibernate Function 4 -> fetchVerLocsHibernate ");
			String qry = formQryToFetchVerLocs(damageCodeVO, nodeVO, userVO);
			damageCodeSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = damageCodeSession.createSQLQuery(qry);
			if (nodeVO.getLevel() == 1 || nodeVO.getLevel() == 2
					|| nodeVO.getLevel() == 3) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode());
			} else if (nodeVO.getLevel() == 4) {
				damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
				damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", damageCodeVO.getoBJCD1());
				query.setParameter("code2", damageCodeVO.getoBJCD2());
			} else if (nodeVO.getLevel() == 5) {
				damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
				damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
				damageCodeVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", damageCodeVO.getoBJCD1());
				query.setParameter("code2", damageCodeVO.getoBJCD2());
				query.setParameter("code3", damageCodeVO.getoBJCD3());
			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBRVRST.class)).list();
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new VersionLocationVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 7)
						+ (((WSGLBRVRST) result.get(i)).getVERSION()));
				node.setLevel(nodeVO.getLevel());
				// if (isVersionLocationHavingChildNodes(damageCodeVO, node,
				// userVO)) {
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(true);
				// } else {
				// node.setHavingChildNodes(false);
				// }
				node.setName(((WSGLBRVRST) result.get(i)).getTEXT());
				nodeList.add(node);
			}

		} catch (Exception e) {
			errorCode = "e025";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return nodeList;
	}

	// ** modified for Hibernate function calls
	/**
	 * Checks if is version location having child nodes.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return true, if is version location having child nodes
	 * @throws EOIException
	 *             the eOI exception
	 */
	private boolean isVersionLocationHavingChildNodes(
			DamageCodeVO damageCodeVO, NodeVO nodeVO, UserVO userVO)
			throws EOIException {
		List result = fetchPosNum(damageCodeVO, nodeVO, userVO);
		if (result.size() > 0) {
			return true;
		}
		return false;
	}

	// ** Inside Hibernate function 5
	/**
	 * Fetch pos num.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchPosNum(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session damageCodeSession = null;
		try {
			// System.out
			// .println("Inside ** Hibernate Function 5 -> fetchPosNumHibernate ");
			damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			damageCodeVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
			damageCodeVO.setvERLOC(nodeVO.getCode().substring(7, 9).trim());
			String qry = formQryToFetchPosNum(damageCodeVO, nodeVO, userVO);
			damageCodeSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = damageCodeSession.createSQLQuery(qry);
			query.setParameter("language", userVO.getLanguage());
			query.setParameter("code1", damageCodeVO.getoBJCD1());
			query.setParameter("version", damageCodeVO.getvERLOC());
			if (nodeVO.getLevel() == 4) {
				query.setParameter("code2", damageCodeVO.getoBJCD2());
			} else if (nodeVO.getLevel() == 5) {
				query.setParameter("code2", damageCodeVO.getoBJCD2());
				query.setParameter("code3", damageCodeVO.getoBJCD3());
			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBRLOCT.class)).list();
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new PositionNumberVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 9)
						+ (((WSGLBRLOCT) result.get(i)).getLOCATION()));
				node.setLevel(nodeVO.getLevel());
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(false);
				node.setName(((WSGLBRLOCT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e026";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return nodeList;
	}

	// ** Inside hibernate function 5_a
	/**
	 * Form qry to fetch pos num.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryToFetchPosNum(DamageCodeVO damageCodeVO,
			NodeVO nodeVO, UserVO userVO) {
		// System.out
		// .println("Inside ** Hibernate Function 5_a -> formQryToFetchPosNumHibernate ");
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			qry = "SELECT DISTINCT LOCATION, TEXT FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND LOCATION IN (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 is null AND OBJCD3 is null AND VERSION = :version AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 2) {
			qry = "SELECT DISTINCT LOCATION, TEXT FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 is null AND OBJCD3 is null AND VERSION = :version AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 3) {
			qry = "SELECT DISTINCT LOCATION, TEXT FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 is null AND OBJCD3 is null AND VERSION = :version AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 4) {
			qry = "SELECT DISTINCT LOCATION, TEXT FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND OBJCD3 is null AND VERSION = :version AND DAM.PRCSTAT = 'A'"
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 5) {
			qry = "SELECT DISTINCT LOCATION, TEXT FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND OBJCD3 = :code3 AND VERSION = :version "
					+ "AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY LOCT.LOCATION";
		}
		return qry;
	}

	// ** Inside Hibernate function 4_a
	/**
	 * Form qry to fetch ver locs.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryToFetchVerLocs(DamageCodeVO damageCodeVO,
			NodeVO nodeVO, UserVO userVO) {
		// System.out
		// .println("Inside ** Hibernate Function 4_a -> formQryToFetchVerLocsHibernate ");
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			qry = "SELECT DISTINCT VERSION, TEXT FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND VERSION IN (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code "
					+ "AND OBJCD2 is null AND OBJCD3 is null AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 2) {
			qry = "SELECT DISTINCT VERSION, TEXT FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code "
					+ "AND OBJCD2 is null AND OBJCD3 is null AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 3) {
			qry = "SELECT DISTINCT VERSION, TEXT FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code "
					+ "AND OBJCD2 is null AND OBJCD3 is null AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 4) {
			qry = "SELECT DISTINCT VERSION, TEXT FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND OBJCD3 is null  AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 5) {
			qry = "SELECT DISTINCT VERSION, TEXT FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = :language "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND OBJCD3 = :code3 "
					+ "AND DAM.PRCSTAT = 'A' "
					+ "AND DAM.damage not like 'n%' AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%') "
					+ "ORDER BY VRST.VERSION";
		}
		return qry;
	}

	// ** Inside Hibernate function 6
	/**
	 * Fetch dmg search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session damageCodeSession = null;
		// BOC: Search not working for next page - 14.10.2015 - R4867
		searchText = searchText.replace("~","%");
		objectCode = objectCode.replace("~","%");
		// EOC: Search not working for next page - 14.10.2015 - R4867
		
		try {
			// System.out
			// .println("Inside ** Hibernate Function 6 -> fetchDMGSearchListHibernate ");
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchDMGSearchListCount(searchText, objectCode,
						userVO, paginationVO);
				LOGGER.error(qry);
				damageCodeSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = damageCodeSession.createSQLQuery(qry);
				/*Updated bY Prabhat On 26 June 2015 to solve Damage Code Search Issue*/
				/*searchText = searchText.replace("~","%");
				objectCode = objectCode.replace("~","%"); */
				query1.setParameter("searchText", searchText);
				/******/
				query1.setParameter("language", userVO.getLanguage());
				query1.setParameter("objectCode", objectCode);
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());

				qry = formQryToFetchDMGSearchList(searchText, objectCode,
						userVO, paginationVO);
				LOGGER.error(qry);
				Query query2 = damageCodeSession.createSQLQuery(qry);
				query2.setParameter("searchText", searchText);
				query2.setParameter("language", userVO.getLanguage());
				query2.setParameter("objectCode", objectCode);
				if (paginationVO.getCurrentPage() != 0) {
					query2.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query2.setParameter("endRowNum",
							paginationVO.getEndRowNum());
				}
				query2.setCacheable(true);
				query2.setCacheRegion("eoicatalog.ehcache");
				result = query2.setResultTransformer(
						Transformers.aliasToBean(WSGLBRDAM.class)).list();
			} else {
				qry = formQryToFetchDMGSearchList(searchText, objectCode,
						userVO, paginationVO);
				damageCodeSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = damageCodeSession.createSQLQuery(qry);
				query.setParameter("searchText", searchText);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("objectCode", objectCode);
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRDAM.class)).list();
			}
			List<DamageCodeVO> voList = new ArrayList<DamageCodeVO>();
			populateDMGDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e027";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return paginationVO;
	}

	/**
	 * Populate dmg data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateDMGDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			DamageCodeVO vo = new DamageCodeVO();
			vo.setoBJCD1(((WSGLBRDAM) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRDAM) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRDAM) result.get(i)).getOBJCD3());
			vo.setvERLOC(((WSGLBRDAM) result.get(i)).getVERSION());
			vo.setpOSNUM(((WSGLBRDAM) result.get(i)).getLOCATION());
			vo.setdEFECT(((WSGLBRDAM) result.get(i)).getDAMAGE());
			vo.setdAMAGECODE(((WSGLBRDAM) result.get(i)).getLABVAL());
			vo.settEXT(((WSGLBRDAM) result.get(i)).getTEXT());
			vo.setDamagetEXT(((WSGLBRDAM) result.get(i)).getDAMAGETEXT());
			voList.add(vo);
		}
	}

	// ** Inside Hibernate function 6_a
	/**
	 * Form qry to fetch dmg search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchDMGSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		// System.out
		// .println("Inside ** Hibernate Function 6_a -> formQryToFetchDMGSearchListHibernate ");
		String qry = "";
		qry = "Select ROWNUM R_NUM, DATA.* from (select DISTINCT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3, VER.VERSION, LOC.LOCATION, DAM.labval, "
				+ "DAM.DAMAGE, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END "
				+ "|| VER.Text || LOC.Text as text, DMGT.Text as damagetext  "
				+ "from WSGLBRDAM  DAM, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRVRST VER, WSGLBRLOCT LOC,WSGLBRDMGT DMGT "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.VERSION = VER.VERSION AND DAM.LOCATION = LOC.LOCATION AND DAM.damage not like 'n%' "
				+ "AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%' AND DAM.DAMAGE = DMGT.DAMAGE "
				+ "AND UPPER (CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || VER.Text || LOC.Text ||DMGT.Text) like UPPER(:searchText) AND DAM.PRCSTAT = 'A' "
				+ "AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND VER.PRCSTAT = 'A' AND LOC.PRCSTAT ='A' AND DMGT.PRCSTAT = 'A'"
				+ "AND O1.SPRAS = :language AND O2.SPRAS = :language AND O3.SPRAS = :language AND VER.SPRAS =:language AND LOC.SPRAS=:language "
				+ "AND DMGT.SPRAS = :language AND DAM.OBJCD1  || DAM.OBJCD2  || DAM.OBJCD3  like :objectCode order by labval) DATA";
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}

		return qry;
	}

	// ** Inside Hibernate function 6_a
	/**
	 * Form qry to fetch dmg search list count.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchDMGSearchListCount(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		
		String qry = "";
		qry = "Select COUNT(*) as TOTALCOUNT from (select DISTINCT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3, VER.VERSION, LOC.LOCATION, DAM.labval, "
				+ "DAM.DAMAGE, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END "
				+ "|| VER.Text || LOC.Text as text, DMGT.Text as damagetext  "
				+ "from WSGLBRDAM  DAM, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRVRST VER, WSGLBRLOCT LOC,WSGLBRDMGT DMGT "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.VERSION = VER.VERSION AND DAM.LOCATION = LOC.LOCATION AND DAM.damage not like 'n%' "
				+ "AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%' AND DAM.DAMAGE = DMGT.DAMAGE "
				+ "AND UPPER (CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || VER.Text || LOC.Text ||DMGT.Text) like UPPER(:searchText) AND DAM.PRCSTAT = 'A' "
				+ "AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND VER.PRCSTAT = 'A' AND LOC.PRCSTAT ='A' AND DMGT.PRCSTAT = 'A'"
				+ "AND O1.SPRAS = :language AND O2.SPRAS = :language AND O3.SPRAS = :language AND VER.SPRAS =:language AND LOC.SPRAS=:language "
				+ "AND DMGT.SPRAS = :language AND DAM.OBJCD1  || DAM.OBJCD2  || DAM.OBJCD3  like :objectCode order by labval) DATA"; 
		return qry;
	}

	/**
	 * Fetch dmg codes list for search defect field.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesListForSearchDefectField(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO nodeVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session damageCodeSession = null;
		try {
			// System.out
			// .println("Inside ** Hibernate Function 2 -> fetchDMGCodesListHibernate ");
			String qry = "";
			damageCodeVO.setoBJCD1("");
			damageCodeVO.setoBJCD2("");
			damageCodeVO.setoBJCD3("");

			if (null != damageCodeVO.getdAMAGECODE()) {
				if (damageCodeVO.getdAMAGECODE().length() >= 3) {
					damageCodeVO.setoBJCD1(damageCodeVO.getdAMAGECODE()
							.substring(0, 3));
				} else {
					damageCodeVO
							.setoBJCD1(damageCodeVO.getdAMAGECODE().substring(
									0, damageCodeVO.getdAMAGECODE().length()));
				}

				if (damageCodeVO.getdAMAGECODE().length() >= 4) {
					damageCodeVO.setoBJCD2(damageCodeVO.getdAMAGECODE()
							.substring(3, 4));
				}

				if (damageCodeVO.getdAMAGECODE().length() >= 5) {
					if (damageCodeVO.getdAMAGECODE().length() >= 7) {
						damageCodeVO.setoBJCD3(damageCodeVO.getdAMAGECODE()
								.substring(4, 7));
					} else {
						damageCodeVO.setoBJCD3(damageCodeVO.getdAMAGECODE()
								.substring(4,
										damageCodeVO.getdAMAGECODE().length()));
					}
				}
			} else {
				if (nodeVO.getCode().length() >= 3) {
					damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3));
				} else {
					damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0,
							nodeVO.getCode().length()));
				}

				if (nodeVO.getCode().length() >= 4) {
					damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4));
				}

				if (nodeVO.getCode().length() >= 5) {
					if (nodeVO.getCode().length() >= 7) {
						damageCodeVO
								.setoBJCD3(nodeVO.getCode().substring(4, 7));
					} else {
						damageCodeVO.setoBJCD3(nodeVO.getCode().substring(4,
								nodeVO.getCode().length()));
					}
				}
			}
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryforSearchCount(userVO, damageCodeVO, nodeVO,
						paginationVO);
				damageCodeSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = damageCodeSession.createSQLQuery(qry);
				if (!damageCodeVO.getoBJCD1().trim().equals("")) {
					query1.setParameter("objcd1", damageCodeVO.getoBJCD1()
							.trim());
				}
				if (!damageCodeVO.getoBJCD2().trim().equals("")) {
					query1.setParameter("objcd2", damageCodeVO.getoBJCD2()
							.trim());
				}
				if (!damageCodeVO.getoBJCD3().trim().equals("")) {
					query1.setParameter("objcd3", damageCodeVO.getoBJCD3()
							.trim());
				}
				query1.setParameter("language", userVO.getLanguage());
				// query1.setParameter("damageCodeVO",
				// damageCodeVO.getdAMAGECODE());
				if (null != damageCodeVO.getdAMAGECODE()) {
					query1.setParameter("labval", damageCodeVO.getdAMAGECODE()
							.trim());
				} else {
					query1.setParameter("node", nodeVO.getCode().trim() + "%");
					// query1.setParameter("labval", "");
				}
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());

				qry = formQryforSearch(userVO, damageCodeVO, nodeVO,
						paginationVO);
				Query query2 = damageCodeSession.createSQLQuery(qry);
				if (!damageCodeVO.getoBJCD1().trim().equals("")) {
					query2.setParameter("objcd1", damageCodeVO.getoBJCD1()
							.trim());
				}
				if (!damageCodeVO.getoBJCD2().trim().equals("")) {
					query2.setParameter("objcd2", damageCodeVO.getoBJCD2()
							.trim());
				}
				if (!damageCodeVO.getoBJCD3().trim().equals("")) {
					query2.setParameter("objcd3", damageCodeVO.getoBJCD3()
							.trim());
				}
				query2.setParameter("language", userVO.getLanguage());
				// query2.setParameter("node", nodeVO.getCode().trim() + "%");
				// query2.setParameter("damageCodeVO",
				// damageCodeVO.getdAMAGECODE());
				if (null != damageCodeVO.getdAMAGECODE()) {
					query2.setParameter("labval", damageCodeVO.getdAMAGECODE()
							.trim());
				} else {
					query2.setParameter("node", nodeVO.getCode().trim() + "%");
					// query2.setParameter("labval", "");
				}
				if (paginationVO.getCurrentPage() != 0) {
					query2.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query2.setParameter("endRowNum",
							paginationVO.getEndRowNum());
				}
				query2.setCacheable(true);
				query2.setCacheRegion("eoicatalog.ehcache");
				result = query2.setResultTransformer(
						Transformers.aliasToBean(WSGLBRDAM.class)).list();
			} else {
				qry = formQryforSearch(userVO, damageCodeVO, nodeVO,
						paginationVO);
				damageCodeSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = damageCodeSession.createSQLQuery(qry);
				if (!damageCodeVO.getoBJCD1().trim().equals("")) {
					query.setParameter("objcd1", damageCodeVO.getoBJCD1()
							.trim());
				}
				if (!damageCodeVO.getoBJCD2().trim().equals("")) {
					query.setParameter("objcd2", damageCodeVO.getoBJCD2()
							.trim());
				}
				if (!damageCodeVO.getoBJCD3().trim().equals("")) {
					query.setParameter("objcd3", damageCodeVO.getoBJCD3()
							.trim());
				}
				query.setParameter("language", userVO.getLanguage());
				// query.setParameter("node", nodeVO.getCode().trim() + "%");
				// query.setParameter("damageCodeVO",
				// damageCodeVO.getdAMAGECODE());
				if (null != damageCodeVO.getdAMAGECODE()) {
					query.setParameter("labval", damageCodeVO.getdAMAGECODE()
							.trim());
				} else {
					query.setParameter("node", nodeVO.getCode().trim() + "%");
					// query.setParameter("labval", "");
				}
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRDAM.class)).list();
			}
			List<DamageCodeVO> voList = new ArrayList<DamageCodeVO>();
			populateDamageCodeVO(result, voList);
			paginationVO.setRows(voList);
		} catch (Exception e) {
			errorCode = "e028";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return paginationVO;
	}

	/**
	 * Form qryfor search.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryforSearch(UserVO userVO, DamageCodeVO damageCodeVO,
			NodeVO node, PaginationVO paginationVO) {
		String qry = "";

		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3,DAM.VERSION,DAM.LOCATION,DAM.DAMAGE,DAM.LABVAL, "
				+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END "
				+ "|| ' ' || V.TEXT || ' ' ||L.TEXT || ' ' || DMGT.TEXT AS TEXT "
				+ "FROM WSGLBRDAM DAM, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L,WSGLBRVRST V, WSGLBRDMGT DMGT  "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.LOCATION = L.LOCATION AND DAM.VERSION = V.VERSION "
				+ "AND DAM.DAMAGE = DMGT.DAMAGE AND DAM.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND V.PRCSTAT = 'A'  AND DMGT.PRCSTAT = 'A' "
				+ "AND O1.SPRAS = "
				+ ":language"
				+ " AND O2.SPRAS = "
				+ ":language"
				+ " "
				+ "AND O3.SPRAS = "
				+ ":language"
				+ " AND L.SPRAS = "
				+ ":language"
				+ " "
				+ "AND V.SPRAS = "
				+ ":language"
				+ " AND DMGT.SPRAS = "
				+ ":language"
				+ " "
				+ "AND LABVAL LIKE "
				+ ((null != damageCodeVO.getdAMAGECODE()) ? ":labval" : ":node")
				+ " AND "
				+ (damageCodeVO.getoBJCD1().trim().equals("") ? "DAM.OBJCD1 IS NULL "
						: "DAM.OBJCD1 = :objcd1 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD2().trim().equals("") ? "DAM.OBJCD2 IS NULL "
						: "DAM.OBJCD2 = :objcd2 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD3().trim().equals("") ? "DAM.OBJCD3 IS NULL "
						: "DAM.OBJCD3 = :objcd3 ") + "ORDER BY LABVAL) DATA ";

		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	/**
	 * Form qry for search count.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryforSearchCount(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO node, PaginationVO paginationVO) {
		String qry = "";

		qry = "SELECT COUNT(*) as TOTALCOUNT FROM (SELECT DISTINCT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3,DAM.VERSION,DAM.LOCATION,DAM.DAMAGE,DAM.LABVAL, "
				+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END "
				+ "|| ' ' || V.TEXT || ' ' ||L.TEXT || ' ' || DMGT.TEXT AS TEXT "
				+ "FROM WSGLBRDAM DAM, WSGLBROBJT O1, WSGLBROBJT O2, WSGLBROBJT O3, WSGLBRLOCT L,WSGLBRVRST V, WSGLBRDMGT DMGT  "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.LOCATION = L.LOCATION AND DAM.VERSION = V.VERSION "
				+ "AND DAM.DAMAGE = DMGT.DAMAGE AND DAM.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND V.PRCSTAT = 'A'  AND DMGT.PRCSTAT = 'A' "
				+ "AND O1.SPRAS = "
				+ ":language"
				+ " AND O2.SPRAS = "
				+ ":language"
				+ " "
				+ "AND O3.SPRAS = "
				+ ":language"
				+ " AND L.SPRAS = "
				+ ":language"
				+ " "
				+ "AND V.SPRAS = "
				+ ":language"
				+ " AND DMGT.SPRAS = "
				+ ":language"
				+ " "
				+ "AND LABVAL LIKE "
				+ ((null != damageCodeVO.getdAMAGECODE()) ? ":labval" : ":node")
				+ " AND "
				+ (damageCodeVO.getoBJCD1().trim().equals("") ? "DAM.OBJCD1 IS NULL "
						: "DAM.OBJCD1 = :objcd1 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD2().trim().equals("") ? "DAM.OBJCD2 IS NULL "
						: "DAM.OBJCD2 = :objcd2 ")
				+ "AND "
				+ (damageCodeVO.getoBJCD3().trim().equals("") ? "DAM.OBJCD3 IS NULL "
						: "DAM.OBJCD3 = :objcd3 ") + "ORDER BY LABVAL) DATA ";

		return qry;
	}

	public boolean fetchValidSearch(UserVO userVO, String searchText,
			Integer textBoxId) throws EOIException {
		List result = null;
		String qry = "";
		Session damageCodeSession = null;
		try {
			switch (textBoxId) {
			case 2:
				qry = "SELECT VERSION FROM WSGLBRVRST WHERE VERSION =:searchText and SPRAS = :language";
				break;
			case 3:
				qry = "SELECT LOCATION FROM WSGLBRLOCT WHERE LOCATION =:searchText and SPRAS = :language";
				break;
			case 4:
				qry = "SELECT DAMAGE FROM WSGLBRDMGT WHERE DAMAGE =:searchText and SPRAS = :language";
				break;
			}
			damageCodeSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = damageCodeSession.createQuery(qry);
			query.setParameter("searchText", searchText);
			query.setParameter("language", userVO.getLanguage());
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
		} catch (Exception e) {
			errorCode = "e546";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		if (result.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO,
			NodeVO nodeVO) throws EOIException {
		List result = null;
		Session damageCodeSession = null;
		try {
			// System.out.println("Inside ** Hibernate Function 1 -> isValidObjCodeHibernate ");
			String code = nodeVO.getCode();
			String qry = "SELECT LABVAL FROM WSGLBRDAM WHERE PRCSTAT = 'A' AND LABVAL like :code "
					+ "AND damage not like 'n%' AND damage not like 'N%' AND damage not like 'r%' AND damage not like 'R%' ";
			damageCodeSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = damageCodeSession.createSQLQuery(qry);
			query.setParameter("code", code + "%");
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			if (result.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			errorCode = "e002";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return false;
	}

	public boolean isValidObjWithDefectRN(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		List result = null;
		Session damageCodeSession = null;
		try {
			// System.out.println("Inside ** Hibernate Function 1 -> isValidObjCodeHibernate ");
			String code = nodeVO.getCode();
			String qry = "SELECT LABVAL FROM WSGLBRDAM WHERE PRCSTAT = 'A' AND LABVAL like :code ";
			damageCodeSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = damageCodeSession.createSQLQuery(qry);
			query.setParameter("code", code + "%");
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			if (result.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			errorCode = "e002";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (damageCodeSession != null) {
				damageCodeSession.close();
			}
		}
		return false;
	}

	public DamageCodeVO fetchMostValidDCAttributes(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {

		DamageCodeVO rtndamageCodeVO = new DamageCodeVO();
		rtndamageCodeVO.setoBJCD1("");
		rtndamageCodeVO.setoBJCD2("");
		rtndamageCodeVO.setoBJCD3("");
		rtndamageCodeVO.setvERLOC("");
		rtndamageCodeVO.setpOSNUM("");
		rtndamageCodeVO.setdEFECT("");
		rtndamageCodeVO.setdAMAGECODE("");
		boolean individualFieldIsValid = true;
		DamageCodeVO tempDamageCodeVO = new DamageCodeVO();
		ObjectCodeVO tempNodeVO = new ObjectCodeVO();

		tempNodeVO
				.setCode((UIUtil.formCodeOfNLength(damageCodeVO.getoBJCD1(), 3)
						+ UIUtil.formCodeOfNLength(damageCodeVO.getoBJCD2(), 1)
						+ UIUtil.formCodeOfNLength(damageCodeVO.getoBJCD3(), 3)
						+ UIUtil.formCodeOfNLength(damageCodeVO.getvERLOC(), 2)
						+ UIUtil.formCodeOfNLength(damageCodeVO.getpOSNUM(), 2) + UIUtil
						.formCodeOfNLength(damageCodeVO.getdEFECT(), 2))
						.replaceAll("\\s+$", ""));

		if (isValidObjCode(userVO, tempDamageCodeVO, tempNodeVO)) {
			// rtndamageCodeVO.setdAMAGECODE(tempNodeVO.getCode());
			rtndamageCodeVO.setoBJCD1(damageCodeVO.getoBJCD1());
			rtndamageCodeVO.setoBJCD2(damageCodeVO.getoBJCD2());
			rtndamageCodeVO.setoBJCD3(damageCodeVO.getoBJCD3());
			rtndamageCodeVO.setvERLOC(damageCodeVO.getvERLOC());
			rtndamageCodeVO.setpOSNUM(damageCodeVO.getpOSNUM());
			rtndamageCodeVO.setdEFECT(damageCodeVO.getdEFECT());
			return rtndamageCodeVO;

		} else {
			// check if defect code is valid

			if (damageCodeVO.getdEFECT().length() > 0) {
				// tempNodeVO.setCode(damageCodeVO.getdEFECT());
				// check valid defect code
				if (fetchValidSearch(userVO, damageCodeVO.getdEFECT(),
						UIConstants.DCView.DEFECTTEXTBOXID)) {
					// valid defect
					rtndamageCodeVO.setdEFECT(damageCodeVO.getdEFECT());
				} else {
					// Invalid defect code
					individualFieldIsValid = false;
					rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO
							.getdAMAGECODE() + ",e539");
					// rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE().substring(1));
					// return rtndamageCodeVO;
				}

			}
			if (damageCodeVO.getpOSNUM().length() > 0 && individualFieldIsValid) {
				// check valid posNo code
				if (fetchValidSearch(userVO, damageCodeVO.getpOSNUM(),
						UIConstants.DCView.PNTEXTBOXID)) {
					// valid posno
					rtndamageCodeVO.setpOSNUM(damageCodeVO.getpOSNUM());
				} else {
					// Invalid posNo code
					individualFieldIsValid = false;
					rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO
							.getdAMAGECODE() + ",e538");
					// rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE().substring(1));
					// return rtndamageCodeVO;
				}
			}
			if (damageCodeVO.getvERLOC().length() > 0 && individualFieldIsValid) {
				// check valid verLoc code
				if (fetchValidSearch(userVO, damageCodeVO.getvERLOC(),
						UIConstants.DCView.VLTEXTBOXID)) {
					// valid verLoc
					rtndamageCodeVO.setvERLOC(damageCodeVO.getvERLOC());
				} else {
					// Invalid verLoc code
					individualFieldIsValid = false;
					rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO
							.getdAMAGECODE() + ",e537");
					// rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE().substring(1));
					// return rtndamageCodeVO;
				}
			}
			if ((damageCodeVO.getoBJCD1() + damageCodeVO.getoBJCD2() + damageCodeVO
					.getoBJCD3()).length() > 0) {
				tempNodeVO.setCode((damageCodeVO.getoBJCD1()
						+ damageCodeVO.getoBJCD2() + damageCodeVO.getoBJCD3())
						.trim());
				DamageCodeVO checkedObjCodeDC = fetchValidObjCode(userVO,
						tempDamageCodeVO, tempNodeVO);
				if ((checkedObjCodeDC.getoBJCD1()
						+ checkedObjCodeDC.getoBJCD2() + checkedObjCodeDC
						.getoBJCD3()).trim().length() > 0) {
					if (((checkedObjCodeDC.getoBJCD1()
							+ checkedObjCodeDC.getoBJCD2() + checkedObjCodeDC
							.getoBJCD3()).trim())
							.equalsIgnoreCase((damageCodeVO.getoBJCD1()
									+ damageCodeVO.getoBJCD2() + damageCodeVO
									.getoBJCD3()).trim())) {
						// Full Valid code
					} else {
						// partial valid code
						rtndamageCodeVO.setoBJCD1(checkedObjCodeDC.getoBJCD1());
						rtndamageCodeVO.setoBJCD2(checkedObjCodeDC.getoBJCD2());
						rtndamageCodeVO.setoBJCD3(checkedObjCodeDC.getoBJCD3());
						rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO
								.getdAMAGECODE() + ",e536");
						if (individualFieldIsValid) {
							individualFieldIsValid = false;
							tempNodeVO
									.setCode((UIUtil.formCodeOfNLength(
											rtndamageCodeVO.getoBJCD1(), 3)
											+ UIUtil.formCodeOfNLength(
													rtndamageCodeVO.getoBJCD2(),
													1)
											+ UIUtil.formCodeOfNLength(
													rtndamageCodeVO.getoBJCD3(),
													3)
											+ UIUtil.formCodeOfNLength(
													damageCodeVO.getvERLOC(), 2)
											+ UIUtil.formCodeOfNLength(
													damageCodeVO.getpOSNUM(), 2) + UIUtil
											.formCodeOfNLength(
													damageCodeVO.getdEFECT(), 2))
											.replaceAll("\\s+$", ""));

							if (isValidObjCode(userVO, tempDamageCodeVO,
									tempNodeVO)) {
								// With Processed Obj code the combination is
								// valid
							} else {
								rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO
										.getdAMAGECODE() + ",e540");
							}
						}
						// rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE().substring(1));
						// return rtndamageCodeVO;
					}
				} else {
					// Invalid Object Code
					individualFieldIsValid = false;
					rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO
							.getdAMAGECODE() + ",e535");
					// rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE().substring(1));
					// return rtndamageCodeVO;
				}
			}
			if (individualFieldIsValid) {
				rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE()
						+ ",e540");
			}

			if (rtndamageCodeVO.getdAMAGECODE().length() > 0
					&& rtndamageCodeVO.getdAMAGECODE().indexOf(",") == 0) {
				rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE()
						.substring(1));
			}
			// if (individualFieldIsValid) {
			// rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE() +
			// ",e540");
			// rtndamageCodeVO.setdAMAGECODE(rtndamageCodeVO.getdAMAGECODE().substring(1));
			// }
		}
		return rtndamageCodeVO;
	}

	public DamageCodeVO fetchValidObjCode(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		damageCodeVO.setoBJCD1(objCD1);
		damageCodeVO.setoBJCD2(objCD2);
		damageCodeVO.setoBJCD3(objCD3);
		try {
			while (nodeVO.getCode().length() > 0) {
				if (isValidObjCode(userVO, damageCodeVO, nodeVO)) {
					String nodeCode = nodeVO.getCode();
					if (nodeCode.length() >= 3) {
						objCD1 = nodeCode.substring(0, 3);
					} else {
						objCD1 = nodeCode.substring(0, nodeCode.length());
					}

					if (nodeCode.length() >= 4) {
						objCD2 = nodeCode.substring(3, 4);
					}

					if (nodeCode.length() >= 5) {
						objCD3 = nodeCode.substring(4, nodeCode.length());
					}
					damageCodeVO.setoBJCD1(objCD1);
					damageCodeVO.setoBJCD2(objCD2);
					damageCodeVO.setoBJCD3(objCD3);
					return damageCodeVO;
				} else {
					nodeVO.setCode(nodeVO.getCode().substring(0,
							(nodeVO.getCode().length() - 1)));
				}
			}
		} catch (Exception e) {
			errorCode = "e001";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return damageCodeVO;
	}
}
