/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.service.rpc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import de.man.mn.esa.eoicatalog.laborvalue.facade.ILaborValFacade;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchChildVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchMostValidWPAttributesVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchSearchVO;
import de.man.mn.esa.eoicatalog.share.common.vo.LVNodeSearchResultVO;
import de.man.mn.esa.eoicatalog.share.common.vo.LVNodeSearchVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.RangeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

/**
 * The Class IRemoteLaborValServlet.
 * 
 * Author: Yuvraj Patil
 */
@RestController
@RequestMapping("/laborval")
@CrossOrigin
public class IRemoteLaborValServlet  {
	
    @Autowired
    private ILaborValFacade facade;
	
	private static final Logger LOGGER = Logger.getLogger(IRemoteLaborValServlet.class);

	/** The Constant LABVALFACADE. */
	//private static final String LABVALFACADE = "laborValueFacade";


	/**
	 * Fetch valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the work process vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchValidObjCode", method = RequestMethod.POST, headers = "Accept=application/json")
	public WorkProcessVO fetchValidObjCode(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		return facade.fetchValidObjCode(userVO, workProcessVO, nodeVO);
	}

	/**
	 * Checks if is valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid obj code
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		return facade.isValidObjCode(userVO, workProcessVO, nodeVO);
	}

	/**
	 * Checks if is valid wp attribute combination.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid wp attribute combination
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidWPAttributeCombination(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		return facade.isValidWPAttributeCombination(userVO, workProcessVO,
				nodeVO);
	}

	/**
	 * Fetch range list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchRangeList", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<RangeVO> fetchRangeList(@RequestBody RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		return facade.fetchRangeList(rangeVO, userVO);
	}

	/**
	 * Fetch unit.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchUnit", method = RequestMethod.GET, headers = "Accept=application/json")
	public String fetchUnit(@RequestBody UserVO userVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		return facade.fetchUnit(userVO);
	}

	/**
	 * Fetch variant list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchVariantList", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<RangeVO> fetchVariantList(@RequestBody RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		return facade.fetchVariantList(rangeVO, userVO);
	}

	/**
	 * Fetch root nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchRootNodes", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<NodeVO> fetchRootNodes(@RequestBody UserVO userVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		//MailSender mailSender = new MailSender();
		//MailConfiguration mailConfiguration = (MailConfiguration)getContextService("mailConfiguration");
		//mailSender.sendMail(mailConfiguration, "subject", "message_body");
		Long inTime = System.currentTimeMillis();
		List nodeVOList = facade.fetchRootNodes(userVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 10){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch root nodes in stipulated time period for Labor Value Catalog");
		}
		return nodeVOList;
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchChildNodes", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<NodeVO> fetchChildNodes(@RequestBody FetchChildVO fetchChildVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		//List<NodeVO> nodeVOList = new List<NodeVO>(); 
		List<NodeVO> nodeVOList = facade.fetchChildNodes(fetchChildVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 2){
			LOGGER.error("User Name: " + fetchChildVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch child nodes in stipulated time period for Labor Value Catalog");
		}
		return nodeVOList;
	}

	/**
	 * Fetch wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchWPList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchWPList(@RequestBody FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchWPList(fetchMostValidWPAttributesVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3 && pagination.getTotalRecords()< 30){
			LOGGER.error("User Name: " + fetchMostValidWPAttributesVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch labor value list for tabulation section in stipulated time period for Labor Value Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchIncludedWPList", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<WorkProcessVO> fetchIncludedWPList(@RequestBody FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		List wpList = facade.fetchIncludedWPList(fetchMostValidWPAttributesVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchMostValidWPAttributesVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch included work process list in stipulated time period for Labor Value Catalog");
		}
		return wpList;
	}

	/**
	 * Fetch wp search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchWPSearchList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchWPSearchList(@RequestBody FetchSearchVO fetchSearchVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		LOGGER.info("Received message to fetch work processes at RPC Servlet");
		LOGGER.info("Received Searchtext in IremoteLabourValServ (fetchWPSearchList)Is"+fetchSearchVO.getSearchText());
		LOGGER.info("Received ObjectCodes in IremoteLabourValServ (fetchObjectSearchList)Is"+fetchSearchVO.getCode());
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchWPSearchList(fetchSearchVO.getSearchText(), fetchSearchVO.getCode(), fetchSearchVO.getUserVO(),
				fetchSearchVO.getPaginationVO());
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchSearchVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch work process search list in stipulated time period for Labor Value Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch language.
	 * 
	 * @param spras
	 *            the spras
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchLanguage", method = RequestMethod.GET, headers = "Accept=application/json")
	public String fetchLanguage(@RequestBody String spras) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		return facade.fetchLanguage(spras);
	}

	/**
	 * Fetch object search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchObjectSearchList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchObjectSearchList(@RequestBody FetchSearchVO fetchSearchVO)
			throws EOIException {
		LOGGER.info("Received message to fetch objectcode at RPC Servlet");
		LOGGER.info("Received Searchtext in IremoteLabourValServ (fetchObjectSearchList)Is"+fetchSearchVO.getSearchText());
		
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchObjectSearchList(fetchSearchVO.getSearchText(), fetchSearchVO.getCode(), fetchSearchVO.getUserVO(),
				fetchSearchVO.getPaginationVO());
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchSearchVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch object search list in stipulated time period for Labor Value Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch activity search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchActivitySearchList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchActivitySearchList(@RequestBody FetchSearchVO fetchSearchVO)
			throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchActivitySearchList(fetchSearchVO.getSearchText(), fetchSearchVO.getCode(), fetchSearchVO.getUserVO(),
				fetchSearchVO.getPaginationVO());
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchSearchVO.getUserVO() .getUserID() + "\n\nMessage: Not able to fetch activity search list in stipulated time period for Labor Value Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch version search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchVersionSearchList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchVersionSearchList(@RequestBody FetchSearchVO fetchSearchVO)
			throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchVersionSearchList(fetchSearchVO.getSearchText(), fetchSearchVO.getCode(), fetchSearchVO.getUserVO(),
				fetchSearchVO.getPaginationVO());
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchSearchVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch version search list in stipulated time period for Labor Value Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch location search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchLocationSearchList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchLocationSearchList(@RequestBody FetchSearchVO fetchSearchVO)
			throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchLocationSearchList(fetchSearchVO.getSearchText(), fetchSearchVO.getCode(), fetchSearchVO.getUserVO(),
				fetchSearchVO.getPaginationVO());
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchSearchVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch location search list in stipulated time period for Labor Value Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch condition search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchConditionSearchList", method = RequestMethod.POST, headers = "Accept=application/json")
	public PaginationVO fetchConditionSearchList(@RequestBody FetchSearchVO fetchSearchVO)
			throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		PaginationVO pagination = facade.fetchConditionSearchList(fetchSearchVO.getSearchText(), fetchSearchVO.getCode(),
				fetchSearchVO.getUserVO(), fetchSearchVO.getPaginationVO());
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchSearchVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch condition search list in stipulated time period for Labor Value Catalog");
		}
		return pagination;
	}

	/**
	 * Fetch not included wp with details list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the hash map
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/fetchNotIncludedWPWithDetailsList", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<WorkProcessVO> fetchNotIncludedWPWithDetailsList(@RequestBody FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		List<WorkProcessVO> workProcessVOs = facade.fetchNotIncludedWPWithDetailsList(fetchMostValidWPAttributesVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + fetchMostValidWPAttributesVO.getUserVO().getUserID() + "\n\nMessage: Not able to fetch not included work process list in stipulated time period for Labor Value Catalog");
		}
		return workProcessVOs;
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param nodeSearchVO
	 *            the node search vo
	 * @param userVO
	 *            the user vo
	 * @return the lV node search result vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	/*@RequestMapping(value = "/fetchChildNodesForSearch", method = RequestMethod.GET, headers = "Accept=application/json")
	public LVNodeSearchResultVO fetchChildNodesForSearch(@RequestBody LVNodeSearchVO nodeSearchVO,
			UserVO userVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		List<NodeVO> nodeList = null;
		LVNodeSearchResultVO resultVO = new LVNodeSearchResultVO();
		resultVO.setLevel(nodeSearchVO.getLevel());
		WorkProcessVO workProcessVO = new WorkProcessVO();
		FetchChildVO fetchChildVO = new FetchChildVO();
		fetchChildVO.setNodeVO(nodeSearchVO.getNodeVO());
		fetchChildVO.setWorkProcessVO(workProcessVO);
		fetchChildVO.setUserVO(userVO);
		nodeList = facade.fetchChildNodes(fetchChildVO);
		resultVO.setNodeVOList(nodeList);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 2){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch child nodes in stipulated time period for Labor Value Catalog");
		}
		return resultVO;
	}
*/
	/**
	 * Checks if is wP having not included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is wP having not included wp list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@RequestMapping(value = "/isWPHavingNotIncludedWPList", method = RequestMethod.GET, headers = "Accept=application/json")
	public boolean isWPHavingNotIncludedWPList(@RequestBody UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		//ILaborValFacade facade = (ILaborValFacade) getContextService(LABVALFACADE);
		Long inTime = System.currentTimeMillis();
		boolean rtnValue = facade
				.isWPHavingNotIncludedWPList(userVO, workProcessVO, nodeVO);
		Long outTime = System.currentTimeMillis();
		Long totalMilliSecsForProcessing = (outTime - inTime);
		if((totalMilliSecsForProcessing/1000) > 3){
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: Not able to fetch not included work process list in stipulated time period for Labor Value Catalog");
		}
		return rtnValue;
	}
	/**
	 * Is valid search.
	 * 
	 * @param text
	 *            the text
	 * @return true, if successful
	 * @throws EOIException 
	 */
	@RequestMapping(value = "/isValidSearch", method = RequestMethod.GET, headers = "Accept=application/json")
	public boolean isValidSearch(@RequestBody UserVO userVO, String text, Integer textId) throws EOIException {
		// TODO Auto-generated method stub
		return facade.isValidSearch(userVO,text,textId);
	}

	/**
	 * @param userVO
	 * @param text
	 * @param tableName
	 * @param textId
	 * @return
	 */
	@RequestMapping(value = "/fetchCodeText", method = RequestMethod.GET, headers = "Accept=application/json")
	public String fetchCodeText(@RequestBody UserVO userVO, String text,Integer textId)
			throws EOIException {
		return facade.fetchCodeText(userVO, text, textId);
	}
	
	@RequestMapping(value = "/fetchMostValidWPAttributes", method = RequestMethod.POST, headers = "Accept=application/json")
	public WorkProcessVO fetchMostValidWPAttributes(@RequestBody FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) 
		throws EOIException {
		return facade.fetchMostValidWPAttributes(fetchMostValidWPAttributesVO);
	}

}
