/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

/**
 * The Class NodeVO.
 * 
 * Author: Aathavan Sivasubramonian
 */
public class NodeVO extends BaseVO implements INode {

	/**
	 * Instantiates a new node vo.
	 */
	public NodeVO() {

	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8208420521535912143L;

	/** The type. */
	private int type;

	/** The code. */
	private String code;

	/** The text. */
	private String name;

	/** The tool tip text. */
	private String toolTipText;

	/** The level. */
	private int level;

	/** The is having child nodes. */
	private boolean hasChildren;

	/** The child nodes have been fetched. */
	private boolean childNodesHaveBeenFetched;
	
	private List<NodeVO> children;

	/**
	 * Gets the type.
	 * 
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * Sets the type.
	 * 
	 * @param type
	 *            the new type
	 */
	protected void setType(int type) {
		this.type = type;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the code.
	 * 
	 * @param code
	 *            the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Gets the text.
	 * 
	 * @return the text
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the text.
	 * 
	 * @param text
	 *            the new text
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the level.
	 * 
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * Sets the level.
	 * 
	 * @param level
	 *            the new level
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * Checks if is having child nodes.
	 * 
	 * @return true, if is having child nodes
	 */
	public boolean isHasChildren() {
		return hasChildren;
	}

	/**
	 * Sets the having child nodes.
	 * 
	 * @param isHavingChildNodes
	 *            the new having child nodes
	 */
	public void setHasChildren(boolean hasChildren) {
		this.hasChildren = hasChildren;
	}

	/**
	 * Checks if is child nodes have been fetched.
	 * 
	 * @return true, if is child nodes have been fetched
	 */
	public boolean isChildNodesHaveBeenFetched() {
		return childNodesHaveBeenFetched;
	}

	/**
	 * Sets the child nodes have been fetched.
	 * 
	 * @param childNodesHaveBeenFetched
	 *            the new child nodes have been fetched
	 */
	public void setChildNodesHaveBeenFetched(boolean childNodesHaveBeenFetched) {
		this.childNodesHaveBeenFetched = childNodesHaveBeenFetched;
	}

	/**
	 * Gets the tool tip text.
	 * 
	 * @return the tool tip text
	 */
	public String getToolTipText() {
		return toolTipText;
	}

	/**
	 * Sets the tool tip text.
	 * 
	 * @param toolTipText
	 *            the new tool tip text
	 */
	public void setToolTipText(String toolTipText) {
		this.toolTipText = toolTipText;
	}
    /**
     * 
     * @return
     */
	public List<NodeVO> getChildren() {
		return children;
	}

	/**
	 * 
	 * @param children
	 */
	public void setChildren(List<NodeVO> children) {
		this.children = children;
	}

}
