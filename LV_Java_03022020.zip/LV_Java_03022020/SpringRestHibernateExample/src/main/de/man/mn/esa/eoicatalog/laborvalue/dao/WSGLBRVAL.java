/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */

package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class WSGLBRVAL.
 * 
 * Author: Yuvraj Patil
 */
@Entity
@Table(name = "WSGLBRVAL")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class WSGLBRVAL implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The LABVAL. */
	@Id
	@Column(name = "LABVAL")
	private String LABVAL; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The RANGE. */
	@Column(name = "RANGE")
	private String RANGE; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The LB r_ variant. */
	@Column(name = "LBR_VARIANT")
	private String LBR_VARIANT; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d1. */
	@Column(name = "OBJCD1")
	private String OBJCD1; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d2. */
	@Column(name = "OBJCD2")
	private String OBJCD2; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The OBJC d3. */
	@Column(name = "OBJCD3")
	private String OBJCD3; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The VERSION. */
	@Column(name = "VERSION")
	private String VERSION; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The LOCATION. */
	@Column(name = "LOCATION")
	private String LOCATION; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The INSTAL l_ con. */
	@Column(name = "INSTALL_CON")
	private String INSTALL_CON; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The ACTIVITY. */
	@Column(name = "ACTIVITY")
	private String ACTIVITY; // NOPMD by yuvraj_patil01 on 3/19/11 10:52 AM

	/** The JOBTYPE. */
	@Column(name = "JOBTYPE")
	private String JOBTYPE; // NOPMD by yuvraj_patil01 on 3/19/11 10:52 AM

	/** The LB r_ value. */
	@Column(name = "LBR_VALUE")
	private String LBR_VALUE; // NOPMD by yuvraj_patil01 on 3/19/11 10:52 AM

	/** The PRCSTAT. */
	@Column(name = "PRCSTAT")
	private String PRCSTAT; // NOPMD by yuvraj_patil01 on 3/19/11 10:52 AM

	/** The R_ num. */
	private BigDecimal R_NUM; // NOPMD by yuvraj_patil01 on 3/19/11 10:52 AM

	/** The TEXT. */
	private String TEXT; // NOPMD by yuvraj_patil01 on 3/19/11 10:52 AM

	/** The TX t_ type. */
	private String TXT_TYPE; // NOPMD by yuvraj_patil01 on 3/19/11 10:52 AM

	/** The N o_ o f_ includedwp. */
	private BigDecimal NO_OF_INCLUDEDWP; // NOPMD by yuvraj_patil01 on 3/19/11
											// 10:53 AM

	/** The N o_ o f_ notincludedwp. */
	private BigDecimal NO_OF_NOTINCLUDEDWP; // NOPMD by yuvraj_patil01 on
											// 3/19/11 10:53 AM

	/**
	 * Gets the rANGE.
	 * 
	 * @return the rANGE
	 */
	public String getRANGE() {
		return RANGE;
	}

	/**
	 * Sets the rANGE.
	 * 
	 * @param rANGE
	 *            the new rANGE
	 */
	public void setRANGE(String rANGE) {
		RANGE = rANGE;
	}

	/**
	 * Gets the lB r_ variant.
	 * 
	 * @return the lB r_ variant
	 */
	public String getLBR_VARIANT() { // NOPMD by yuvraj_patil01 on 3/19/11 10:50
										// AM
		return LBR_VARIANT;
	}

	/**
	 * Sets the lB r_ variant.
	 * 
	 * @param lBR_VARIANT
	 *            the new lB r_ variant
	 */
	public void setLBR_VARIANT(String lBR_VARIANT) { // NOPMD by yuvraj_patil01
														// on 3/19/11 10:50 AM
		LBR_VARIANT = lBR_VARIANT;
	}

	/**
	 * Gets the oBJC d1.
	 * 
	 * @return the oBJC d1
	 */
	public String getOBJCD1() {
		return OBJCD1;
	}

	/**
	 * Sets the oBJC d1.
	 * 
	 * @param oBJCD1
	 *            the new oBJC d1
	 */
	public void setOBJCD1(String oBJCD1) {
		OBJCD1 = oBJCD1;
	}

	/**
	 * Gets the oBJC d2.
	 * 
	 * @return the oBJC d2
	 */
	public String getOBJCD2() {
		return OBJCD2;
	}

	/**
	 * Sets the oBJC d2.
	 * 
	 * @param oBJCD2
	 *            the new oBJC d2
	 */
	public void setOBJCD2(String oBJCD2) {
		OBJCD2 = oBJCD2;
	}

	/**
	 * Gets the oBJC d3.
	 * 
	 * @return the oBJC d3
	 */
	public String getOBJCD3() {
		return OBJCD3;
	}

	/**
	 * Sets the oBJC d3.
	 * 
	 * @param oBJCD3
	 *            the new oBJC d3
	 */
	public void setOBJCD3(String oBJCD3) {
		OBJCD3 = oBJCD3;
	}

	/**
	 * Gets the vERSION.
	 * 
	 * @return the vERSION
	 */
	public String getVERSION() {
		return VERSION;
	}

	/**
	 * Sets the vERSION.
	 * 
	 * @param vERSION
	 *            the new vERSION
	 */
	public void setVERSION(String vERSION) {
		VERSION = vERSION;
	}

	/**
	 * Gets the lOCATION.
	 * 
	 * @return the lOCATION
	 */
	public String getLOCATION() {
		return LOCATION;
	}

	/**
	 * Sets the lOCATION.
	 * 
	 * @param lOCATION
	 *            the new lOCATION
	 */
	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}

	/**
	 * Gets the iNSTAL l_ con.
	 * 
	 * @return the iNSTAL l_ con
	 */
	public String getINSTALL_CON() { // NOPMD by yuvraj_patil01 on 3/19/11 10:50
										// AM
		return INSTALL_CON;
	}

	/**
	 * Sets the iNSTAL l_ con.
	 * 
	 * @param iNSTALL_CON
	 *            the new iNSTAL l_ con
	 */
	public void setINSTALL_CON(String iNSTALL_CON) { // NOPMD by yuvraj_patil01
														// on 3/19/11 10:50 AM
		INSTALL_CON = iNSTALL_CON;
	}

	/**
	 * Gets the aCTIVITY.
	 * 
	 * @return the aCTIVITY
	 */
	public String getACTIVITY() {
		return ACTIVITY;
	}

	/**
	 * Sets the aCTIVITY.
	 * 
	 * @param aCTIVITY
	 *            the new aCTIVITY
	 */
	public void setACTIVITY(String aCTIVITY) {
		ACTIVITY = aCTIVITY;
	}

	/**
	 * Gets the jOBTYPE.
	 * 
	 * @return the jOBTYPE
	 */
	public String getJOBTYPE() {
		return JOBTYPE;
	}

	/**
	 * Sets the jOBTYPE.
	 * 
	 * @param jOBTYPE
	 *            the new jOBTYPE
	 */
	public void setJOBTYPE(String jOBTYPE) {
		JOBTYPE = jOBTYPE;
	}

	/**
	 * Gets the lB r_ value.
	 * 
	 * @return the lB r_ value
	 */
	public String getLBR_VALUE() { // NOPMD by yuvraj_patil01 on 3/19/11 10:50
									// AM
		return LBR_VALUE;
	}

	/**
	 * Sets the lB r_ value.
	 * 
	 * @param lBR_VALUE
	 *            the new lB r_ value
	 */
	public void setLBR_VALUE(String lBR_VALUE) { // NOPMD by yuvraj_patil01 on
													// 3/19/11 10:51 AM
		LBR_VALUE = lBR_VALUE;
	}

	/**
	 * Gets the lABVAL.
	 * 
	 * @return the lABVAL
	 */
	public String getLABVAL() {
		return LABVAL;
	}

	/**
	 * Sets the lABVAL.
	 * 
	 * @param lABVAL
	 *            the new lABVAL
	 */
	public void setLABVAL(String lABVAL) {
		LABVAL = lABVAL;
	}

	/**
	 * Gets the pRCSTAT.
	 * 
	 * @return the pRCSTAT
	 */
	public String getPRCSTAT() {
		return PRCSTAT;
	}

	/**
	 * Sets the pRCSTAT.
	 * 
	 * @param pRCSTAT
	 *            the new pRCSTAT
	 */
	public void setPRCSTAT(String pRCSTAT) {
		PRCSTAT = pRCSTAT;
	}

	/**
	 * Gets the tEXT.
	 * 
	 * @return the tEXT
	 */
	public String getTEXT() {
		return TEXT;
	}

	/**
	 * Sets the tEXT.
	 * 
	 * @param tEXT
	 *            the new tEXT
	 */
	public void setTEXT(String tEXT) {
		TEXT = tEXT;
	}

	/**
	 * Gets the r_ num.
	 * 
	 * @return the r_ num
	 */
	public BigDecimal getR_NUM() { // NOPMD by yuvraj_patil01 on 3/19/11 10:51
									// AM
		return R_NUM;
	}

	/**
	 * Sets the r_ num.
	 * 
	 * @param r_NUM
	 *            the new r_ num
	 */
	public void setR_NUM(BigDecimal r_NUM) { // NOPMD by yuvraj_patil01 on
												// 3/19/11 10:51 AM
		R_NUM = r_NUM;
	}

	/**
	 * Gets the tX t_ type.
	 * 
	 * @return the tX t_ type
	 */
	public String getTXT_TYPE() { // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM
		return TXT_TYPE;
	}

	/**
	 * Sets the tX t_ type.
	 * 
	 * @param tXT_TYPE
	 *            the new tX t_ type
	 */
	public void setTXT_TYPE(String tXT_TYPE) { // NOPMD by yuvraj_patil01 on
												// 3/19/11 10:51 AM
		TXT_TYPE = tXT_TYPE;
	}

	/**
	 * Gets the n o_ o f_ includedwp.
	 * 
	 * @return the n o_ o f_ includedwp
	 */
	public BigDecimal getNO_OF_INCLUDEDWP() { // NOPMD by yuvraj_patil01 on
												// 3/19/11 10:52 AM
		return NO_OF_INCLUDEDWP;
	}

	/**
	 * Sets the n o_ o f_ includedwp.
	 * 
	 * @param nO_OF_INCLUDEDWP
	 *            the new n o_ o f_ includedwp
	 */
	public void setNO_OF_INCLUDEDWP(BigDecimal nO_OF_INCLUDEDWP) { // NOPMD by
																	// yuvraj_patil01
																	// on
																	// 3/19/11
																	// 10:52 AM
		NO_OF_INCLUDEDWP = nO_OF_INCLUDEDWP;
	}

	/**
	 * Gets the n o_ o f_ notincludedwp.
	 * 
	 * @return the n o_ o f_ notincludedwp
	 */
	public BigDecimal getNO_OF_NOTINCLUDEDWP() { // NOPMD by yuvraj_patil01 on
													// 3/19/11 10:52 AM
		return NO_OF_NOTINCLUDEDWP;
	}

	/**
	 * Sets the n o_ o f_ notincludedwp.
	 * 
	 * @param nO_OF_NOTINCLUDEDWP
	 *            the new n o_ o f_ notincludedwp
	 */
	public void setNO_OF_NOTINCLUDEDWP(BigDecimal nO_OF_NOTINCLUDEDWP) { // NOPMD
																			// by
																			// yuvraj_patil01
																			// on
																			// 3/19/11
																			// 10:52
																			// AM
		NO_OF_NOTINCLUDEDWP = nO_OF_NOTINCLUDEDWP;
	}

	@Override
	public int hashCode() {
		int hash = 1;
		// hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		boolean equals = true;
		if (!(object instanceof WSGLBRVAL)) {
			return false;
		}
		WSGLBRVAL other = (WSGLBRVAL) object;
		equals = checkEqual(this.RANGE, other.RANGE);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.LBR_VARIANT, other.LBR_VARIANT);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.LABVAL, other.LABVAL);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.JOBTYPE, other.JOBTYPE);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.LBR_VALUE, other.LBR_VALUE);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.PRCSTAT, other.PRCSTAT);
		if (!equals) {
			return equals;
		}
		return equals;
	}

	/**
	 * Check equal.
	 * 
	 * @param one
	 *            the one
	 * @param two
	 *            the two
	 * @return true, if successful
	 */
	private boolean checkEqual(String one, String two) {
		boolean equals = true;
		if (one != null && two != null) {
			if (!one.equals(two)) {
				equals = false;
			}
		} else {
			if ((one == null && two != null) || (one != null && two == null)) {
				equals = false;
			}
		}
		return equals;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WSGLBROBJT=" + RANGE + " " + LBR_VARIANT + OBJCD1 + " "
				+ OBJCD2 + " " + OBJCD3 + " " + ACTIVITY + " " + VERSION + " "
				+ LOCATION + " " + INSTALL_CON + " " + JOBTYPE + " "
				+ LBR_VALUE + " " + LABVAL + " " + PRCSTAT + "]";
	}

}
