/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class LANG.
 * 
 * Author: Reena Rawat
 */
@Entity
@Table(name = "LANG")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class LANG implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The SPRAS. */
	@Id
	@Column(name = "SPRAS")
	private String SPRAS; // NOPMD by yuvraj_patil01 on 3/19/11 10:47 AM

	/** The LASPEZ. */
	@Column(name = "LASPEZ")
	private String LASPEZ; // NOPMD by yuvraj_patil01 on 3/19/11 10:47 AM

	/** The LAHQ. */
	@Column(name = "LAHQ")
	private String LAHQ; // NOPMD by yuvraj_patil01 on 3/19/11 10:47 AM

	/** The LAISO. */
	@Column(name = "LAISO")
	private String LAISO; // NOPMD by yuvraj_patil01 on 3/19/11 10:47 AM

	/** The SPTXT. */
	@Column(name = "SPTXT")
	private String SPTXT; // NOPMD by yuvraj_patil01 on 3/19/11 10:47 AM

	/**
	 * Gets the sPRAS.
	 * 
	 * @return the sPRAS
	 */
	public String getSPRAS() {
		return SPRAS;
	}

	/**
	 * Sets the sPRAS.
	 * 
	 * @param sPRAS
	 *            the new sPRAS
	 */
	public void setSPRAS(String sPRAS) {
		SPRAS = sPRAS;
	}

	/**
	 * Gets the lASPEZ.
	 * 
	 * @return the lASPEZ
	 */
	public String getLASPEZ() {
		return LASPEZ;
	}

	/**
	 * Sets the lASPEZ.
	 * 
	 * @param lASPEZ
	 *            the new lASPEZ
	 */
	public void setLASPEZ(String lASPEZ) {
		LASPEZ = lASPEZ;
	}

	/**
	 * Gets the lAHQ.
	 * 
	 * @return the lAHQ
	 */
	public String getLAHQ() {
		return LAHQ;
	}

	/**
	 * Sets the lAHQ.
	 * 
	 * @param lAHQ
	 *            the new lAHQ
	 */
	public void setLAHQ(String lAHQ) {
		LAHQ = lAHQ;
	}

	/**
	 * Gets the lAISO.
	 * 
	 * @return the lAISO
	 */
	public String getLAISO() {
		return LAISO;
	}

	/**
	 * Sets the lAISO.
	 * 
	 * @param lAISO
	 *            the new lAISO
	 */
	public void setLAISO(String lAISO) {
		LAISO = lAISO;
	}

	/**
	 * Gets the sPTXT.
	 * 
	 * @return the sPTXT
	 */
	public String getSPTXT() {
		return SPTXT;
	}

	/**
	 * Sets the sPTXT.
	 * 
	 * @param sPTXT
	 *            the new sPTXT
	 */
	public void setSPTXT(String sPTXT) {
		SPTXT = sPTXT;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof LANG)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LANG=" + SPRAS + " " + LASPEZ + " " + LAHQ + " " + LAISO + " "
				+ SPTXT + "]";
	}

}
