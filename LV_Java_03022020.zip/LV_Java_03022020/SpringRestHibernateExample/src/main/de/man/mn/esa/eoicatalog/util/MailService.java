/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.util;

import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

/**
 * The Class MailService.
 * 
 * Author: Yuvraj Patil
 */
public class MailService {

	/** The mail sender. */
	private MailSender mailSender;

	/** The alert mail message. */
	private SimpleMailMessage alertMailMessage;

	/**	
	 * Send mail.
	 * 
	 * @param from
	 *            the from
	 * @param to
	 *            the to
	 * @param subject
	 *            the subject
	 * @param body
	 *            the body
	 */
	public void sendMail(String from, String to, String subject, String body) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(from);
		message.setTo(to);
		message.setSubject(subject);
		message.setText(body);
		mailSender.send(message);
	}

	/**
	 * Send alert mail.
	 * 
	 * @param alert
	 *            the alert
	 */
	public void sendAlertMail(String alert) {
		SimpleMailMessage mailMessage = new SimpleMailMessage(alertMailMessage);
		mailMessage.setText(alert);
		mailSender.send(mailMessage);
	}

	/**
	 * Gets the mail sender.
	 * 
	 * @return the mail sender
	 */
	public MailSender getMailSender() {
		return mailSender;
	}

	/**
	 * Sets the mail sender.
	 * 
	 * @param mailSender
	 *            the new mail sender
	 */
	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}

	/**
	 * Gets the alert mail message.
	 * 
	 * @return the alert mail message
	 */
	public SimpleMailMessage getAlertMailMessage() {
		return alertMailMessage;
	}

	/**
	 * Sets the alert mail message.
	 * 
	 * @param alertMailMessage
	 *            the new alert mail message
	 */
	public void setAlertMailMessage(SimpleMailMessage alertMailMessage) {
		this.alertMailMessage = alertMailMessage;
	}
}