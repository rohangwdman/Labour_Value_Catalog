package de.man.mn.esa.eoicatalog.laborvalue.facade;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestDBOracle {

	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");

		String url = "jdbc:Oracle:thin:@10.76.160.207:1521:EOICAT";

		Connection conn = DriverManager.getConnection(url, "EOICAT_USER",
				"eoicat123");

		conn.setAutoCommit(false);
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery("select MSEH3 from UOMT");
		while (rset.next()) {
			//System.out.println(rset.getString(1));
		}
		stmt.close();
		//System.out.println("Ok.");
		//System.out.println((new TestDBOracle()).getLocale("E"));
	}

	public String getLocale(String language) {
		String locale = "";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:Oracle:thin:@10.76.160.207:1521:EOICAT";

			Connection conn = DriverManager.getConnection(url, "EOICAT_USER",
					"eoicat123");

			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery("SELECT LAISO from LANG WHERE SPRAS = '" + language + "'");
			while (rset.next()) {
				locale = rset.getString(1);
				//System.out.println(">>>>>>" + locale);
			}
			stmt.close();
			//System.out.println("Ok.");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return locale;
	}
}