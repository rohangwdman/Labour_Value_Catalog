/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class UOMT.
 * 
 * Author: Reena Rawat
 */
@Entity
@Table(name = "UOMT")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class UOMT implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The SPRAS. */
	@Id
	@Column(name = "SPRAS")
	private String SPRAS; // NOPMD by yuvraj_patil01 on 3/19/11 10:48 AM

	/** The MSEHI. */
	@Column(name = "MSEHI")
	private String MSEHI; // NOPMD by yuvraj_patil01 on 3/19/11 10:48 AM

	/** The MSE h3. */
	@Column(name = "MSEH3")
	private String MSEH3; // NOPMD by yuvraj_patil01 on 3/19/11 10:48 AM

	/**
	 * Gets the sPRAS.
	 * 
	 * @return the sPRAS
	 */
	public String getSPRAS() {
		return SPRAS;
	}

	/**
	 * Sets the sPRAS.
	 * 
	 * @param sPRAS
	 *            the new sPRAS
	 */
	public void setSPRAS(String sPRAS) {
		SPRAS = sPRAS;
	}

	/**
	 * Gets the mSEHI.
	 * 
	 * @return the mSEHI
	 */
	public String getMSEHI() {
		return MSEHI;
	}

	/**
	 * Sets the mSEHI.
	 * 
	 * @param mSEHI
	 *            the new mSEHI
	 */
	public void setMSEHI(String mSEHI) {
		MSEHI = mSEHI;
	}

	/**
	 * Gets the mSE h3.
	 * 
	 * @return the mSE h3
	 */
	public String getMSEH3() {
		return MSEH3;
	}

	/**
	 * Sets the mSE h3.
	 * 
	 * @param mSEH3
	 *            the new mSE h3
	 */
	public void setMSEH3(String mSEH3) {
		MSEH3 = mSEH3;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof UOMT)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "UOMT=" + SPRAS + " " + MSEHI + " " + MSEH3 + "]";
	}

}
