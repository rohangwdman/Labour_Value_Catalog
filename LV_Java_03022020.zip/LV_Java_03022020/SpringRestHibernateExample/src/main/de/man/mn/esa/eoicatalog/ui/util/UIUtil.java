/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.ui.util;

//import com.google.gwt.event.shared.HandlerManager;

import de.man.mn.esa.eoicatalog.share.exception.EOIException;
//import de.man.mn.esa.eoicatalog.ui.widget.EOIButton;

/**
 * The Class UIUtil.
 * 
 * Author: Yuvraj Patil
 */
public class UIUtil {

	/** The ui util. */
	private static UIUtil uiUtil;

	/** The event bus. */
	//private HandlerManager eventBus;

	/**
	 * Gets the single instance of UIUtil.
	 * 
	 * @return single instance of UIUtil
	 */
	public static UIUtil getInstance() {
		if (uiUtil == null) {
			uiUtil = new UIUtil();
		}
		return uiUtil;
	}

	/**
	 * Instantiates a new uI util.
	 */
	public UIUtil() {

	}

	/**
	 * Sets the event bus.
	 * 
	 * @param inEventBus
	 *            the new event bus
	 *//*
	public void setEventBus(HandlerManager inEventBus) {
		eventBus = inEventBus;
	}

	*//**
	 * Gets the event bus.
	 * 
	 * @return the event bus
	 *//*
	public HandlerManager getEventBus() {
		return eventBus;
	}*/

	/**
	 * Gets the uI exceptions.
	 * 
	 * @param caught
	 *            the caught
	 * @return the uI exceptions
	 */
	public static String getUIExceptions(Throwable caught) {
		String message = "";
		if (caught instanceof EOIException) {

		} else {
			// fatal error
		}

		return message;
	}

	/**
	 * Handle ui exceptions.
	 * 
	 * @param caught
	 *            the caught
	 */
	public static void handleUIExceptions(Throwable caught) {
		if (caught instanceof EOIException) {

		}
	}

	/**
	 * Removes the characters.
	 * 
	 * @param text
	 *            the text
	 * @param charsToRemove
	 *            the chars to remove
	 * @return the string
	 */
	public static String removeCharacters(String text, String charsToRemove) {
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < text.length(); i++) {
			char ch = text.charAt(i);
			if (!(charsToRemove.indexOf(ch) > -1)) {
				buffer.append(ch);
			}
		}
		return buffer.toString();
	}

	/**
	 * Replace characters.
	 * 
	 * @param text
	 *            the text
	 * @param charToReplace
	 *            the char to replace
	 * @param charToReplaceWith
	 *            the char to replace with
	 * @return the string
	 */
	public static String replaceCharacters(String text, char charToReplace,
			char charToReplaceWith) {
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < text.length(); i++) {
			char ch = text.charAt(i);
			if (ch == charToReplace) {
				buffer.append(charToReplaceWith);
			} else {
				buffer.append(ch);
			}
		}
		return buffer.toString();
	}

	/**
	 * Form code of n length.
	 * 
	 * @param code
	 *            the code
	 * @param nLength
	 *            the n length
	 * @return the string
	 */
	public static String formCodeOfNLength(String code, int nLength) {
		String rtnCode = code;
		if (rtnCode == null) {
			rtnCode = "";
		}
		while (rtnCode.length() < nLength) {
			rtnCode = rtnCode + " ";
		}
		return rtnCode;
	}

	/**
	 * Prefix char to form code of n length.
	 * 
	 * @param code
	 *            the code
	 * @param nLength
	 *            the n length
	 * @param prefixChar
	 *            the prefix char
	 * @return the string
	 */
	public static String prefixCharToFormCodeOfNLength(String code,
			int nLength, char prefixChar) {
		String rtnCode = code;
		if (rtnCode == null) {
			rtnCode = "";
		}
		while (rtnCode.length() < nLength) {
			rtnCode = prefixChar + rtnCode;
		}
		return rtnCode;
	}

	/**
	 * Removes the prefix char.
	 * 
	 * @param code
	 *            the code
	 * @param prefixChar
	 *            the prefix char
	 * @return the string
	 */
	public static String removePrefixChar(String code, char prefixChar) {
		String rtnCode = code;
		if (rtnCode == null) {
			rtnCode = "";
		}
		while (rtnCode.length() > 0) {
			if (rtnCode.indexOf(prefixChar) == 0) {
				rtnCode = rtnCode.substring(1);
			} else {
				break;
			}
		}
		return rtnCode;
	}

/*	*//**
	 * Adds the button validation.
	 * 
	 * @param searchText
	 *            the search text
	 * @param secondText
	 *            the second text
	 * @param searchButton
	 *            the search button
	 *//*
	public static void addButtonValidation(String searchText,
			String secondText, EOIButton searchButton) {
		String searchTxt = searchText;
		String secondTxt = secondText;
		searchTxt = searchTxt.trim();
		secondTxt = secondTxt.trim();
		if (searchTxt.length() == 0) {
			// ErrMsg:
			// "Please provide a search criterion to search for Labor Values."
			searchButton.setEnabled(false);
		} else {
			if (searchTxt.indexOf('*') < 0) {
				// Is not having * char
				if (searchTxt.length() < 3) {
					// ErrMsg:
					// "Please provide at least 3 characters as a search criterion to search for Labor Values."
					searchButton.setEnabled(false);
				} else {
					// LoadingDialog.getInstance().show();
					// fetchSearchWorkProcesses(paginationVO);
					searchButton.setEnabled(true);
				}
			} else {
				// Is having * char
				String temp = UIUtil.removeCharacters(searchTxt, "*");
				if (temp.length() < 3) {
					// ErrMsg:
					// "Please provide at least 3 characters excluding the wildcard character �*� as a search criterion to search for Labor Values."
					searchButton.setEnabled(false);
				} else {
					// LoadingDialog.getInstance().show();
					// fetchSearchWorkProcesses(paginationVO);
					searchButton.setEnabled(true);
				}
			}
		}

	}*/

	public static String insertSepratorInLVCode(String labourValueCode) {
		String rtnStr = "";
		if(labourValueCode != null && !labourValueCode.isEmpty() && labourValueCode.length() > 16){
			rtnStr = labourValueCode.substring(0, 3) + "|"
					+ labourValueCode.substring(3, 4) + "|"
					+ labourValueCode.substring(4, 7) + "|"
					+ labourValueCode.substring(7, 10) + "|"
					+ labourValueCode.substring(10, 12) + "|"
					+ labourValueCode.substring(12, 14) + "|"
					+ labourValueCode.substring(14, 16) + "|"
					+ labourValueCode.substring(16, 17);
		}
		
		return rtnStr;
	}

	public static String insertSepratorInObjCode(String objCode) {
		String rtnStr = "";
		objCode = formCodeOfNLength(objCode, 7);
		rtnStr = objCode.substring(0, 3) + "|" + objCode.substring(3, 4) + "|"
				+ objCode.substring(4, 7);
		return rtnStr;
	}

	public static String insertSepratorInDCCode(String damageCode) {
		String rtnStr = "";
		rtnStr = damageCode.substring(0, 3) + "|" + damageCode.substring(3, 4)
				+ "|" + damageCode.substring(4, 7) + "|"
				+ damageCode.substring(7, 9) + "|"
				+ damageCode.substring(9, 11) + "|"
				+ damageCode.substring(11, 13);
		return rtnStr;
	}
}
