/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */

package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class WSGLBRACTT.
 * 
 * Author: Yuvraj Patil
 */
@Entity
@Table(name = "WSGLBRACTT")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class WSGLBRACTT implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ACTIVITY. */
	@Id
	@Column(name = "ACTIVITY")
	private String ACTIVITY; // NOPMD by yuvraj_patil01 on 3/19/11 10:48 AM

	/** The TEXT. */
	@Column(name = "TEXT")
	private String TEXT; // NOPMD by yuvraj_patil01 on 3/19/11 10:48 AM

	/** The SPRAS. */
	@Column(name = "SPRAS")
	private String SPRAS; // NOPMD by yuvraj_patil01 on 3/19/11 10:48 AM

	/** The PRCSTAT. */
	@Column(name = "PRCSTAT")
	private String PRCSTAT; // NOPMD by yuvraj_patil01 on 3/19/11 10:48 AM

	/**
	 * Gets the aCTIVITY.
	 * 
	 * @return the aCTIVITY
	 */
	public String getACTIVITY() {
		return ACTIVITY;
	}

	/**
	 * Sets the aCTIVITY.
	 * 
	 * @param aCTIVITY
	 *            the new aCTIVITY
	 */
	public void setACTIVITY(String aCTIVITY) {
		ACTIVITY = aCTIVITY;
	}

	/**
	 * Gets the tEXT.
	 * 
	 * @return the tEXT
	 */
	public String getTEXT() {
		return TEXT;
	}

	/**
	 * Sets the tEXT.
	 * 
	 * @param tEXT
	 *            the new tEXT
	 */
	public void setTEXT(String tEXT) {
		TEXT = tEXT;
	}

	/**
	 * Gets the sPRAS.
	 * 
	 * @return the sPRAS
	 */
	public String getSPRAS() {
		return SPRAS;
	}

	/**
	 * Sets the sPRAS.
	 * 
	 * @param sPRAS
	 *            the new sPRAS
	 */
	public void setSPRAS(String sPRAS) {
		SPRAS = sPRAS;
	}

	/**
	 * Gets the pRCSTAT.
	 * 
	 * @return the pRCSTAT
	 */
	public String getPRCSTAT() {
		return PRCSTAT;
	}

	/**
	 * Sets the pRCSTAT.
	 * 
	 * @param pRCSTAT
	 *            the new pRCSTAT
	 */
	public void setPRCSTAT(String pRCSTAT) {
		PRCSTAT = pRCSTAT;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		// hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof WSGLBRACTT)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "WSGLBROBJT=" + ACTIVITY + " " + TEXT + " " + SPRAS + " "
				+ PRCSTAT + "]";
	}

}
