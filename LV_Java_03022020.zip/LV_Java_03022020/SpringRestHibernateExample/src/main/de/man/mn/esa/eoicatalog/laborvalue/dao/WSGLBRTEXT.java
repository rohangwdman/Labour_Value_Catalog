/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */

package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class WSGLBRTEXT.
 * 
 * Author: Yuvraj Patil
 */
@Entity
@Table(name = "WSGLBRTEXT")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class WSGLBRTEXT implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The OBJCDID. */
	@Id
	@Column(name = "TEXTID")
	private BigDecimal TEXTID; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d1. */
	@Column(name = "LBR_VARIANT")
	private String LBR_VARIANT; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d2. */
	@Column(name = "RACTIVITY")
	private String RACTIVITY; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d3. */
	@Column(name = "ROBJCD1")
	private String ROBJCD1; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The TEXT. */
	@Column(name = "ROBJCD2")
	private String ROBJCD2; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The SPRAS. */
	@Column(name = "ROBJCD3")
	private String ROBJCD3; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "RANGE")
	private String RANGE; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d2. */
	@Column(name = "OBJCD1")
	private String OBJCD1; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d2. */
	@Column(name = "OBJCD2")
	private String OBJCD2; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The OBJC d3. */
	@Column(name = "OBJCD3")
	private String OBJCD3; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The PRCSTAT. */
	@Column(name = "PRCSTAT")
	private String PRCSTAT; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	/** The PRCSTAT. */
	@Column(name = "ACTIVITY")
	private String ACTIVITY; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "TXT_TYPE")
	private String TXT_TYPE; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "VERSION")
	private String VERSION; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "RVERSION")
	private String RVERSION; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "LOCATION")
	private String LOCATION; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "RLOCATION")
	private String RLOCATION; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "JOBTYPE")
	private String JOBTYPE; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "INSTALL_CON")
	private String INSTALL_CON; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	@Column(name = "RINSTALL_CON")
	private String RINSTALL_CON; // NOPMD by yuvraj_patil01 on 3/19/11 10:51 AM

	public BigDecimal getTEXTID() {
		return TEXTID;
	}

	public void setTEXTID(BigDecimal tEXTID) {
		TEXTID = tEXTID;
	}

	public String getOBJCD1() {
		return OBJCD1;
	}

	public void setOBJCD1(String oBJCD1) {
		OBJCD1 = oBJCD1;
	}

	public String getLBR_VARIANT() { // NOPMD by yuvraj_patil01 on 3/25/11 3:30 PM
		return LBR_VARIANT;
	}

	public void setLBR_VARIANT(String lBR_VARIANT) { // NOPMD by yuvraj_patil01 on 3/25/11 3:30 PM
		LBR_VARIANT = lBR_VARIANT;
	}

	public String getRACTIVITY() {
		return RACTIVITY;
	}

	public void setRACTIVITY(String rACTIVITY) {
		RACTIVITY = rACTIVITY;
	}

	public String getROBJCD1() {
		return ROBJCD1;
	}

	public void setROBJCD1(String rOBJCD1) {
		ROBJCD1 = rOBJCD1;
	}

	public String getROBJCD2() {
		return ROBJCD2;
	}

	public void setROBJCD2(String rOBJCD2) {
		ROBJCD2 = rOBJCD2;
	}

	public String getROBJCD3() {
		return ROBJCD3;
	}

	public void setROBJCD3(String rOBJCD3) {
		ROBJCD3 = rOBJCD3;
	}

	public String getRANGE() {
		return RANGE;
	}

	public void setRANGE(String rANGE) {
		RANGE = rANGE;
	}

	public String getOBJCD2() {
		return OBJCD2;
	}

	public void setOBJCD2(String oBJCD2) {
		OBJCD2 = oBJCD2;
	}

	public String getOBJCD3() {
		return OBJCD3;
	}

	public void setOBJCD3(String oBJCD3) {
		OBJCD3 = oBJCD3;
	}

	public String getPRCSTAT() {
		return PRCSTAT;
	}

	public void setPRCSTAT(String pRCSTAT) {
		PRCSTAT = pRCSTAT;
	}

	public String getACTIVITY() {
		return ACTIVITY;
	}

	public void setACTIVITY(String aCTIVITY) {
		ACTIVITY = aCTIVITY;
	}

	public String getTXT_TYPE() { // NOPMD by yuvraj_patil01 on 3/25/11 3:30 PM
		return TXT_TYPE;
	}

	public void setTXT_TYPE(String tXT_TYPE) { // NOPMD by yuvraj_patil01 on 3/25/11 3:30 PM
		TXT_TYPE = tXT_TYPE;
	}

	public String getVERSION() {
		return VERSION;
	}

	public void setVERSION(String vERSION) {
		VERSION = vERSION;
	}

	public String getLOCATION() {
		return LOCATION;
	}

	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}

	public String getJOBTYPE() {
		return JOBTYPE;
	}

	public void setJOBTYPE(String jOBTYPE) {
		JOBTYPE = jOBTYPE;
	}

	public String getINSTALL_CON() { // NOPMD by yuvraj_patil01 on 3/25/11 3:30 PM
		return INSTALL_CON;
	}

	public void setINSTALL_CON(String iNSTALL_CON) { // NOPMD by yuvraj_patil01 on 3/25/11 3:31 PM
		INSTALL_CON = iNSTALL_CON;
	}

	public String getRVERSION() {
		return RVERSION;
	}

	public void setRVERSION(String rVERSION) {
		RVERSION = rVERSION;
	}

	public String getRLOCATION() {
		return RLOCATION;
	}

	public void setRLOCATION(String rLOCATION) {
		RLOCATION = rLOCATION;
	}

	public String getRINSTALL_CON() { // NOPMD by yuvraj_patil01 on 3/25/11 3:31 PM
		return RINSTALL_CON;
	}

	public void setRINSTALL_CON(String rINSTALL_CON) { // NOPMD by yuvraj_patil01 on 3/25/11 3:31 PM
		RINSTALL_CON = rINSTALL_CON;
	}

	@Override
	public int hashCode() {
		int hash = 1;
		// hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		boolean equals = true;
		if (!(object instanceof WSGLBRTEXT)) {
			return false;
		}
		WSGLBRTEXT other = (WSGLBRTEXT) object;

		// equals = checkEqual(this.OBJCD123, other.OBJCD123);
		// if(!equals){
		// return equals;
		// }
		equals = checkEqual(this.OBJCD1, other.OBJCD1);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.OBJCD2, other.OBJCD2);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.OBJCD3, other.OBJCD3);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.ROBJCD1, other.ROBJCD1);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.ROBJCD2, other.ROBJCD2);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.ROBJCD3, other.ROBJCD3);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.PRCSTAT, other.PRCSTAT);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.LBR_VARIANT, other.LBR_VARIANT);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.RACTIVITY, other.RACTIVITY);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.RANGE, other.RANGE);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.JOBTYPE, other.JOBTYPE);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.INSTALL_CON, other.INSTALL_CON);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.VERSION, other.VERSION);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.LOCATION, other.LOCATION);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.RINSTALL_CON, other.RINSTALL_CON);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.RVERSION, other.RVERSION);
		if (!equals) {
			return equals;
		}
		equals = checkEqual(this.RLOCATION, other.RLOCATION);
		if (!equals) {
			return equals;
		}
		return equals;
	}

	/**
	 * Check equal.
	 * 
	 * @param one
	 *            the one
	 * @param two
	 *            the two
	 * @return true, if successful
	 */
	private boolean checkEqual(String one, String two) {
		boolean equals = true;
		if (one != null && two != null) {
			if (!one.equals(two)) {
				equals = false;
			}
		} else {
			if ((one == null && two != null) || (one != null && two == null)) {
				equals = false;
			}
		}
		return equals;
	}

	@Override
	public String toString() {
		return "WSGLBRTEXT=" + OBJCD1 + " " + OBJCD2 + " " + OBJCD3 + LOCATION
				+ " " + VERSION + " " + INSTALL_CON + " " + JOBTYPE + " "
				+ PRCSTAT + " " + RANGE + " " + RACTIVITY + " " + LBR_VARIANT
				+ " " + ROBJCD1 + " " + ROBJCD2 + " " + ROBJCD3 + " "
				+ RVERSION + " " + RLOCATION + " " + RINSTALL_CON + "]";
	}

}
