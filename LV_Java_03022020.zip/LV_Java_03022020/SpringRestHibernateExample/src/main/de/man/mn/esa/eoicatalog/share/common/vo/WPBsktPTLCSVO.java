/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.constants.AppConstants;

/**
 * The Class WPBsktPTLCSVO.
 * 
 * Author: Yuvraj Patil
 */
public class WPBsktPTLCSVO extends NodeVO {

	/**
	 * Instantiates a new wP bskt ptlcsvo.
	 */
	public WPBsktPTLCSVO() {
		super();
		setType(AppConstants.Node.WPBSKTPTLCS);
	}

}
