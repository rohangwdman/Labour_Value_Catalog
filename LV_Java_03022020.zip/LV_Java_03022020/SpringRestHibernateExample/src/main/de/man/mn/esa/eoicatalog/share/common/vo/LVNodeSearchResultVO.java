/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

/**
 * The Class LVNodeSearchResultVO.
 * 
 * Author: Aathavan Sivasubramonian
 */
public class LVNodeSearchResultVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5363345413030970877L;

	/** The node vo list. */
	private List<NodeVO> nodeVOList;

	/** The level. */
	private int level;

	/**
	 * Instantiates a new lV node search result vo.
	 */
	public LVNodeSearchResultVO() {

	}

	/**
	 * Gets the node vo list.
	 * 
	 * @return the node vo list
	 */
	public List<NodeVO> getNodeVOList() {
		return nodeVOList;
	}

	/**
	 * Sets the node vo list.
	 * 
	 * @param nodeVOList
	 *            the new node vo list
	 */
	public void setNodeVOList(List<NodeVO> nodeVOList) {
		this.nodeVOList = nodeVOList;
	}

	/**
	 * Gets the level.
	 * 
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * Sets the level.
	 * 
	 * @param level
	 *            the new level
	 */
	public void setLevel(int level) {
		this.level = level;
	}
}
