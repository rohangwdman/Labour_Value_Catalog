/*package de.man.mn.esa.eoicatalog.service.rpc;

import de.man.mn.esa.eoicatalog.share.service.IRemoteSessionService;

*//**
 * The Class SessionCheckServlet
 * 
 * Check validity of user's session
 * 
 * Author: Rahul Bairathi
 *//*

public class IRemoteSessionServlet extends BaseRemoteServiceServlet implements
		IRemoteSessionService {
	
	private static final long serialVersionUID = 7551777965519895340L;

	*//**
	 * Check validity of user's session
	 * 
	 * @return
	 *//*
	public boolean isSessionValid() {
		return (this.getThreadLocalRequest().getSession() != null);
	}
}*/