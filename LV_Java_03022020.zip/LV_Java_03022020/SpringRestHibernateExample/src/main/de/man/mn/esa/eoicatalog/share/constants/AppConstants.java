/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.constants;

/**
 * The Class AppConstants.
 * 
 * Author: Aathavan Sivasubramonian
 */
public class AppConstants {

	/** The Caller ID EOI */
	public static final String EOI = "EOI";
	
	/** The Caller ID ASP */
	public static final String ASP = "ASP";
	
	/** The Caller ID GAO */
	public static final String GAO = "GAO";
	
	/**
	 * The Class Node.
	 * 
	 * Author: Aathavan Sivasubramonian
	 */
	public class Node {

		/** The Constant OBJECT. */
		public static final int OBJECT = 1;

		/** The Constant ACTIVITY. */
		public static final int ACTIVITY = 2;

		/** The Constant VERSIONLOCATION. */
		public static final int VERSIONLOCATION = 3;

		/** The Constant POSITIONNUMBER. */
		public static final int POSITIONNUMBER = 4;

		/** The Constant DEFECTTYPE. */
		public static final int DEFECTTYPE = 5;

		/** The Constant WPBSKTPTLCS. */
		public static final int WPBSKTPTLCS = 6;

		/** The Constant WPBSKTPTMA. */
		public static final int WPBSKTPTMA = 7;

		/** The Constant WPBSKTLVQD. */
		public static final int WPBSKTLVQD = 8;
		
	}
}
