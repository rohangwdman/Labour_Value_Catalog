/**
 * Copyright (c) 2010 Infosys Technologies Ltd.. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.facade;

import javax.servlet.ServletContext;

import org.springframework.beans.BeansException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import de.man.mn.esa.eoicatalog.laborvalue.service.ILaborValService;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;


/**
 * The Class LaborValFacade.
 * 
 * @Revision : 0.1
 * @Author : Yuvraj Patil
 */
public class JSPLaborValFacade {

	final static String LABVALSERVICE = "labValService";
	
	public static String getLanguage(ServletContext context, String language){
		WebApplicationContext applicationContext = WebApplicationContextUtils.getWebApplicationContext(context);
		String localeLang = "";
		try {
			localeLang = ((ILaborValService)applicationContext.getBean(LABVALSERVICE)).fetchLanguage(language);
		} catch (BeansException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EOIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return localeLang;
	}
}
