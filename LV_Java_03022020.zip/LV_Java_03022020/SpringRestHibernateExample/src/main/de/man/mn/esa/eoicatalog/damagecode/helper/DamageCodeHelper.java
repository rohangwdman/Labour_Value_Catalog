/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.damagecode.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRDAM;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRLOCT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBROBJT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRVRST;
import de.man.mn.esa.eoicatalog.laborvalue.helper.ErrorMessages;
import de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.ObjectCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PositionNumberVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.VersionLocationVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;
import de.man.mn.esa.eoicatalog.ui.util.UIUtil;

/**
 * The Class DamageCodeHelper.
 * 
 * Author: Reena Rawat
 */
@Repository
public class DamageCodeHelper implements IDamageCodeHelper {

	/** The hibernate template. */
	@Autowired
	private HibernateTemplate hibernateTemplate;

	/** The error messages. */
	@Autowired
	private ErrorMessages errorMessages;

	/** The error msg. */
	private String errorMsg = "";

	/** The error code. */
	private String errorCode = "";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger
			.getLogger(DamageCodeHelper.class);

	// EOIGWTI18NConstants cONSTANTS = EOIGWTI18NConstants.CONSTANTS;

	/**
	 * Sets the session factory.
	 * 
	 * @param sessionFactory
	 *            the new session factory
	 *//*
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}

	*//**
	 * Sets the error messages.
	 * 
	 * @param errorMessages
	 *            the new error messages
	 *//*
	public void setErrorMessages(ErrorMessages errorMessages) {
		this.errorMessages = errorMessages;
	}*/

	/**
	 * Fetch parent nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchParentNodes(UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			result = hibernateTemplate
					.find("FROM WSGLBROBJT OBJ where OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = '"
							+ userVO.getLanguage()
							+ "' "
							+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,1)) from WSGLBRDAM DAM where "
							+ "DAM.PRCSTAT = 'A') " + "ORDER BY OBJCD1");

			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e022";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;

	}

	/**
	 * Fetch dmg codes list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesList(UserVO userVO,DamageCodeVO damageCodeVO, NodeVO nodeVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQry(userVO, damageCodeVO, nodeVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQry(userVO, damageCodeVO, nodeVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRDAM.class))
						.list();
			} else {
				qry = formQry(userVO, damageCodeVO, nodeVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRDAM.class))
						.list();
			}
			List<DamageCodeVO> voList = new ArrayList<DamageCodeVO>();
			populateDamageCodeVO(result, voList);
			paginationVO.setRows(voList);
		} catch (Exception e) {
			errorCode = "e023";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Form qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQry(UserVO userVO, DamageCodeVO damageCodeVO,
			NodeVO node, PaginationVO paginationVO) {
		String qry = "";

		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3,DAM.VERSION,DAM.LOCATION,DAM.DAMAGE,DAM.LABVAL, "
				+ "O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END "
				+ "|| ' ' || V.TEXT || ' ' ||L.TEXT || ' ' || DMGT.TEXT AS TEXT "
				+ "FROM {h-schema}WSGLBRDAM DAM, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L,{h-schema}WSGLBRVRST V, {h-schema}WSGLBRDMGT DMGT  "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.LOCATION = L.LOCATION AND DAM.VERSION = V.VERSION  AND DAM.damage not like 'n%' "
				+ "AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%'"
				+ "AND DAM.DAMAGE = DMGT.DAMAGE AND DAM.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND V.PRCSTAT = 'A'  AND DMGT.PRCSTAT = 'A' "
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND L.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND V.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND DMGT.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND LABVAL LIKE '"
				+ ((null != damageCodeVO.getdAMAGECODE()) ? damageCodeVO
						.getdAMAGECODE().trim() : node.getCode().trim())
				+ "%' ORDER BY LABVAL) DATA";

		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Populate damage code vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateDamageCodeVO(List result, List<DamageCodeVO> voList) {
		for (int i = 0; i < result.size(); i++) {
			DamageCodeVO vo = new DamageCodeVO();
			vo.setoBJCD1(((WSGLBRDAM) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRDAM) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRDAM) result.get(i)).getOBJCD3());
			vo.setvERLOC(((WSGLBRDAM) result.get(i)).getVERSION());
			vo.setpOSNUM(((WSGLBRDAM) result.get(i)).getLOCATION());
			vo.setdAMAGECODE(((WSGLBRDAM) result.get(i)).getLABVAL());
			vo.setdEFECT(((WSGLBRDAM) result.get(i)).getDAMAGE());
			vo.settEXT(((WSGLBRDAM) result.get(i)).getTEXT());
			voList.add(vo);
		}
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildNodes(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List returnNodes = new ArrayList();
		if (nodeVO instanceof ObjectCodeVO) {
			if (nodeVO.getLevel() >= 1 & nodeVO.getLevel() <= 4) {
				List verLocNodes = fetchVerLocs(damageCodeVO, nodeVO, userVO);
				returnNodes.addAll(verLocNodes);
				List objNodes = fetchChildObjects1(damageCodeVO, nodeVO, userVO);
				returnNodes.addAll(objNodes);
			} else if (nodeVO.getLevel() == 5) {
				List verLocNodes = fetchVerLocs(damageCodeVO, nodeVO, userVO);
				returnNodes.addAll(verLocNodes);
			}
		} else if (nodeVO instanceof VersionLocationVO) {
			List posNumNodes = fetchPosNum(damageCodeVO, nodeVO, userVO);
			returnNodes.addAll(posNumNodes);
		}
		return returnNodes;
	}

	/*
	 * public List fetchChildObjects(DamageCodeVO damageCodeVO, NodeVO nodeVO,
	 * UserVO userVO){ List result = null; try{ String qry =
	 * formQryOfChildObjects(damageCodeVO, nodeVO, userVO); result =
	 * hibernateTemplate.find(qry); }catch(Exception e){ e.printStackTrace(); }
	 * List<NodeVO> nodeList=new ArrayList<NodeVO>(); for(int
	 * i=0;i<result.size();i++){ NodeVO node = new ObjectCodeVO();
	 * node.setChildNodesHaveBeenFetched(false); node.setHavingChildNodes(true);
	 * if(nodeVO.getLevel() == 1){
	 * node.setCode((({h-schema}WSGLBROBJT)result.get(i)).getOBJCD1()); }else
	 * if(nodeVO.getLevel() == 2){
	 * node.setCode((({h-schema}WSGLBROBJT)result.get(i)).getOBJCD1()); }else
	 * if(nodeVO.getLevel() == 3){
	 * node.setCode(UIUtil.formCodeOfNLength((({h-schema}WSGLBROBJT
	 * )result.get(i)).getOBJCD1(),3) +
	 * (({h-schema}WSGLBROBJT)result.get(i)).getOBJCD2()); }else if(nodeVO.getLevel() ==
	 * 4){
	 * node.setCode(UIUtil.formCodeOfNLength((({h-schema}WSGLBROBJT)result.get(i)).getOBJCD1
	 * (),3) +
	 * UIUtil.formCodeOfNLength((({h-schema}WSGLBROBJT)result.get(i)).getOBJCD2(),1) +
	 * (({h-schema}WSGLBROBJT)result.get(i)).getOBJCD3()); }
	 * node.setLevel(nodeVO.getLevel() + 1);
	 * node.setText((({h-schema}WSGLBROBJT)result.get(i)).getTEXT()); nodeList.add(node);
	 * } return nodeList;
	 * 
	 * }
	 */
	/**
	 * Fetch child objects1.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildObjects1(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		Query query = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			String qry = formQryOfChildObjects1(damageCodeVO, nodeVO, userVO);

			if (nodeVO.getLevel() == 1) {
				query = hibernateTemplate.getSessionFactory().openSession()
						.createQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode() + "%");
			} else if (nodeVO.getLevel() == 2) {
				query = hibernateTemplate.getSessionFactory().openSession()
						.createQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode() + "%");
			} else if (nodeVO.getLevel() == 3) {
				query = hibernateTemplate.getSessionFactory().openSession()
						.createQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode());
			} else if (nodeVO.getLevel() == 4) {
				damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
				damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
				query = hibernateTemplate.getSessionFactory().openSession()
						.createQuery(qry);
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", damageCodeVO.getoBJCD1());
				query.setParameter("code2", damageCodeVO.getoBJCD2());
			}
			result = query.list();

			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(true);
				if (nodeVO.getLevel() == 1) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 2) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 3) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD2());
				} else if (nodeVO.getLevel() == 4) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ UIUtil.formCodeOfNLength(
									((WSGLBROBJT) result.get(i)).getOBJCD2(), 1)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD3());
				}
				node.setLevel(nodeVO.getLevel() + 1);
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e024";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;

	}

	/*
	 * private String formQryOfChildObjects(DamageCodeVO damageCodeVO, NodeVO
	 * nodeVO, UserVO userVO){ String qry = ""; if(nodeVO.getLevel() == 1){ qry
	 * =
	 * "FROM {h-schema}WSGLBROBJT OBJ WHERE OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = '"
	 * + userVO.getLanguage() + "' " +
	 * "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,2)) FROM {h-schema}WSGLBRDAM DAM WHERE OBJCD1 like '"
	 * + nodeVO.getCode() + "%' " +
	 * "AND DAM.PRCSTAT = 'A' AND damage not like 'n%' AND damage not like 'N%' AND damage not like 'r%' AND damage not like 'R%')"
	 * + "ORDER BY OBJCD1, OBJCD2, OBJCD3"; }else if(nodeVO.getLevel() == 2){
	 * qry =
	 * "FROM {h-schema}WSGLBROBJT OBJ WHERE OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = '"
	 * + userVO.getLanguage() + "' " +
	 * "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,3)) FROM {h-schema}WSGLBRDAM DAM WHERE OBJCD1 like '"
	 * + nodeVO.getCode() + "%' " +
	 * "AND DAM.PRCSTAT = 'A' AND damage not like 'n%' AND damage not like 'N%' AND damage not like 'r%' AND damage not like 'R%')"
	 * + "ORDER BY OBJCD1, OBJCD2, OBJCD3"; }else if(nodeVO.getLevel() == 3){
	 * qry = "FROM {h-schema}WSGLBROBJT OBJ WHERE OBJCD3 IS NULL AND SPRAS = '" +
	 * userVO.getLanguage() + "' " + "AND OBJ.PRCSTAT = 'A' AND OBJCD1 = '" +
	 * nodeVO.getCode() +
	 * "' AND OBJCD2 IN (SELECT DISTINCT(SUBSTR(LABVAL,4,1)) FROM {h-schema}WSGLBRDAM DAM "
	 * + "WHERE OBJCD1 = '" + nodeVO.getCode() +
	 * "' AND DAM.PRCSTAT = 'A' AND damage not like 'n%' AND damage not like 'N%' AND damage not like 'r%' AND damage not like 'R%')"
	 * + "ORDER BY OBJCD1, OBJCD2, OBJCD3"; }else if(nodeVO.getLevel() == 4){
	 * damageCodeVO.setOBJCD1(nodeVO.getCode().substring(0,3).trim());
	 * damageCodeVO.setOBJCD2(nodeVO.getCode().substring(3,4).trim()); qry =
	 * "FROM {h-schema}WSGLBROBJT OBJ WHERE SPRAS = '" + userVO.getLanguage() + "' " +
	 * "AND OBJCD1 = '" + damageCodeVO.getOBJCD1() + "' AND OBJCD2 = '" +
	 * damageCodeVO.getOBJCD2() + "'  AND OBJCD3 IN " +
	 * "(SELECT DISTINCT(SUBSTR(LABVAL,5,3)) FROM {h-schema}WSGLBRDAM DAM WHERE OBJCD1 = '"
	 * + damageCodeVO.getOBJCD1() + "' " + "AND OBJCD2 = '" +
	 * damageCodeVO.getOBJCD2() +
	 * "' AND DAM.PRCSTAT = 'A' AND damage not like 'n%' AND damage not like 'N%' AND damage not like 'r%' AND damage not like 'R%')"
	 * + "ORDER BY OBJCD1, OBJCD2, OBJCD3"; } return qry; }
	 */

	/**
	 * Form qry of child objects1.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildObjects1(DamageCodeVO damageCodeVO,
			NodeVO nodeVO, UserVO userVO) {
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			qry = "FROM {h-schema}WSGLBROBJT OBJ WHERE OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
					+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,2)) FROM {h-schema}WSGLBRDAM DAM WHERE OBJCD1 like :code "
					+ "AND DAM.PRCSTAT = 'A' )"
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 2) {
			qry = "FROM {h-schema}WSGLBROBJT OBJ WHERE OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
					+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,3)) FROM {h-schema}WSGLBRDAM DAM WHERE OBJCD1 like :code "
					+ "AND DAM.PRCSTAT = 'A' )"
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 3) {
			qry = "FROM {h-schema}WSGLBROBJT OBJ WHERE OBJCD3 IS NULL AND SPRAS = :language "
					+ "AND OBJ.PRCSTAT = 'A' AND OBJCD1 = :code AND OBJCD2 IN (SELECT DISTINCT(SUBSTR(LABVAL,4,1)) FROM {h-schema}WSGLBRDAM DAM "
					+ "WHERE OBJCD1 = :code AND DAM.PRCSTAT = 'A' )"
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		} else if (nodeVO.getLevel() == 4) {
			qry = "FROM {h-schema}WSGLBROBJT OBJ WHERE SPRAS = :language "
					+ "AND OBJCD1 = :code1 AND OBJCD2 = :code2  AND OBJCD3 IN "
					+ "(SELECT DISTINCT(SUBSTR(LABVAL,5,3)) FROM {h-schema}WSGLBRDAM DAM WHERE OBJCD1 = :code1 "
					+ "AND OBJCD2 = :code2 AND DAM.PRCSTAT = 'A' )"
					+ "ORDER BY OBJCD1, OBJCD2, OBJCD3";
		}

		return qry;
	}

	/**
	 * Fetch ver locs.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchVerLocs(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			String qry = formQryToFetchVerLocs(damageCodeVO, nodeVO, userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new VersionLocationVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 7)
						+ (((WSGLBRVRST) result.get(i)).getVERSION()));
				node.setLevel(nodeVO.getLevel());
				if (isVersionLocationHavingChildNodes(damageCodeVO, node,
						userVO)) {
					node.setChildNodesHaveBeenFetched(false);
					node.setHasChildren(true);
				} else {
					node.setHasChildren(false);
				}
				node.setName(((WSGLBRVRST) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e025";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;
	}

	/**
	 * Checks if is version location having child nodes.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return true, if is version location having child nodes
	 * @throws EOIException
	 *             the eOI exception
	 */
	private boolean isVersionLocationHavingChildNodes(
			DamageCodeVO damageCodeVO, NodeVO nodeVO, UserVO userVO)
			throws EOIException {
		List result = fetchPosNum(damageCodeVO, nodeVO, userVO);
		if (result.size() > 0) {
			return true;
		}
		return false;
	}

	/**
	 * Fetch pos num.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchPosNum(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		try {
			String qry = formQryToFetchPosNum(damageCodeVO, nodeVO, userVO);
			result = hibernateTemplate.find(qry);
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new PositionNumberVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 9)
						+ (((WSGLBRLOCT) result.get(i)).getLOCATION()));
				node.setLevel(nodeVO.getLevel());
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(false);
				node.setName(((WSGLBRLOCT) result.get(i)).getTEXT());
				nodeList.add(node);
			}

		} catch (Exception e) {
			errorCode = "e026";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return nodeList;
	}

	/**
	 * Form qry to fetch pos num.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryToFetchPosNum(DamageCodeVO damageCodeVO,
			NodeVO nodeVO, UserVO userVO) {
		String qry = "";
		damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
		damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
		damageCodeVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
		damageCodeVO.setvERLOC(nodeVO.getCode().substring(7, 9).trim());
		if (nodeVO.getLevel() == 1) {
			qry = "FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND LOCATION IN (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ damageCodeVO.getoBJCD1() + "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND VERSION = '"
					+ damageCodeVO.getvERLOC() + "' AND DAM.PRCSTAT = 'A' )"
					+ " ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 2) {
			qry = "FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ damageCodeVO.getoBJCD1() + "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND VERSION = '"
					+ damageCodeVO.getvERLOC() + "' AND DAM.PRCSTAT = 'A' )"
					+ " ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 3) {
			qry = "FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ damageCodeVO.getoBJCD1() + "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND VERSION = '"
					+ damageCodeVO.getvERLOC() + "'AND DAM.PRCSTAT = 'A' )"
					+ " ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 4) {
			qry = "FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ damageCodeVO.getoBJCD1() + "' " + "AND OBJCD2 = '"
					+ damageCodeVO.getoBJCD2()
					+ "' AND OBJCD3 = null AND VERSION = '"
					+ damageCodeVO.getvERLOC() + "' AND DAM.PRCSTAT = 'A')"
					+ " ORDER BY LOCT.LOCATION";
		} else if (nodeVO.getLevel() == 5) {
			qry = "FROM WSGLBRLOCT LOCT WHERE LOCT.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND LOCATION in (SELECT DISTINCT(LOCATION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ damageCodeVO.getoBJCD1() + "' " + "AND OBJCD2 = '"
					+ damageCodeVO.getoBJCD2() + "' AND OBJCD3 = '"
					+ damageCodeVO.getoBJCD3() + "' AND VERSION = '"
					+ damageCodeVO.getvERLOC() + "' "
					+ "AND DAM.PRCSTAT = 'A' ) " + "ORDER BY LOCT.LOCATION";
		}
		return qry;
	}

	/**
	 * Form qry to fetch ver locs.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryToFetchVerLocs(DamageCodeVO damageCodeVO,
			NodeVO nodeVO, UserVO userVO) {
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			qry = "FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION IN (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND DAM.PRCSTAT = 'A' )"
					+ " ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 2) {
			qry = "FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND DAM.PRCSTAT = 'A' )"
					+ " ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 3) {
			qry = "FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ nodeVO.getCode()
					+ "' "
					+ "AND OBJCD2 = null AND OBJCD3 = null AND DAM.PRCSTAT = 'A' )"
					+ " ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 4) {
			damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			qry = "FROM {h-schema}WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ damageCodeVO.getoBJCD1() + "' " + "AND OBJCD2 = '"
					+ damageCodeVO.getoBJCD2()
					+ "' AND OBJCD3 = null  AND DAM.PRCSTAT = 'A' )"
					+ " ORDER BY VRST.VERSION";
		} else if (nodeVO.getLevel() == 5) {
			damageCodeVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			damageCodeVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			damageCodeVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
			qry = "FROM WSGLBRVRST VRST WHERE VRST.PRCSTAT = 'A' AND SPRAS = '"
					+ userVO.getLanguage()
					+ "' "
					+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM WSGLBRDAM DAM WHERE OBJCD1 = '"
					+ damageCodeVO.getoBJCD1() + "' " + "AND OBJCD2 = '"
					+ damageCodeVO.getoBJCD2() + "' AND OBJCD3 = '"
					+ damageCodeVO.getoBJCD3() + "' "
					+ "AND DAM.PRCSTAT = 'A' )" + "ORDER BY VRST.VERSION";
		}
		return qry;
	}

	/**
	 * Fetch dmg search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchDMGSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryToFetchDMGSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRDAM.class))
						.list();
			} else {
				qry = formQryToFetchDMGSearchList(searchText, objectCode,
						userVO, paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRDAM.class))
						.list();
			}
			LOGGER.error(qry);
			List<DamageCodeVO> voList = new ArrayList<DamageCodeVO>();
			populateDMGDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e027";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Populate dmg data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateDMGDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			DamageCodeVO vo = new DamageCodeVO();
			vo.setoBJCD1(((WSGLBRDAM) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRDAM) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRDAM) result.get(i)).getOBJCD3());
			vo.setvERLOC(((WSGLBRDAM) result.get(i)).getVERSION());
			vo.setpOSNUM(((WSGLBRDAM) result.get(i)).getLOCATION());
			vo.setdEFECT(((WSGLBRDAM) result.get(i)).getDAMAGE());
			vo.setdAMAGECODE(((WSGLBRDAM) result.get(i)).getLABVAL());
			vo.settEXT(((WSGLBRDAM) result.get(i)).getTEXT());
			voList.add(vo);
		}
	}

	/**
	 * Form qry to fetch dmg search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchDMGSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		String qry = "";
		qry = "Select ROWNUM R_NUM, DATA.* from (select DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3, VER.VERSION, LOC.LOCATION, DAM.labval, "
				+ "DAM.DAMAGE, O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END "
				+ "|| VER.Text || LOC.Text || DMGT.Text as text "
				+ "from {h-schema}WSGLBRDAM  DAM, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRVRST VER, {h-schema}WSGLBRLOCT LOC,{h-schema}WSGLBRDMGT DMGT "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.VERSION = VER.VERSION AND DAM.LOCATION = LOC.LOCATION AND DAM.damage not like 'n%' "
				+ "AND DAM.damage not like 'N%' AND DAM.damage not like 'r%' AND DAM.damage not like 'R%' AND DAM.DAMAGE = DMGT.DAMAGE "
				+ "AND UPPER (O1.TEXT || O2.TEXT || O3.TEXT || VER.Text || LOC.Text ||DMGT.Text) like UPPER('"
				+ searchText
				+ "') AND DAM.PRCSTAT = 'A' "
				+ "AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND VER.PRCSTAT = 'A' AND LOC.PRCSTAT ='A' AND DMGT.PRCSTAT = 'A'"
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND VER.SPRAS ='"
				+ userVO.getLanguage()
				+ "' AND LOC.SPRAS='"
				+ userVO.getLanguage()
				+ "' "
				+ "AND DMGT.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND DAM.OBJCD1  || DAM.OBJCD2  || DAM.OBJCD3  like '"
				+ objectCode + "' order by labval) DATA";

		if (paginationVO.getCurrentPage() != 0) {
			// qry = qry + " WHERE ROWNUM > " + paginationVO.getStartRowNum() +
			// " AND ROWNUM <= " + paginationVO.getEndRowNum() + "";
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	/**
	 * Fetch dmg codes list for search defect field.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesListForSearchDefectField(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO nodeVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		try {
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryforSearch(userVO, damageCodeVO, nodeVO,
						paginationVO);
				result = hibernateTemplate.getSessionFactory().openSession()
						.createSQLQuery(qry).list();
				paginationVO.setTotalRecords(result.size());

				qry = formQryforSearch(userVO, damageCodeVO, nodeVO,
						paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRDAM.class))
						.list();
			} else {
				qry = formQryforSearch(userVO, damageCodeVO, nodeVO,
						paginationVO);
				result = hibernateTemplate
						.getSessionFactory()
						.openSession()
						.createSQLQuery(qry)
						.setResultTransformer(
								Transformers.aliasToBean(WSGLBRDAM.class))
						.list();
			}
			List<DamageCodeVO> voList = new ArrayList<DamageCodeVO>();
			populateDamageCodeVO(result, voList);
			paginationVO.setRows(voList);
		} catch (Exception e) {
			errorCode = "e028";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return paginationVO;
	}

	/**
	 * Form qryfor search.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryforSearch(UserVO userVO, DamageCodeVO damageCodeVO,
			NodeVO node, PaginationVO paginationVO) {
		String qry = "";

		qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DAM.OBJCD1, DAM.OBJCD2, DAM.OBJCD3,DAM.VERSION,DAM.LOCATION,DAM.DAMAGE,DAM.LABVAL, "
				+ "O1.TEXT || CASE WHEN O2.OBJCD2 IS NOT NULL THEN ' ' || O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN ' ' || O3.TEXT ELSE '' END "
				+ "|| ' ' || V.TEXT || ' ' ||L.TEXT || ' ' || DMGT.TEXT AS TEXT "
				+ "FROM {h-schema}WSGLBRDAM DAM, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L,{h-schema}WSGLBRVRST V, {h-schema}WSGLBRDMGT DMGT  "
				+ "WHERE DAM.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
				+ "AND DAM.OBJCD1 || DAM.OBJCD2 || DAM.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
				+ "AND DAM.LOCATION = L.LOCATION AND DAM.VERSION = V.VERSION "
				+ "AND DAM.DAMAGE = DMGT.DAMAGE AND DAM.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND V.PRCSTAT = 'A'  AND DMGT.PRCSTAT = 'A' "
				+ "AND O1.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND O2.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND O3.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND L.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND V.SPRAS = '"
				+ userVO.getLanguage()
				+ "' AND DMGT.SPRAS = '"
				+ userVO.getLanguage()
				+ "' "
				+ "AND LABVAL LIKE '"
				+ ((null != damageCodeVO.getdAMAGECODE()) ? damageCodeVO
						.getdAMAGECODE().trim() : node.getCode().trim())
				+ "%' ORDER BY LABVAL) DATA";

		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > "
					+ paginationVO.getStartRowNum() + " AND R_NUM <= "
					+ paginationVO.getEndRowNum() + "";
		}
		return qry;
	}

	public boolean fetchValidSearch(UserVO userVO,String text,Integer textId) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.helper.IDamageCodeHelper#isValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public boolean isValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.helper.IDamageCodeHelper#fetchValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public DamageCodeVO fetchValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.helper.IDamageCodeHelper#fetchMostValidWPAttributes(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public DamageCodeVO fetchMostValidDCAttributes(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return null;
	}

}
