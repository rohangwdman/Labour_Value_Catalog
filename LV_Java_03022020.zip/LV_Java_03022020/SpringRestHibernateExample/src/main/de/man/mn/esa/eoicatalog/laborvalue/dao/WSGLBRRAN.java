/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */

package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class WSGLBRRAN.
 * 
 * Author: Yuvraj Patil
 */
@Entity
@Table(name = "WSGLBRRAN")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class WSGLBRRAN implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The RANGE. */
	@Id
	@Column(name = "RANGE")
	private String RANGE; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The VARIANTE. */
	@Column(name = "VARIANTE")
	private String VARIANTE; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/** The PRCSTAT. */
	@Column(name = "PRCSTAT")
	private String PRCSTAT; // NOPMD by yuvraj_patil01 on 3/19/11 10:50 AM

	/**
	 * Gets the rANGE.
	 * 
	 * @return the rANGE
	 */
	public String getRANGE() {
		return RANGE;
	}

	/**
	 * Sets the rANGE.
	 * 
	 * @param rANGE
	 *            the new rANGE
	 */
	public void setRANGE(String rANGE) {
		RANGE = rANGE;
	}

	/**
	 * Gets the vARIANTE.
	 * 
	 * @return the vARIANTE
	 */
	public String getVARIANTE() {
		return VARIANTE;
	}

	/**
	 * Sets the vARIANTE.
	 * 
	 * @param vARIANTE
	 *            the new vARIANTE
	 */
	public void setVARIANTE(String vARIANTE) {
		VARIANTE = vARIANTE;
	}

	/**
	 * Gets the pRCSTAT.
	 * 
	 * @return the pRCSTAT
	 */
	public String getPRCSTAT() {
		return PRCSTAT;
	}

	/**
	 * Sets the pRCSTAT.
	 * 
	 * @param pRCSTAT
	 *            the new pRCSTAT
	 */
	public void setPRCSTAT(String pRCSTAT) {
		PRCSTAT = pRCSTAT;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof WSGLBRRAN)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "WSGLBRRAN=" + RANGE + " " + VARIANTE + " " + PRCSTAT + "]";
	}

}
