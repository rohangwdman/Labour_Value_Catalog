/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.constants.AppConstants;

/**
 * The Class DefectTypeVO.
 * 
 * Author: Reena Rawat
 */
public class DefectTypeVO extends NodeVO {

	/**
	 * Instantiates a new defect type vo.
	 */
	public DefectTypeVO() {
		setType(AppConstants.Node.DEFECTTYPE);
	}
}
