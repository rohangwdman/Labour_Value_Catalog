/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.service.common;

/**
 * The Interface IBaseFacade.
 * 
 * Author: Aathavan Sivasubramonian
 */
public interface IBaseFacade {

}
