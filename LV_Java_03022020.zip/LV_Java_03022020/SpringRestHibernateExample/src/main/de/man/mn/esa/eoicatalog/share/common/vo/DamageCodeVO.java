/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

/**
 * The Class DamageCodeVO.
 * 
 * Author: Reena Rawat
 */
public class DamageCodeVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 77796953481239312L;

	/** The OBJCd1. */
	private String oBJCD1;

	/** The OBJCd2. */
	private String oBJCD2;

	/** The OBJCd3. */
	private String oBJCD3;

	/** The vERLOC. */
	private String vERLOC;

	/** The pOSNUM. */
	private String pOSNUM;

	/** The dEFECT. */
	private String dEFECT;

	/** The dAMAGECODE. */
	private String dAMAGECODE;

	/** The pRCSTAT. */
	private String pRCSTAT;

	/** The tEXT. */
	private String tEXT;

	/** The damagetEXT. */
	private String damagetEXT;

	/**
	 * Gets the DamagetEXT.
	 * 
	 * @return the DamagetEXT
	 */
	public String getDamagetEXT() {
		return damagetEXT;
	}

	/**
	 * Sets the DamagetEXT.
	 * 
	 * @param DamagetEXT
	 *            the new DamagetEXT
	 */
	public void setDamagetEXT(String damagetEXT) {
		this.damagetEXT = damagetEXT;
	}

	/**
	 * Gets the oBJC d1.
	 * 
	 * @return the oBJC d1
	 */
	public String getoBJCD1() {
		return oBJCD1;
	}

	/**
	 * Sets the oBJC d1.
	 * 
	 * @param oBJCD1
	 *            the new oBJC d1
	 */
	public void setoBJCD1(String oBJCD1) {
		this.oBJCD1 = oBJCD1;
	}

	/**
	 * Gets the oBJC d2.
	 * 
	 * @return the oBJC d2
	 */
	public String getoBJCD2() {
		return oBJCD2;
	}

	/**
	 * Sets the oBJC d2.
	 * 
	 * @param oBJCD2
	 *            the new oBJC d2
	 */
	public void setoBJCD2(String oBJCD2) {
		this.oBJCD2 = oBJCD2;
	}

	/**
	 * Gets the oBJC d3.
	 * 
	 * @return the oBJC d3
	 */
	public String getoBJCD3() {
		return oBJCD3;
	}

	/**
	 * Sets the oBJC d3.
	 * 
	 * @param oBJCD3
	 *            the new oBJC d3
	 */
	public void setoBJCD3(String oBJCD3) {
		this.oBJCD3 = oBJCD3;
	}

	/**
	 * Gets the pRCSTAT.
	 * 
	 * @return the pRCSTAT
	 */
	public String getpRCSTAT() {
		return pRCSTAT;
	}

	/**
	 * Sets the pRCSTAT.
	 * 
	 * @param pRCSTAT
	 *            the new pRCSTAT
	 */
	public void setpRCSTAT(String pRCSTAT) {
		this.pRCSTAT = pRCSTAT;
	}

	/**
	 * Gets the vERLOC.
	 * 
	 * @return the vERLOC
	 */
	public String getvERLOC() {
		return vERLOC;
	}

	/**
	 * Sets the vERLOC.
	 * 
	 * @param vERLOC
	 *            the new vERLOC
	 */
	public void setvERLOC(String vERLOC) {
		this.vERLOC = vERLOC;
	}

	/**
	 * Gets the pOSNUM.
	 * 
	 * @return the pOSNUM
	 */
	public String getpOSNUM() {
		return pOSNUM;
	}

	/**
	 * Sets the pOSNUM.
	 * 
	 * @param pOSNUM
	 *            the new pOSNUM
	 */
	public void setpOSNUM(String pOSNUM) {
		this.pOSNUM = pOSNUM;
	}

	/**
	 * Gets the dEFECT.
	 * 
	 * @return the dEFECT
	 */
	public String getdEFECT() {
		return dEFECT;
	}

	/**
	 * Sets the dEFECT.
	 * 
	 * @param dEFECT
	 *            the new dEFECT
	 */
	public void setdEFECT(String dEFECT) {
		this.dEFECT = dEFECT;
	}

	/**
	 * Gets the dAMAGECODE.
	 * 
	 * @return the dAMAGECODE
	 */
	public String getdAMAGECODE() {
		return dAMAGECODE;
	}

	/**
	 * Sets the dAMAGECODE.
	 * 
	 * @param dAMAGECODE
	 *            the new dAMAGECODE
	 */
	public void setdAMAGECODE(String dAMAGECODE) {
		this.dAMAGECODE = dAMAGECODE;
	}

	/**
	 * Gets the tEXT.
	 * 
	 * @return the tEXT
	 */
	public String gettEXT() {
		return tEXT;
	}

	/**
	 * Sets the tEXT.
	 * 
	 * @param tEXT
	 *            the new tEXT
	 */
	public void settEXT(String tEXT) {
		this.tEXT = tEXT;
	}

}
