/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

/**
 * The Class PaginationVO.
 * 
 * Author: Aathavan Sivasubramonian
 */
public class PaginationVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8061706902267230307L;

	/** The number of pages. */
	private int numberOfPages;

	/** The current page. */
	private int currentPage;

	/** The page size. */
	private int pageSize;

	/** The rows. */
	private List rows;

	/** The total records. */
	private int totalRecords;

	/** The is next enabled. */
	private boolean isNextEnabled;

	/** The is previous enabled. */
	private boolean isPreviousEnabled;

	/** The is first enabled. */
	private boolean isFirstEnabled;

	/** The is last enabled. */
	private boolean isLastEnabled;

	/** The start row num. */
	private int startRowNum;

	/** The end row num. */
	private int endRowNum;

	/**
	 * Instantiates a new pagination vo.
	 */
	public PaginationVO() {
		numberOfPages = 0;
		currentPage = 0;
		pageSize = 50;
		totalRecords = 0;

		isNextEnabled = false;
		isPreviousEnabled = false;
		isFirstEnabled = false;
		isLastEnabled = false;
	}

	/**
	 * Checks if is next enabled.
	 * 
	 * @return true, if is next enabled
	 */
	public boolean isNextEnabled() {
		return isNextEnabled;
	}

	/**
	 * Checks if is previous enabled.
	 * 
	 * @return true, if is previous enabled
	 */
	public boolean isPreviousEnabled() {
		return isPreviousEnabled;
	}

	/**
	 * Checks if is first enabled.
	 * 
	 * @return true, if is first enabled
	 */
	public boolean isFirstEnabled() {
		return isFirstEnabled;
	}

	/**
	 * Checks if is last enabled.
	 * 
	 * @return true, if is last enabled
	 */
	public boolean isLastEnabled() {
		return isLastEnabled;
	}

	/**
	 * Gets the number of pages.
	 * 
	 * @return the number of pages
	 */
	public int getNumberOfPages() {
		return numberOfPages;
	}

	/**
	 * Gets the current page.
	 * 
	 * @return the current page
	 */
	public int getCurrentPage() {
		return currentPage;
	}

	/**
	 * Sets the current page.
	 * 
	 * @param currentPage
	 *            the new current page
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
		assignStartEndRowNum();
		assignPreviousNextEnabled();
	}

	/**
	 * Gets the page size.
	 * 
	 * @return the page size
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * Sets the page size.
	 * 
	 * @param pageSize
	 *            the new page size
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * Gets the rows.
	 * 
	 * @return the rows
	 */
	public List getRows() {
		return rows;
	}

	/**
	 * Sets the rows.
	 * 
	 * @param rows
	 *            the new rows
	 */
	public void setRows(List rows) {
		this.rows = rows;
	}

	/**
	 * Gets the total records.
	 * 
	 * @return the total records
	 */
	public int getTotalRecords() {
		return totalRecords;
	}

	/**
	 * Sets the total records.
	 * 
	 * @param totalRecords
	 *            the new total records
	 */
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
		if (totalRecords > 0) {
			assignNumberOfPages();
			setCurrentPage(1);
		}
	}

	/**
	 * Gets the start row num.
	 * 
	 * @return the start row num
	 */
	public int getStartRowNum() {
		return startRowNum;
	}

	/**
	 * Gets the end row num.
	 * 
	 * @return the end row num
	 */
	public int getEndRowNum() {
		return endRowNum;
	}

	/**
	 * Assign number of pages.
	 */
	private void assignNumberOfPages() {
		numberOfPages = totalRecords / pageSize;
		if ((numberOfPages * pageSize) < totalRecords) {
			numberOfPages++;
		}
	}

	/**
	 * Assign start end row num.
	 */
	private void assignStartEndRowNum() {
		if (currentPage == 1) {
			startRowNum = 0;
			if (currentPage == numberOfPages) {
				endRowNum = totalRecords;
			} else {
				endRowNum = (pageSize * currentPage);
			}
			// endRowNum = pageSize;
		} else if (currentPage > 1) {
			if (totalRecords > 0) {
				startRowNum = (pageSize * (currentPage - 1));
				if (currentPage == numberOfPages) {
					endRowNum = totalRecords;
				} else {
					endRowNum = (pageSize * currentPage);
				}
			}
		}
	}

	/**
	 * Assign previous next enabled.
	 */
	private void assignPreviousNextEnabled() {
		if (currentPage == 1) {
			isPreviousEnabled = false;
			isFirstEnabled = false;
			if (currentPage == numberOfPages) {
				isLastEnabled = false;
				isNextEnabled = false;
			} else {
				isLastEnabled = true;
				isNextEnabled = true;
			}
		} else if (currentPage == numberOfPages) {
			isLastEnabled = false;
			isNextEnabled = false;
			isPreviousEnabled = true;
			isFirstEnabled = true;
		} else if (currentPage < numberOfPages) {
			isLastEnabled = true;
			isNextEnabled = true;
			isPreviousEnabled = true;
			isFirstEnabled = true;
		}
	}
}
