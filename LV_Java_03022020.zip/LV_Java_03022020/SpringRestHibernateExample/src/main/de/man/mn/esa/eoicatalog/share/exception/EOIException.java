/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.exception;

import java.io.Serializable;

/**
 * The Class EOIException.
 * 
 * Author: Yuvraj Patil
 */
public class EOIException extends Exception implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The exception msg. */
	private String exceptionMsg = "";

	/** The exception code. */
	private String exceptionCode = "";

	/**
	 * Instantiates a new eOI exception.
	 */
	public EOIException() {
		super();
	}

	/**
	 * Instantiates a new eOI exception.
	 * 
	 * @param exceptionMsg
	 *            the exception msg
	 */
	public EOIException(String exceptionMsg) {
		super(exceptionMsg);
	}

	/**
	 * Instantiates a new eOI exception.
	 * 
	 * @param exceptionMsg
	 *            the exception msg
	 * @param exceptionCode
	 *            the exception code
	 */
	public EOIException(String exceptionMsg, String exceptionCode) {
		super(exceptionMsg);
		this.exceptionMsg = exceptionMsg;
		this.exceptionCode = exceptionCode;
	}

	/**
	 * Gets the exception msg.
	 * 
	 * @return the exception msg
	 */
	public String getExceptionMsg() {
		return exceptionMsg;
	}

	/**
	 * Gets the exception code.
	 * 
	 * @return the exception code
	 */
	public String getExceptionCode() {
		return exceptionCode;
	}
}
