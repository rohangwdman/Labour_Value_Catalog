package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;


/**  
* Base class is used for enabling serialization to objects.
* It should be extended by each data transfer Object. 
* 
* This is marker class at this moment.
* 
* @Revision : 0.1
* @Author : Infosys Technologies Ltd
*/
public interface LaborValDao {
	List fetchRootNodes(UserVO userVO);
}
