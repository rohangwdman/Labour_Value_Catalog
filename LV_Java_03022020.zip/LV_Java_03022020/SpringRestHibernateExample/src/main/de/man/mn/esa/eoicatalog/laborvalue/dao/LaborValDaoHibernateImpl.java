package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.util.ArrayList;
import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.ObjectCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;


/**  
* Base class is used for enabling serialization to objects.
* It should be extended by each data transfer Object. 
* 
* This is marker class at this moment.
* 
* @Revision : 0.1
* @Author : Infosys Technologies Ltd
*/
public class LaborValDaoHibernateImpl implements LaborValDao{
	/*
    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory)
    {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }
    */
	public List fetchRootNodes(UserVO userVO){
		List<NodeVO> nodeList=new ArrayList<NodeVO>();
		for(int i=0;i<3;i++){
		NodeVO node = new ObjectCodeVO();
		node.setCode(i+"");
		node.setName("Node:"+i);
		nodeList.add(node);
		}
		return nodeList;
		
		//return hibernateTemplate.find("from  WSGLBROBJT");
	}
	
//    @Override
//    public List<Catalog> getCatalog(String id) {
//        Catalog catalog;
//       return  hibernateTemplate.find("from  name");
//
//    }
	
}
