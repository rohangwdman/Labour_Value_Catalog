/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.helper;

import java.util.HashMap;
import java.util.List;

import de.man.mn.esa.eoicatalog.share.common.vo.FetchChildVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchMostValidWPAttributesVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.RangeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

/**
 * The Interface ILaborValHelper.
 * 
 * Author: Yuvraj Patil
 */
public interface ILaborValHelper {

	/**
	 * Fetch valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the work process vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	WorkProcessVO fetchValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException;

	/**
	 * Checks if is valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid obj code
	 * @throws EOIException
	 *             the eOI exception
	 */
	boolean isValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException;

	/**
	 * Checks if is valid wp attribute combination.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid wp attribute combination
	 * @throws EOIException
	 *             the eOI exception
	 */
	boolean isValidWPAttributeCombination(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException;

	/**
	 * Fetch range list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	List fetchRangeList(RangeVO rangeVO, UserVO userVO) throws EOIException;

	/**
	 * Fetch variant list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	List fetchVariantList(RangeVO rangeVO, UserVO userVO) throws EOIException;

	/**
	 * Fetch root nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	List fetchRootNodes(UserVO userVO) throws EOIException;

	/**
	 * Fetch child nodes.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	List fetchChildNodes(FetchChildVO fetchChildVO) throws EOIException;

	/**
	 * Fetch unit.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	String fetchUnit(UserVO userVO) throws EOIException;

	/**
	 * Fetch wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	PaginationVO fetchWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException;

	/**
	 * Fetch included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	List fetchIncludedWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException;

	/**
	 * Fetch wp search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	PaginationVO fetchWPSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException;

	/**
	 * Fetch object search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	PaginationVO fetchObjectSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException;

	/**
	 * Fetch activity search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	PaginationVO fetchActivitySearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException;

	/**
	 * Fetch version search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	PaginationVO fetchVersionSearchList(String searchText, String versionCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException;

	/**
	 * Fetch location search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	PaginationVO fetchLocationSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException;

	/**
	 * Fetch condition search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	PaginationVO fetchConditionSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException;

	/**
	 * Fetch not included wp with details list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the hash map
	 * @throws EOIException
	 *             the eOI exception
	 */
	List<WorkProcessVO> fetchNotIncludedWPWithDetailsList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException;

	/**
	 * Checks if is wP having not included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is wP having not included wp list
	 * @throws EOIException
	 *             the eOI exception
	 */
	boolean isWPHavingNotIncludedWPList(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException;
	
	/**
	 * Fetch language.
	 * 
	 * @param spras
	 *            the spras
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	public String fetchLanguage(String spras) throws EOIException;
	
	/**
	 * Is valid search.
	 * 
	 * @param text
	 *            the text
	 * @return true, if successful
	 * @throws EOIException 
	 */
	boolean isValidSearch(UserVO userVO,String text,Integer textId) throws EOIException;

	/**
	 * Fetch Code text
	 * 
	 * @param userVO
	 * @param text
	 * @param textId
	 * @return
	 */
	String fetchCodeText(UserVO userVO, String text, 
			Integer textId) throws EOIException;
	
	/**
	 * @param userVO
	 * @param workProcessVO
	 * @param nodeVO
	 * @return
	 * @throws EOIException 
	 */
	WorkProcessVO fetchMostValidWPAttributes(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException;
}
