/**
 * Copyright (c) 2010 Infosys Technologies Ltd.. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.facade;

import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import de.man.mn.esa.eoicatalog.laborvalue.service.ILaborValService;
import de.man.mn.esa.eoicatalog.service.common.BaseFacade;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchChildVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchMostValidWPAttributesVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.RangeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;
import de.man.mn.esa.eoicatalog.util.MailConfiguration;

/**
 * The Class LaborValFacade.
 * 
 * @Revision : 0.1
 * @Author : Yuvraj Patil
 */
@Service
public class LaborValFacade extends BaseFacade implements ILaborValFacade {

	private static final String LABVALSERVICE = "labValService";
	
	private static final String MAILSERVICE = "mailConfiguration";

	/** The labor val service. */
	@Autowired
	private ILaborValService laborValService;

	/** The mail configuration. */
	@Autowired
	private MailConfiguration mailConfiguration;
	

	/*public LaborValFacade(ServletContext servletContext) {
		super();
		this.laborValService = (ILaborValService)this.getServiceBeanFromContext(servletContext,LABVALSERVICE);
	//	this.mailConfiguration = (MailConfiguration)this.getServiceBeanFromContext(servletContext,MAILSERVICE);
	}*/

	/*private ILaborValService getServiceBeanFromContext(ServletContext servletContext, String serviceId) {
		WebApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(servletContext);
		return (ILaborValService)applicationContext.getBean(serviceId);
	}

	private ILaborValService getMailConfigurationBeanFromContext(ServletContext servletContext, String mailBeanId) {
		WebApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(servletContext);
		return (ILaborValService)applicationContext.getBean(mailBeanId);
	}*/

	/**
	 * Fetch range list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchRangeList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		return laborValService.fetchRangeList(rangeVO, userVO);
	}

	/**
	 * Fetch unit.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	public String fetchUnit(UserVO userVO) throws EOIException {
		return laborValService.fetchUnit(userVO);
	}

	/**
	 * Fetch language.
	 * 
	 * @param spras
	 *            the spras
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	public String fetchLanguage(String spras) throws EOIException {
		return laborValService.fetchLanguage(spras);
	}

	/**
	 * Fetch variant list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchVariantList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		return laborValService.fetchVariantList(rangeVO, userVO);
	}

	/**
	 * Fetch valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the work process vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public WorkProcessVO fetchValidObjCode(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		return laborValService.fetchValidObjCode(userVO, workProcessVO, nodeVO);
	}

	/**
	 * Checks if is valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid obj code
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException {
		return laborValService.isValidObjCode(userVO, workProcessVO, nodeVO);
	}

	/**
	 * Checks if is valid wp attribute combination.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid wp attribute combination
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidWPAttributeCombination(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		return laborValService.isValidWPAttributeCombination(userVO,
				workProcessVO, nodeVO);
	}

	/**
	 * fetchRootNodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return List
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchRootNodes(UserVO userVO) throws EOIException {
		//MailSender mailSender = new MailSender();
		//mailSender.sendMail(mailConfiguration, "subject", "message_body");
		return laborValService.fetchRootNodes(userVO);
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildNodes(FetchChildVO fetchChildVO) throws EOIException {
		return laborValService.fetchChildNodes(fetchChildVO);
	}

	/**
	 * Fetch wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		return laborValService.fetchWPList(fetchMostValidWPAttributesVO);
	}

	/**
	 * Fetch included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchIncludedWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		return laborValService.fetchIncludedWPList(fetchMostValidWPAttributesVO);
	}

	/**
	 * Fetch wp search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchWPSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException {
		return laborValService.fetchWPSearchList(searchText, objectCode,
				userVO, paginationVO);
	}

	/**
	 * Fetch object search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchObjectSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValService.fetchObjectSearchList(searchText, objectCode,
				userVO, paginationVO);
	}

	/**
	 * Fetch activity search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchActivitySearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValService.fetchActivitySearchList(searchText,
				activityCode, userVO, paginationVO);
	}

	/**
	 * Fetch version search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchVersionSearchList(String searchText,
			String versionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValService.fetchVersionSearchList(searchText, versionCode,
				userVO, paginationVO);
	}

	/**
	 * Fetch location search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchLocationSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValService.fetchLocationSearchList(searchText,
				locationCode, userVO, paginationVO);
	}

	/**
	 * Fetch condition search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchConditionSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return laborValService.fetchConditionSearchList(searchText,
				conditionCode, userVO, paginationVO);
	}

	/**
	 * Fetch not included wp with details list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the hash map
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List<WorkProcessVO> fetchNotIncludedWPWithDetailsList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		return laborValService.fetchNotIncludedWPWithDetailsList(fetchMostValidWPAttributesVO);
	}

	/**
	 * Sets the labor val service.
	 * 
	 * @param laborValService
	 *            the new labor val service
	 */
	//public void setLaborValService(LaborValService laborValService) {
	//	this.laborValService = laborValService;
	//}

	/**
	 * Gets the labor val service.
	 * 
	 * @return the labor val service
	 */
	//public LaborValService getLaborValService() {
	//	return laborValService;
	//}

	/**
	 * Gets the mail configuration.
	 * 
	 * @return the mail configuration
	 */
	//public MailConfiguration getMailConfiguration() {
	//	return mailConfiguration;
	//}

	/**
	 * Sets the mail configuration.
	 * 
	 * @param mailConfiguration
	 *            the new mail configuration
	 */
	//public void setMailConfiguration(MailConfiguration mailConfiguration) {
	//	this.mailConfiguration = mailConfiguration;
	//}

	/**
	 * Checks if is wP having not included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is wP having not included wp list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isWPHavingNotIncludedWPList(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		return laborValService.isWPHavingNotIncludedWPList(userVO,
				workProcessVO, nodeVO);
	}

	public boolean isValidSearch(UserVO userVO, String text, Integer textId)
			throws EOIException {
		// TODO Auto-generated method stub
		return laborValService.isValidSearch(userVO, text, textId);
	}

	/**
	 * @param userVO
	 * @param text
	 * @param tableName
	 * @param textId
	 * @return
	 */
	public String fetchCodeText(UserVO userVO, String text, 
			Integer textId) throws EOIException {
		// TODO Auto-generated method stub
		return laborValService.fetchCodeText(userVO, text, textId);
	}
	
	public WorkProcessVO fetchMostValidWPAttributes(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException{
		return laborValService.fetchMostValidWPAttributes(fetchMostValidWPAttributesVO);
	}
}
