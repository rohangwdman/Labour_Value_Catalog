/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 *//*
package de.man.mn.esa.eoicatalog.service.rpc;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import de.man.mn.esa.eoicatalog.service.common.IBaseFacade;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

*//**
 * The Class BaseRemoteServiceServlet.
 * 
 * Author: Aathavan Sivasubramonian
 *//*
public class BaseRemoteServiceServlet extends RemoteServiceServlet {

	*//** The Constant serialVersionUID. *//*
	private static final long serialVersionUID = 4146618560295405158L;

	*//**
	 * Gets the context service.
	 * 
	 * @param serviceId
	 *            the service id
	 * @return the context service
	 *//*
	protected Object getContextService(String serviceId) {

		ServletContext context = getServletContext();

		WebApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(context);

		return applicationContext.getBean(serviceId);
	}
	
	protected ServletContext getContext(){
		return getServletContext();
	}

	*//**
	 * Sets the session attribute.
	 * 
	 * @param key
	 *            the key
	 * @param value
	 *            the value
	 * @throws EOIException
	 *             the eOI exception
	 *//*
	protected void setSessionAttribute(String key, Object value)
			throws EOIException {
		HttpSession session = getThreadLocalRequest().getSession(false);

		try {
			if (session != null) {
				session.setAttribute(key, value);
			} else {
				throw new EOIException("invalid session");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	*//**
	 * Gets the session attribute.
	 * 
	 * @param key
	 *            the key
	 * @return the session attribute
	 * @throws EOIException
	 *             the eOI exception
	 *//*
	protected Object getSessionAttribute(String key) throws EOIException {
		HttpSession session = getThreadLocalRequest().getSession(false);
		if (session != null) {
			return session.getAttribute(key);
		} else {
			throw new EOIException("invalid session");
		}
	}

}
*/