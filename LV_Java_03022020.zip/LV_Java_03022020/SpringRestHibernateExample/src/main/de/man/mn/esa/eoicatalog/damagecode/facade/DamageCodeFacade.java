/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */

package de.man.mn.esa.eoicatalog.damagecode.facade;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.man.mn.esa.eoicatalog.damagecode.service.IDamageCodeService;
import de.man.mn.esa.eoicatalog.service.common.BaseFacade;
import de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

/**
 * The Class DamageCodeFacade.
 * 
 * Author: Reena Rawat
 */
@Service
public class DamageCodeFacade extends BaseFacade implements IDamageCodeFacade {

	private static final String DAMAGECODESERVICE = "damageCodeService";
	
	/** The damage code service. */
	@Autowired
	private IDamageCodeService damageCodeService;

	/** The mail configuration. */
	//private MailConfiguration mailConfiguration;

	/*public DamageCodeFacade(ServletContext servletContext) {
		super();
		this.damageCodeService = (IDamageCodeService)this.getServiceBeanFromContext(servletContext,DAMAGECODESERVICE);
	}

	private IDamageCodeService getServiceBeanFromContext(ServletContext servletContext, String serviceId) {
		WebApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(servletContext);
		return (IDamageCodeService)applicationContext.getBean(serviceId);
	}*/

	/**
	 * Fetch parent nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchParentNodes(UserVO userVO) throws EOIException {
		return damageCodeService.fetchParentNodes(userVO);
	}

	/**
	 * Fetch dmg codes list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesList(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO node, PaginationVO paginationVO)
			throws EOIException {
		return damageCodeService.fetchDMGCodesList(userVO, damageCodeVO, node,
				paginationVO);
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildNodes(DamageCodeVO damageCodeVO, NodeVO node,
			UserVO userVO) throws EOIException {
		return damageCodeService.fetchChildNodes(damageCodeVO, node, userVO);
	}

	/**
	 * Fetch dmg search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return damageCodeService.fetchDMGSearchList(searchText, objectCode,
				userVO, paginationVO);
	}

	/**
	 * Gets the damage code service.
	 * 
	 * @return the damage code service
	 */
	//public DamageCodeService getDamageCodeService() {
	//	return damageCodeService;
	//}

	/**
	 * Sets the damage code service.
	 * 
	 * @param damageCodeService
	 *            the new damage code service
	 */
	//public void setDamageCodeService(DamageCodeService damageCodeService) {
	//	this.damageCodeService = damageCodeService;
	//}

	/**
	 * Fetch dmg codes list for defect field.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesListForDefectField(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO node, PaginationVO paginationVO)
			throws EOIException {
		return damageCodeService.fetchDMGCodesListForDefectField(userVO,
				damageCodeVO, node, paginationVO);
	}

	public boolean fetchValidSearch(UserVO userVO,String text,Integer textId) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeService.fetchValidSearch(userVO,text,textId);
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.facade.IDamageCodeFacade#fetchMostValidWPAttributes(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public DamageCodeVO fetchMostValidDCAttributes(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeService.fetchMostValidDCAttributes(userVO, damageCodeVO, nodeVO);
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.facade.IDamageCodeFacade#fetchValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public DamageCodeVO fetchValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeService.fetchValidObjCode(userVO, damageCodeVO, nodeVO);
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.facade.IDamageCodeFacade#isValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public boolean isValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeService.isValidObjCode(userVO, damageCodeVO, nodeVO);
	}

}
