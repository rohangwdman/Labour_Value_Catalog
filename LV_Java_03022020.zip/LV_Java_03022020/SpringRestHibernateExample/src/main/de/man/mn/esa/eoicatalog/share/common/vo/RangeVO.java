/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

/**
 * The Class RangeVO.
 * 
 * Author: Yuvraj Patil
 */
public class RangeVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The model. */
	private String model;

	/** The variant. */
	private String variant;

	/**
	 * Gets the model.
	 * 
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * Sets the model.
	 * 
	 * @param model
	 *            the new model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * Gets the variant.
	 * 
	 * @return the variant
	 */
	public String getVariant() {
		return variant;
	}

	/**
	 * Sets the variant.
	 * 
	 * @param variant
	 *            the new variant
	 */
	public void setVariant(String variant) {
		this.variant = variant;
	}
}
