/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.constants.AppConstants;

/**
 * The Class VersionLocationVO.
 * 
 * Author: Reena Rawat
 */
public class VersionLocationVO extends NodeVO {

	/**
	 * Instantiates a new version location vo.
	 */
	public VersionLocationVO() {
		setType(AppConstants.Node.VERSIONLOCATION);
	}
}
