/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.damagecode.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.man.mn.esa.eoicatalog.damagecode.helper.DamageCodeHelper;
import de.man.mn.esa.eoicatalog.damagecode.helper.IDamageCodeHelper;
import de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;

/**
 * The Class DamageCodeService.
 * 
 * Author: Reena Rawat
 */
@Service
public class DamageCodeService implements IDamageCodeService {

	/** The damage code helper. */
	@Autowired
	private IDamageCodeHelper damageCodeHelper;

	/**
	 * Gets the damage code helper.
	 * 
	 * @return the damage code helper
	 */
	/*public IDamageCodeHelper getDamageCodeHelper() {
		return damageCodeHelper;
	}*/

	/**
	 * Sets the damage code helper.
	 * 
	 * @param damageCodeHelper
	 *            the new damage code helper
	 */
	/*public void setDamageCodeHelper(IDamageCodeHelper damageCodeHelper) {
		this.damageCodeHelper = damageCodeHelper;
	}*/

	/**
	 * Fetch parent nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchParentNodes(UserVO userVO) throws EOIException {
		return damageCodeHelper.fetchParentNodes(userVO);
	}

	/**
	 * Fetch dmg codes list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesList(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO node, PaginationVO paginationVO)
			throws EOIException {
		return damageCodeHelper.fetchDMGCodesList(userVO, damageCodeVO, node,
				paginationVO);
	}

	/**
	 * Fetch child nodes.
	 * 
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildNodes(DamageCodeVO damageCodeVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		return damageCodeHelper.fetchChildNodes(damageCodeVO, nodeVO, userVO);
	}

	/**
	 * Fetch dmg search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		return damageCodeHelper.fetchDMGSearchList(searchText, objectCode,
				userVO, paginationVO);
	}

	/**
	 * Fetch dmg codes list for defect field.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param damageCodeVO
	 *            the damage code vo
	 * @param node
	 *            the node
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchDMGCodesListForDefectField(UserVO userVO,
			DamageCodeVO damageCodeVO, NodeVO node, PaginationVO paginationVO)
			throws EOIException {
		return damageCodeHelper.fetchDMGCodesListForSearchDefectField(userVO,
				damageCodeVO, node, paginationVO);
	}

	public boolean fetchValidSearch(UserVO userVO,String text,Integer Id) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeHelper.fetchValidSearch(userVO,text,Id);
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.service.IDamageCodeService#fetchValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public DamageCodeVO fetchValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeHelper.fetchValidObjCode(userVO, damageCodeVO, nodeVO);
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.service.IDamageCodeService#fetchMostValidWPAttributes(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public DamageCodeVO fetchMostValidDCAttributes(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeHelper.fetchMostValidDCAttributes(userVO, damageCodeVO, nodeVO);
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.service.IDamageCodeService#isValidObjCode(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
	public boolean isValidObjCode(UserVO userVO, DamageCodeVO damageCodeVO, NodeVO nodeVO) throws EOIException {
		// TODO Auto-generated method stub
		return damageCodeHelper.isValidObjCode(userVO, damageCodeVO, nodeVO);
	}

	/* (non-Javadoc)
	 * @see de.man.mn.esa.eoicatalog.damagecode.service.IDamageCodeService#fetchMostValidWPAttributes(de.man.mn.esa.eoicatalog.share.common.vo.UserVO, de.man.mn.esa.eoicatalog.share.common.vo.DamageCodeVO, de.man.mn.esa.eoicatalog.share.common.vo.NodeVO)
	 */
}
