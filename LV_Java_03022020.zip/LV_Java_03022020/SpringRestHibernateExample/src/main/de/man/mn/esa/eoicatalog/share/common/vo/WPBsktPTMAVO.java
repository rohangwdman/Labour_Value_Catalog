/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.constants.AppConstants;

/**
 * The Class WPBsktPTMAVO.
 * 
 * Author: Yuvraj Patil
 */
public class WPBsktPTMAVO extends NodeVO {

	/**
	 * Instantiates a new wP bskt ptmavo.
	 */
	public WPBsktPTMAVO() {
		super();
		setType(AppConstants.Node.WPBSKTPTMA);
	}

}
