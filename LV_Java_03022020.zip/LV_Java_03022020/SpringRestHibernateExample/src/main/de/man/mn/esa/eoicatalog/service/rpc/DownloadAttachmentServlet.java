/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.service.rpc;

import java.io.IOException;
import java.nio.charset.Charset;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * The Class DownloadAttachmentServlet.
 * 
 * Author: Aathavan Sivasubramonian
 */
public class DownloadAttachmentServlet extends HttpServlet {

	/**
	 * Do post.
	 * 
	 * @param req
	 *            the req
	 * @param resp
	 *            the resp
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	/**
	 * Do get.
	 * 
	 * @param req
	 *            the req
	 * @param resp
	 *            the resp
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		// BOC: Additional parameter DMS_Order - R4867 - 31.08.2016
		String filename = req.getParameter("filename");
		if(filename == null || filename.trim().equals("")) {
			filename = "Download.xml";
		}
		// EOC: Additional parameter DMS_Order - R4867 - 31.08.2016
		
		resp.setContentType("text/xml;charset=UTF-8");
		// BOC: Additional parameter DMS_Order - R4867 - 31.08.2016
		resp.setHeader("Content-disposition", "attachment; filename="
				+ filename);
		// EOC: Additional parameter DMS_Order - R4867 - 31.08.2016

		String paramName = "xml";
		String buff = req.getParameter(paramName);
		if (buff == null) {
			buff = req.getSession().getAttribute("xml") + "";
		}
		ServletOutputStream outputStream = resp.getOutputStream();
		// BOC: Fix for broken special characters while Exporting - 07.07.2016
		outputStream.write(buff.getBytes(Charset.forName("UTF-8")));
		// EOC: Fix for broken special characters while Exporting - 07.07.2016
		
		/*for (int i = 0; i < buff.length(); ++i) {
			outputStream.write(buff.charAt(i));
		}*/
		outputStream.flush();
		outputStream.close();
	}
}