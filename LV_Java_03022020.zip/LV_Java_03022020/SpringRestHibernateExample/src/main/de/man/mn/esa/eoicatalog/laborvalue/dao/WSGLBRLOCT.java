/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */

package de.man.mn.esa.eoicatalog.laborvalue.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class WSGLBRLOCT.
 * 
 * Author: Reena Rawat
 */
@Entity
@Table(name = "WSGLBRLOCT")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class WSGLBRLOCT implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The LOCATION. */
	@Id
	@Column(name = "LOCATION")
	private String LOCATION; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The TEXT. */
	@Column(name = "TEXT")
	private String TEXT; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The SPRAS. */
	@Column(name = "SPRAS")
	private String SPRAS; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/** The PRCSTAT. */
	@Column(name = "PRCSTAT")
	private String PRCSTAT; // NOPMD by yuvraj_patil01 on 3/19/11 10:49 AM

	/**
	 * Gets the lOCATION.
	 * 
	 * @return the lOCATION
	 */
	public String getLOCATION() {
		return LOCATION;
	}

	/**
	 * Sets the lOCATION.
	 * 
	 * @param lOCATION
	 *            the new lOCATION
	 */
	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}

	/**
	 * Gets the tEXT.
	 * 
	 * @return the tEXT
	 */
	public String getTEXT() {
		return TEXT;
	}

	/**
	 * Sets the tEXT.
	 * 
	 * @param tEXT
	 *            the new tEXT
	 */
	public void setTEXT(String tEXT) {
		TEXT = tEXT;
	}

	/**
	 * Gets the sPRAS.
	 * 
	 * @return the sPRAS
	 */
	public String getSPRAS() {
		return SPRAS;
	}

	/**
	 * Sets the sPRAS.
	 * 
	 * @param sPRAS
	 *            the new sPRAS
	 */
	public void setSPRAS(String sPRAS) {
		SPRAS = sPRAS;
	}

	/**
	 * Gets the pRCSTAT.
	 * 
	 * @return the pRCSTAT
	 */
	public String getPRCSTAT() {
		return PRCSTAT;
	}

	/**
	 * Sets the pRCSTAT.
	 * 
	 * @param pRCSTAT
	 *            the new pRCSTAT
	 */
	public void setPRCSTAT(String pRCSTAT) {
		PRCSTAT = pRCSTAT;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		// hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof WSGLBRACTT)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "WSGLBROBJT=" + LOCATION + " " + TEXT + " " + SPRAS + " "
				+ PRCSTAT + "]";
	}

}
