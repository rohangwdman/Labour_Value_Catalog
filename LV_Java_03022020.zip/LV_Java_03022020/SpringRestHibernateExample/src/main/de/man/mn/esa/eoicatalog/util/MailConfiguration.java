/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.util;

import org.springframework.stereotype.Service;

/**
 * The Class MailConfiguration.
 * 
 * Author: Yuvraj Patil
 */
@Service
public class MailConfiguration {

	/** The host mail server. */
	private String hostMailServer;

	/** The host mail server port. */
	private String hostMailServerPort;

	/** The from. */
	private String from;

	/** The to. */
	private String to;

	/** The authenticate. */
	private String authenticate;

	/** The from user id password. */
	private String fromUserIDPassword;

	/**
	 * Gets the host Mail Server.
	 * 
	 * @return the host Mail Server
	 */
	public String getHostMailServer() {
		return hostMailServer;
	}

	/**
	 * Sets the host Mail Server.
	 * 
	 * @param hostMailServer
	 *            the new host Mail Server
	 */
	public void setHostMailServer(String hostMailServer) {
		this.hostMailServer = hostMailServer;
	}

	/**
	 * Gets the host Mail Server Port.
	 * 
	 * @return the host Mail Server Port
	 */
	public String getHostMailServerPort() {
		return hostMailServerPort;
	}

	/**
	 * Sets the host Mail Server Port.
	 * 
	 * @param hostMailServerPort
	 *            the new host Mail Server Port
	 */
	public void setHostMailServerPort(String hostMailServerPort) {
		this.hostMailServerPort = hostMailServerPort;
	}

	/**
	 * Gets the message from.
	 * 
	 * @return the message from
	 */
	public String getFrom() {
		return from;
	}

	/**
	 * Sets the message from.
	 * 
	 * @param from
	 *            the new message from
	 */
	public void setFrom(String from) {
		this.from = from;
	}

	/**
	 * Gets the message recipient.
	 * 
	 * @return the message recipient
	 */
	public String getTo() {
		return to;
	}

	/**
	 * Sets the message recipient.
	 * 
	 * @param to
	 *            the new message recipient
	 */
	public void setTo(String to) {
		this.to = to;
	}

	/**
	 * Gets the from user id is to be authenticate or not.
	 * 
	 * @return the from user id is to be authenticate or not
	 */
	public String getAuthenticate() {
		return authenticate;
	}

	/**
	 * Sets the from user id is to be authenticate or not.
	 * 
	 * @param authenticate
	 *            the new from user id is to be authenticate or not
	 */
	public void setAuthenticate(String authenticate) {
		this.authenticate = authenticate;
	}

	/**
	 * Gets the if authenticate = true then the needed password.
	 * 
	 * @return the if authenticate = true then the needed password
	 */
	public String getFromUserIDPassword() {
		return fromUserIDPassword;
	}

	/**
	 * Sets the if authenticate = true then the needed password.
	 * 
	 * @param fromUserIDPassword
	 *            the new if authenticate = true then the needed password
	 */
	public void setFromUserIDPassword(String fromUserIDPassword) {
		this.fromUserIDPassword = fromUserIDPassword;
	}
}