/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import org.springframework.stereotype.Service;

/**
 * The Class MailSender.
 * 
 * Author: Yuvraj Patil
 */
@Service
public class MailSender {

	/** The session. */
	private Session session;

	/** The mesg. */
	private Message mesg;

	/**
	 * Send mail.
	 * 
	 * @param mailConfiguration
	 *            the mail configuration
	 * @param message_subject
	 *            the message_subject
	 * @param message_body
	 *            the message_body
	 */
	public void sendMail(MailConfiguration mailConfiguration,
			String message_subject, String message_body) {

		Authenticator authenticator = new Authenticator(mailConfiguration);

		Properties props = new Properties();
		props.put("mail.smtp.host", mailConfiguration.getHostMailServer());

		if (mailConfiguration.getAuthenticate().equalsIgnoreCase("true")) {
			props.setProperty("mail.smtp.submitter", authenticator
					.getPasswordAuthentication().getUserName());
			props.setProperty("mail.smtp.auth", "true");
		}
		props.setProperty("mail.smtp.port",
				mailConfiguration.getHostMailServerPort());
		props.put("mail.smtp.connectiontimeout", "5000");
		props.put("mail.smtp.timeout", "5000");
		props.put("mail.smtp.quitwait", "false");
		session = Session.getInstance(props, authenticator);
		session.setDebug(true); // Verbose!
		try {
			// create a message
			mesg = new MimeMessage(session);

			// From Address - this should come from a Properties...
			mesg.setFrom(new InternetAddress(mailConfiguration.getFrom()));

			// TO Address
			mesg.addRecipient(RecipientType.TO, new InternetAddress(
					mailConfiguration.getTo()));

			// The Subject
			mesg.setSubject(message_subject);

			// Now the message body.
			mesg.setText(message_body);
			// XXX I18N: use setText(msgText.getText(), charset)

			//Provider provider = new Provider();
			
			//session.setProvider(provider)
			// Finally, send the message!
			Transport.send(mesg);

		} catch (MessagingException ex) {
			while ((ex = (MessagingException) ex.getNextException()) != null) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * The Class Authenticator.
	 * 
	 * Author: Yuvraj Patil
	 */
	private class Authenticator extends javax.mail.Authenticator {

		/** The authentication. */
		private PasswordAuthentication authentication;

		/**
		 * Instantiates a new authenticator.
		 * 
		 * @param mailConfiguration
		 *            the mail configuration
		 */
		public Authenticator(MailConfiguration mailConfiguration) {
			String username = mailConfiguration.getFrom();
			String password = mailConfiguration.getFromUserIDPassword();
			authentication = new PasswordAuthentication(username, password);
		}

		/**
		 * Gets the password authentication.
		 * 
		 * @return the password authentication
		 */
		protected PasswordAuthentication getPasswordAuthentication() {
			return authentication;
		}
	}

}