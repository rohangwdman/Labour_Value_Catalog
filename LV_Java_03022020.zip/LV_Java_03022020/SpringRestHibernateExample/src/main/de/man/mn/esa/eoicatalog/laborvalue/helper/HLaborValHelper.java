/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.laborvalue.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.AbstractQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.stat.SecondLevelCacheStatistics;
import org.hibernate.stat.Statistics;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRACTT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBROBJT;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRVAL;
import de.man.mn.esa.eoicatalog.laborvalue.dao.WSGLBRVRST;
import de.man.mn.esa.eoicatalog.share.common.vo.ActivityVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchChildVO;
import de.man.mn.esa.eoicatalog.share.common.vo.FetchMostValidWPAttributesVO;
import de.man.mn.esa.eoicatalog.share.common.vo.NodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.ObjectCodeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.PaginationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.RangeVO;
import de.man.mn.esa.eoicatalog.share.common.vo.UserVO;
import de.man.mn.esa.eoicatalog.share.common.vo.VersionLocationVO;
import de.man.mn.esa.eoicatalog.share.common.vo.WorkProcessVO;
import de.man.mn.esa.eoicatalog.share.constants.AppConstants;
import de.man.mn.esa.eoicatalog.share.exception.EOIException;
import de.man.mn.esa.eoicatalog.ui.util.UIUtil;
import net.sf.ehcache.search.expression.Criteria;

/**
 * The Class HLaborValHelper.
 * 
 * Author: Yuvraj Patil
 */
@Primary
@Repository
public class HLaborValHelper implements ILaborValHelper {

	/** The hibernate template. */
	@Autowired
	private HibernateTemplate hibernateTemplate;

	/** The error messages. */
	@Autowired
	private ErrorMessages errorMessages;
	
	@PersistenceContext
	EntityManager entityManager;

	/** The error msg. */
	private String errorMsg = "";

	/** The error code. */
	private String errorCode = "";

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(HLaborValHelper.class);

	// private static Session laborValSession;

	/**
	 * Sets the session factory.
	 * 
	 * @param sessionFactory
	 *            the new session factory
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
		this.hibernateTemplate.setCacheQueries(true);
		// this.laborValSession =
		// this.hibernateTemplate.getSessionFactory().openSession();
	}

	/**
	 * Sets the error messages.
	 * 
	 * @param errorMessages
	 *            the new error messages
	 */
	public void setErrorMessages(ErrorMessages errorMessages) {
		this.errorMessages = errorMessages;
	}

	public HLaborValHelper() {

	}

	public WorkProcessVO fetchMostValidWPAttributes(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {

		WorkProcessVO rtnWorkProcessVO = new WorkProcessVO();
		rtnWorkProcessVO.setoBJCD1("");
		rtnWorkProcessVO.setoBJCD2("");
		rtnWorkProcessVO.setoBJCD3("");
		rtnWorkProcessVO.setaCTIVITY("");
		rtnWorkProcessVO.setvERSION("");
		rtnWorkProcessVO.setlOCATION("");
		rtnWorkProcessVO.setiNSTALLCON("");
		rtnWorkProcessVO.setlABVAL("");
		boolean individualFieldIsValid = true;
		PaginationVO tempPaginationVO = new PaginationVO();
		WorkProcessVO tempWorkProcessVO = new WorkProcessVO();

		ObjectCodeVO tempNodeVO = new ObjectCodeVO();
        WorkProcessVO workProcessVO = fetchMostValidWPAttributesVO.getWorkProcessVO();
        UserVO userVO = fetchMostValidWPAttributesVO.getUserVO();
		tempNodeVO
				.setCode((UIUtil.formCodeOfNLength(workProcessVO.getoBJCD1(), 3)
						+ UIUtil.formCodeOfNLength(workProcessVO.getoBJCD2(), 1)
						+ UIUtil.formCodeOfNLength(workProcessVO.getoBJCD3(), 3)
						+ UIUtil.formCodeOfNLength(workProcessVO.getaCTIVITY(),
								3)
						+ UIUtil.formCodeOfNLength(workProcessVO.getvERSION(),
								2)
						+ UIUtil.formCodeOfNLength(workProcessVO.getlOCATION(),
								2) + UIUtil.formCodeOfNLength(
						workProcessVO.getiNSTALLCON(), 2)).replaceAll("\\s+$",
						""));

		if (isValidObjCode(userVO, tempWorkProcessVO, tempNodeVO)) {
			// rtndamageCodeVO.setdAMAGECODE(tempNodeVO.getCode());
			rtnWorkProcessVO.setoBJCD1(workProcessVO.getoBJCD1());
			rtnWorkProcessVO.setoBJCD2(workProcessVO.getoBJCD2());
			rtnWorkProcessVO.setoBJCD3(workProcessVO.getoBJCD3());
			rtnWorkProcessVO.setaCTIVITY(workProcessVO.getaCTIVITY());
			rtnWorkProcessVO.setvERSION(workProcessVO.getvERSION());
			rtnWorkProcessVO.setlOCATION(workProcessVO.getlOCATION());
			rtnWorkProcessVO.setiNSTALLCON(workProcessVO.getiNSTALLCON());
			return rtnWorkProcessVO;

		} else {
			// check if iNSTALLCON code is valid
			if (workProcessVO.getiNSTALLCON().length() > 0) {
				// check valid iNSTALLCON code
				tempPaginationVO = fetchConditionSearchList("%",
						workProcessVO.getiNSTALLCON(), userVO, tempPaginationVO);
				if (tempPaginationVO.getTotalRecords() > 0) {
					// valid iNSTALLCON
					rtnWorkProcessVO.setiNSTALLCON(workProcessVO
							.getiNSTALLCON());
				} else {
					// Invalid iNSTALLCON code
					individualFieldIsValid = false;
					rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
							+ ",e532");
					// rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL().substring(1));
					// return rtnWorkProcessVO;
				}
			}
			// check if lOCATION code is valid
			tempPaginationVO = new PaginationVO();
			if (workProcessVO.getlOCATION().length() > 0
					&& individualFieldIsValid) {
				// check valid lOCATION code
				tempPaginationVO = fetchLocationSearchList("%",
						workProcessVO.getlOCATION(), userVO, tempPaginationVO);
				if (tempPaginationVO.getTotalRecords() > 0) {
					// valid lOCATION
					rtnWorkProcessVO.setlOCATION(workProcessVO.getlOCATION());
				} else {
					// Invalid lOCATION code
					individualFieldIsValid = false;
					rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
							+ ",e531");
					// rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL().substring(1));
					// return rtnWorkProcessVO;
				}
			}
			// check if vERSION code is valid
			tempPaginationVO = new PaginationVO();
			if (workProcessVO.getvERSION().length() > 0
					&& individualFieldIsValid) {
				// check valid vERSION code
				tempPaginationVO = fetchVersionSearchList("%",
						workProcessVO.getvERSION(), userVO, tempPaginationVO);
				if (tempPaginationVO.getTotalRecords() > 0) {
					// valid vERSION
					rtnWorkProcessVO.setvERSION(workProcessVO.getvERSION());
				} else {
					// Invalid vERSION code
					individualFieldIsValid = false;
					rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
							+ ",e530");
					// rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL().substring(1));
					// return rtnWorkProcessVO;
				}
			}
			// check if aCTIVITY code is valid
			tempPaginationVO = new PaginationVO();
			if (workProcessVO.getaCTIVITY().length() > 0
					&& individualFieldIsValid) {
				// check valid aCTIVITY code
				tempPaginationVO = fetchActivitySearchList("%",
						workProcessVO.getaCTIVITY(), userVO, tempPaginationVO);
				if (tempPaginationVO.getTotalRecords() > 0) {
					// valid aCTIVITY
					rtnWorkProcessVO.setaCTIVITY(workProcessVO.getaCTIVITY());
				} else {
					// Invalid aCTIVITY code
					individualFieldIsValid = false;
					rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
							+ ",e529");
					// rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL().substring(1));
					// return rtnWorkProcessVO;
				}
			}
			// check if object code is valid
			if ((workProcessVO.getoBJCD1() + workProcessVO.getoBJCD2() + workProcessVO
					.getoBJCD3()).length() > 0) {
				tempNodeVO
						.setCode((workProcessVO.getoBJCD1()
								+ workProcessVO.getoBJCD2() + workProcessVO
								.getoBJCD3()).trim());
				WorkProcessVO checkedObjCodeDC = fetchValidObjCode(userVO,
						tempWorkProcessVO, tempNodeVO);
				if ((checkedObjCodeDC.getoBJCD1()
						+ checkedObjCodeDC.getoBJCD2() + checkedObjCodeDC
						.getoBJCD3()).trim().length() > 0) {
					if (((checkedObjCodeDC.getoBJCD1()
							+ checkedObjCodeDC.getoBJCD2() + checkedObjCodeDC
							.getoBJCD3()).trim())
							.equalsIgnoreCase((workProcessVO.getoBJCD1()
									+ workProcessVO.getoBJCD2() + workProcessVO
									.getoBJCD3()).trim())) {
						// Full Valid code
					} else {
						// partial valid code
						rtnWorkProcessVO
								.setoBJCD1(checkedObjCodeDC.getoBJCD1());
						rtnWorkProcessVO
								.setoBJCD2(checkedObjCodeDC.getoBJCD2());
						rtnWorkProcessVO
								.setoBJCD3(checkedObjCodeDC.getoBJCD3());
						rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
								+ ",e528");
						if (individualFieldIsValid) {
							individualFieldIsValid = false;
							tempNodeVO
									.setCode((UIUtil.formCodeOfNLength(
											rtnWorkProcessVO.getoBJCD1(), 3)
											+ UIUtil.formCodeOfNLength(
													rtnWorkProcessVO
															.getoBJCD2(), 1)
											+ UIUtil.formCodeOfNLength(
													rtnWorkProcessVO
															.getoBJCD3(), 3)
											+ UIUtil.formCodeOfNLength(
													workProcessVO.getaCTIVITY(),
													3)
											+ UIUtil.formCodeOfNLength(
													workProcessVO.getvERSION(),
													2)
											+ UIUtil.formCodeOfNLength(
													workProcessVO.getlOCATION(),
													2) + UIUtil
											.formCodeOfNLength(workProcessVO
													.getiNSTALLCON(), 2))
											.replaceAll("\\s+$", ""));
							if (isValidObjCode(userVO, tempWorkProcessVO,
									tempNodeVO)) {
								// With Processed Obj code the combination is
								// valid
							} else {
								rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO
										.getlABVAL() + ",e533");
							}
						}
						// rtnWorkProcessVO`.setlABVAL(rtnWorkProcessVO.getlABVAL().substring(1));
						// return rtnWorkProcessVO;
					}
				} else {
					// Invalid Object Code
					individualFieldIsValid = false;
					rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
							+ ",e527");
					// rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL().substring(1));
					// return rtnWorkProcessVO;
				}
			}
			if (individualFieldIsValid) {
				rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
						+ ",e533");
			}

			if (rtnWorkProcessVO.getlABVAL().length() > 0
					&& rtnWorkProcessVO.getlABVAL().indexOf(",") == 0) {
				rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL()
						.substring(1));
			}

			// if (individualFieldIsValid) {
			// rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL() +
			// ",e533");
			// rtnWorkProcessVO.setlABVAL(rtnWorkProcessVO.getlABVAL().substring(1));
			// }
		}
		return rtnWorkProcessVO;
	}

	// ** modified for Hibernate function calls
	/**
	 * Fetch valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the work process vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public WorkProcessVO fetchValidObjCode(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		workProcessVO.setoBJCD1(objCD1);
		workProcessVO.setoBJCD2(objCD2);
		workProcessVO.setoBJCD3(objCD3);
		try {
			while (nodeVO.getCode().length() > 0) {
				if (isValidObjCode(userVO, workProcessVO, nodeVO)) {
					String nodeCode = nodeVO.getCode();
					if (nodeCode.length() >= 3) {
						objCD1 = nodeCode.substring(0, 3);
					} else {
						objCD1 = nodeCode.substring(0, nodeCode.length());
					}

					if (nodeCode.length() >= 4) {
						objCD2 = nodeCode.substring(3, 4);
					}

					if (nodeCode.length() >= 5) {
						objCD3 = nodeCode.substring(4, nodeCode.length());
					}
					workProcessVO.setoBJCD1(objCD1);
					workProcessVO.setoBJCD2(objCD2);
					workProcessVO.setoBJCD3(objCD3);
					return workProcessVO;
				} else {
					nodeVO.setCode(nodeVO.getCode().substring(0,
							(nodeVO.getCode().length() - 1)));
				}
			}
		} catch (Exception e) {
			errorCode = "e001";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		}
		return workProcessVO;
	}

	// ** Hibernate Function 1
	/**
	 * Checks if is valid obj code.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid obj code
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidObjCode(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO) throws EOIException {
		List result = null;
		Session laborValSession = null;
		try {
			// LOGGER.info("Inside ** Hibernate Function 1 -> isValidObjCodeHibernate ");
			String code = nodeVO.getCode();
			String qry = "";
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT LABVAL FROM {h-schema}WSGLBRVAL WHERE PRCSTAT = 'A' AND RANGE like "
						+ ":range AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H' AND LABVAL like :code ";
			} else {
				qry = "SELECT LABVAL FROM {h-schema}WSGLBRVAL WHERE PRCSTAT = 'A' AND RANGE like "
						+ ":range AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H' AND LABVAL like :code ";
			}
			// Query query = laborValSession.createSQLQuery(qry);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);
			if (userVO.getModel().equalsIgnoreCase("All")) {
				query.setParameter("range", "%");
			} else {
				query.setParameter("range", userVO.getModel());
			}
			if (!userVO.getVariant().equalsIgnoreCase("All")) {
				query.setParameter("variant", userVO.getVariant());
			}
			query.setParameter("code", code + "%");
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			if (result.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			errorCode = "e002";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return false;
	}

	// ** Hibernate function 2
	/**
	 * Checks if is valid wp attribute combination.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is valid wp attribute combination
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isValidWPAttributeCombination(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {
		List result = null;
		Session laborValSession = null;
		try {
			// LOGGER.info("Inside ** Hibernate Function 2 -> isValidWPAttributeCombinationHibernate ");
			String qry = "";
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT LABVAL FROM {h-schema}WSGLBRVAL WHERE PRCSTAT = 'A' AND RANGE like "
						+ ":range AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H' AND LABVAL like :code ";
			} else {
				qry = "SELECT LABVAL FROM {h-schema}WSGLBRVAL WHERE PRCSTAT = 'A' AND RANGE like "
						+ ":range AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H' AND LABVAL like :code ";
			}
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);
			TypedQuery<Object> tquery = laborValSession.createQuery(qry);
			if (userVO.getModel().equalsIgnoreCase("All")) {
				query.setParameter("range", "%");
			} else {
				query.setParameter("range", userVO.getModel());
			}
			if (!userVO.getVariant().equalsIgnoreCase("All")) {
				query.setParameter("variant", userVO.getVariant());
			}
			query.setParameter("code", nodeVO.getCode() + "%");
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			if (result.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			errorCode = "e003";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return false;
	}

	// ** Hibernate function 3
	/**
	 * Fetch root nodes.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List fetchRootNodes(UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session laborValSession = null;
		try {
			LOGGER.info("Inside ** Hibernate Function 3 -> fetchRootNodesHibernate ");
			String qry = "";
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT OBJCD1, TEXT FROM  {h-schema}WSGLBROBJT where PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,1)) from  {h-schema}WSGLBRVAL where "
						+ "PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY OBJCD1";
			} else {
				qry = "SELECT DISTINCT OBJCD1, TEXT FROM  {h-schema}WSGLBROBJT where PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 in (SELECT DISTINCT(SUBSTR(LABVAL,1,1)) from  {h-schema}WSGLBRVAL where "
						+ "PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY OBJCD1";
			}
	
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);
			query.setParameter("language", userVO.getLanguage());
			if (userVO.getModel().equalsIgnoreCase("All")) {
				query.setParameter("range", "%");
			} else {
				query.setParameter("range", userVO.getModel());
			}
			if (!userVO.getVariant().equalsIgnoreCase("All")) {
				query.setParameter("variant", userVO.getVariant());
			}
		
			//query.setCacheable(true);
			//query.setCacheRegion("eoicatalog.ehcache");
			
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBROBJT.class)).list();
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				node.setHasChildren(true);
				//node.setChildren(new ArrayList<NodeVO>());
				nodeList.add(node);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			errorCode = "e004";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} 
		return nodeList;

	}

	// ** Hibernate function 4
	/**
	 * Fetch range list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchRangeList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		List result = null;
		List<RangeVO> returnRangeList = new ArrayList<RangeVO>();
		Session laborValSession = null;
		try {
			// LOGGER.info("Inside ** Hibernate Function 4 -> fetchRangeListHibernate ");
			String qry = formQryOfRange(rangeVO, userVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createQuery(qry);
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			for (int i = 0; i < result.size(); i++) {
				RangeVO range = new RangeVO();
				range.setModel(result.get(i) + "");
				returnRangeList.add(range);
			}
		} catch (Exception e) {
			errorCode = "e005";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}

		return returnRangeList;
	}

	/**
	 * Fetch unit.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	public String fetchUnit(UserVO userVO) throws EOIException {
		// TODO Auto-generated method stub
		List result = null;
		String UOMT = "";
		Session laborValSession = null;
		try {
			String qry = formQryOfUnit(userVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createQuery(qry);
			query.setParameter("language", userVO.getLanguage());
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			for (int i = 0; i < result.size(); i++) {
				UOMT = result.get(i) + "";
			}
			userVO.setUnit(UOMT);
		} catch (Exception e) {
			errorCode = "e006";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return UOMT;
	}

	/**
	 * Fetch language.
	 * 
	 * @param spras
	 *            the spras
	 * @return the string
	 * @throws EOIException
	 *             the eOI exception
	 */
	public String fetchLanguage(String spras) throws EOIException {
		// TODO Auto-generated method stub

		List result = null;
		String lang = "";
		Session laborValSession = null;
		try {
			String qry = formQryForLang(spras);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createQuery(qry);
			query.setParameter("lang", spras);
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			for (int i = 0; i < result.size(); i++) {
				lang = result.get(i) + "";
			}
		} catch (Exception e) {
			errorCode = "e007";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error(
					"Message: " + errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return lang;
	}

	// ** Hibernate function 5
	/**
	 * Fetch variant list.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchVariantList(RangeVO rangeVO, UserVO userVO)
			throws EOIException {
		List result = null;
		List<RangeVO> returnVariantList = new ArrayList<RangeVO>();
		Session laborValSession = null;
		try {
			// LOGGER.info("Inside ** Hibernate Function 5 -> fetchVariantListHibernate ");
			String qry = formQryOfVariant(rangeVO, userVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createQuery(qry);
			if (rangeVO.getModel().equalsIgnoreCase("All")) {
				query.setParameter("range", "%");
			} else {
				query.setParameter("range", rangeVO.getModel());
			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			for (int i = 0; i < result.size(); i++) {
				RangeVO range = new RangeVO();
				range.setVariant(result.get(i) + "");
				returnVariantList.add(range);
			}
		} catch (Exception e) {
			errorCode = "e008";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return returnVariantList;
	}

	// ** modified for Hibernate function calls
	/**
	 * Fetch child nodes.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildNodes(FetchChildVO fetchChildVO) throws EOIException {
		List returnNodes = new ArrayList();
		NodeVO nodeVO = fetchChildVO.getNodeVO();
		if (nodeVO.getType() == AppConstants.Node.OBJECT) {
			if (nodeVO.getLevel() >= 1 & nodeVO.getLevel() <= 4) {
				List actNodes = fetchChildActivities(fetchChildVO.getWorkProcessVO(), nodeVO,
						fetchChildVO.getUserVO());
				returnNodes.addAll(actNodes);
				List objNodes = fetchChildObjects(fetchChildVO.getWorkProcessVO(), nodeVO,
						fetchChildVO.getUserVO());
				returnNodes.addAll(objNodes);
			} else if (nodeVO.getLevel() == 5) {
				List actNodes = fetchChildActivities(fetchChildVO.getWorkProcessVO(), nodeVO,
						fetchChildVO.getUserVO());
				returnNodes.addAll(actNodes);
			}
		} else if (nodeVO.getType() == AppConstants.Node.ACTIVITY) {
			List versionNodes = fetchChildVersions(fetchChildVO.getWorkProcessVO(), nodeVO,
					fetchChildVO.getUserVO());
			returnNodes.addAll(versionNodes);
		}
		return returnNodes;
	}

	// ** Hibernate function 6
	/**
	 * Fetch child objects.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildObjects(WorkProcessVO workProcessVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session laborValSession = null;
		try {
			// LOGGER.info("Inside ** Hibernate Function 6 -> fetchChildObjectsHibernate ");
			String qry = formQryOfChildObjects(workProcessVO, nodeVO, userVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);

			if (nodeVO.getLevel() == 1) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode() + "%");
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			} else if (nodeVO.getLevel() == 2) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode() + "%");
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			} else if (nodeVO.getLevel() == 3) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			} else if (nodeVO.getLevel() == 4) {
				workProcessVO
						.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
				workProcessVO
						.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("code2", workProcessVO.getoBJCD2());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBROBJT.class)).list();

			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ObjectCodeVO();
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(true);
				//node.setChildren(new ArrayList<NodeVO>());
				if (nodeVO.getLevel() == 1) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 2) {
					node.setCode(((WSGLBROBJT) result.get(i)).getOBJCD1());
				} else if (nodeVO.getLevel() == 3) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD2());
				} else if (nodeVO.getLevel() == 4) {
					node.setCode(UIUtil.formCodeOfNLength(
							((WSGLBROBJT) result.get(i)).getOBJCD1(), 3)
							+ UIUtil.formCodeOfNLength(
									((WSGLBROBJT) result.get(i)).getOBJCD2(), 1)
							+ ((WSGLBROBJT) result.get(i)).getOBJCD3());
				}
				node.setLevel(nodeVO.getLevel() + 1);
				node.setName(((WSGLBROBJT) result.get(i)).getTEXT());
				nodeList.add(node);
			}
		} catch (Exception e) {
			errorCode = "e009";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return nodeList;
	}

	// ** Hibernate function 7
	/**
	 * Fetch child activities.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildActivities(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session laborValSession = null;
		try {
			// LOGGER.info("Inside ** Hibernate Function 7 -> fetchChildActivitiesHibernate ");
			String qry = formQryOfChildActivities(workProcessVO, nodeVO, userVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);

			if (nodeVO.getLevel() == 1) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", nodeVO.getCode());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}

			} else if (nodeVO.getLevel() == 2) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", nodeVO.getCode());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}

			} else if (nodeVO.getLevel() == 3) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", nodeVO.getCode());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}

			} else if (nodeVO.getLevel() == 4) {
				workProcessVO
						.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
				workProcessVO
						.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("code2", workProcessVO.getoBJCD2());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}

			} else if (nodeVO.getLevel() == 5) {
				workProcessVO
						.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
				workProcessVO
						.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
				workProcessVO
						.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("code2", workProcessVO.getoBJCD2());
				query.setParameter("code3", workProcessVO.getoBJCD3());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}

			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBRACTT.class)).list();
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new ActivityVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 7)
						+ ((WSGLBRACTT) result.get(i)).getACTIVITY());
				node.setLevel(nodeVO.getLevel());
				// if (isActivityHavingChildNodes(workProcessVO, node, userVO))
				// {
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(true);
				//node.setChildren(new ArrayList<NodeVO>());
				// } else {
				// node.setHavingChildNodes(false);
				// }
				node.setName(((WSGLBRACTT) result.get(i)).getTEXT());
				nodeList.add(node);
			}

		} catch (Exception e) {
			errorCode = "e010";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return nodeList;
	}

	// ** Hibernate function 8
	/**
	 * Fetch child versions.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchChildVersions(WorkProcessVO workProcessVO, NodeVO nodeVO,
			UserVO userVO) throws EOIException {
		List result = null;
		List<NodeVO> nodeList = new ArrayList<NodeVO>();
		Session laborValSession = null;
		try {
			// LOGGER.info("Inside ** Hibernate Function 8 -> fetchChildVersionsHibernate ");
			workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3).trim());
			workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4).trim());
			workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7).trim());
			workProcessVO.setaCTIVITY(nodeVO.getCode().substring(7, 10).trim());

			String qry = formQryOfChildVersions(workProcessVO, nodeVO, userVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);

			if (nodeVO.getLevel() == 1) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("activity", workProcessVO.getaCTIVITY());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			} else if (nodeVO.getLevel() == 2) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("activity", workProcessVO.getaCTIVITY());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			} else if (nodeVO.getLevel() == 3) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("activity", workProcessVO.getaCTIVITY());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			} else if (nodeVO.getLevel() == 4) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("code2", workProcessVO.getoBJCD2());
				query.setParameter("activity", workProcessVO.getaCTIVITY());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			} else if (nodeVO.getLevel() == 5) {
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code1", workProcessVO.getoBJCD1());
				query.setParameter("code2", workProcessVO.getoBJCD2());
				query.setParameter("code3", workProcessVO.getoBJCD3());
				query.setParameter("activity", workProcessVO.getaCTIVITY());
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBRVRST.class)).list();
			for (int i = 0; i < result.size(); i++) {
				NodeVO node = new VersionLocationVO();
				node.setCode(UIUtil.formCodeOfNLength(nodeVO.getCode(), 10)
						+ (((WSGLBRVRST) result.get(i)).getVERSION()));
				node.setLevel(nodeVO.getLevel());
				node.setChildNodesHaveBeenFetched(false);
				node.setHasChildren(false);
				node.setName(((WSGLBRVRST) result.get(i)).getTEXT());
				nodeList.add(node);
			}

		} catch (Exception e) {
			errorCode = "e011";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return nodeList;
	}

	// ** modified for Hibernate function calls
	/**
	 * Checks if is activity having child nodes.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return true, if is activity having child nodes
	 * @throws EOIException
	 *             the eOI exception
	 */
	private boolean isActivityHavingChildNodes(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) throws EOIException {
		List result = fetchChildVersions(workProcessVO, nodeVO, userVO);
		if (result.size() > 0) {
			return true;
		}
		return false;
	}

	// ** Hibernate function 9
	/**
	 * Fetch wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		List result = null;
		Session laborValSession = null;
		PaginationVO paginationVO = fetchMostValidWPAttributesVO.getPaginationVO();
		UserVO userVO = fetchMostValidWPAttributesVO.getUserVO();
		WorkProcessVO workProcessVO = fetchMostValidWPAttributesVO.getWorkProcessVO();
		NodeVO nodeVO = fetchMostValidWPAttributesVO.getNodeVO();
		try {
			// LOGGER.info("Inside ** Hibernate Function 9 -> fetchWPListHibernate ");
			String qry = "";
			workProcessVO.setoBJCD1("");
			workProcessVO.setoBJCD2("");
			workProcessVO.setoBJCD3("");

			if (null != workProcessVO.getlABVAL()) {
				if (workProcessVO.getlABVAL().length() >= 3) {
					workProcessVO.setoBJCD1(workProcessVO.getlABVAL()
							.substring(0, 3));
				} else {
					workProcessVO.setoBJCD1(workProcessVO.getlABVAL()
							.substring(0, workProcessVO.getlABVAL().length()));
				}

				if (workProcessVO.getlABVAL().length() >= 4) {
					workProcessVO.setoBJCD2(workProcessVO.getlABVAL()
							.substring(3, 4));
				}

				if (workProcessVO.getlABVAL().length() >= 5) {
					if (workProcessVO.getlABVAL().length() >= 7) {
						workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
								.substring(4, 7));
					} else {
						workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
								.substring(4,
										workProcessVO.getlABVAL().length()));
					}
				}
			} else {
				if (nodeVO.getCode().length() >= 3) {
					workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3));
				} else {
					workProcessVO.setoBJCD1(nodeVO.getCode().substring(0,
							nodeVO.getCode().length()));
				}

				if (nodeVO.getCode().length() >= 4) {
					workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4));
				}

				if (nodeVO.getCode().length() >= 5) {
					if (nodeVO.getCode().length() >= 7) {
						workProcessVO.setoBJCD3(nodeVO.getCode()
								.substring(4, 7));
					} else {
						workProcessVO.setoBJCD3(nodeVO.getCode().substring(4,
								nodeVO.getCode().length()));
					}
				}
			}
			if (paginationVO.getCurrentPage() == 0) {
				// qry = formWPListQry(userVO, workProcessVO, nodeVO,
				// paginationVO);
				qry = formWPListCountQry(userVO, workProcessVO, nodeVO,
						paginationVO);
				int i = 0;
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query1.setParameter("range", "%");
				} else {
					query1.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query1.setParameter("variant", userVO.getVariant());
				}
				if (!workProcessVO.getoBJCD1().trim().equals("")) {
					query1.setParameter("objcd1", workProcessVO.getoBJCD1()
							.trim());
				}
				if (!workProcessVO.getoBJCD2().trim().equals("")) {
					query1.setParameter("objcd2", workProcessVO.getoBJCD2()
							.trim());
				}
				if (!workProcessVO.getoBJCD3().trim().equals("")) {
					query1.setParameter("objcd3", workProcessVO.getoBJCD3()
							.trim());
				}
				query1.setParameter("language", userVO.getLanguage());
				query1.setParameter("code", nodeVO.getCode().trim() + "%");
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());

				qry = formWPListQry(userVO, workProcessVO, nodeVO, paginationVO);
				Query query2 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query2.setParameter("range", "%");
				} else {
					query2.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query2.setParameter("variant", userVO.getVariant());
				}
				if (!workProcessVO.getoBJCD1().trim().equals("")) {
					query2.setParameter("objcd1", workProcessVO.getoBJCD1()
							.trim());
				}
				if (!workProcessVO.getoBJCD2().trim().equals("")) {
					query2.setParameter("objcd2", workProcessVO.getoBJCD2()
							.trim());
				}
				if (!workProcessVO.getoBJCD3().trim().equals("")) {
					query2.setParameter("objcd3", workProcessVO.getoBJCD3()
							.trim());
				}
				query2.setParameter("language", userVO.getLanguage());
				query2.setParameter("code", nodeVO.getCode().trim() + "%");
				if (paginationVO.getCurrentPage() != 0) {
					query2.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query2.setParameter("endRowNum",
							paginationVO.getEndRowNum());
				}
				query2.setCacheable(true);
				query2.setCacheRegion("eoicatalog.ehcache");
				result = query2.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
				// .setFirstResult(paginationVO.getStartRowNum())
				// .setMaxResults(paginationVO.getEndRowNum())
			} else {
				qry = formWPListQry(userVO, workProcessVO, nodeVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
				if (!workProcessVO.getoBJCD1().trim().equals("")) {
					query.setParameter("objcd1", workProcessVO.getoBJCD1()
							.trim());
				}
				if (!workProcessVO.getoBJCD2().trim().equals("")) {
					query.setParameter("objcd2", workProcessVO.getoBJCD2()
							.trim());
				}
				if (!workProcessVO.getoBJCD3().trim().equals("")) {
					query.setParameter("objcd3", workProcessVO.getoBJCD3()
							.trim());
				}
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("code", nodeVO.getCode().trim() + "%");
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
				// .setFirstResult(paginationVO.getStartRowNum())
				// .setMaxResults(paginationVO.getEndRowNum())
				// set the fetched list in pageVO
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);
		} catch (Exception e) {
			errorCode = "e012";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return paginationVO;
	}

	// ** Hibernate function 10
	/**
	 * Fetch included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List fetchIncludedWPList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		List result = null;
		List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
		Session laborValSession = null;
		WorkProcessVO workProcessVO = fetchMostValidWPAttributesVO.getWorkProcessVO();
		UserVO userVO = fetchMostValidWPAttributesVO.getUserVO();
		NodeVO nodeVO = fetchMostValidWPAttributesVO.getNodeVO();
		try {
			// LOGGER.info("Inside ** Hibernate Function 10 -> fetchIncludedWPListHibernate ");
			String qry = "";
			String objCD1 = "";
			String objCD2 = "";
			String objCD3 = "";
			if (workProcessVO.getoBJCD1() != null) {
				objCD1 = workProcessVO.getoBJCD1();
				// objCD1 = formCodeOfNLength(objCD1,3);
			}
			if (workProcessVO.getoBJCD2() != null) {
				objCD2 = workProcessVO.getoBJCD2();
				// objCD2 = formCodeOfNLength(objCD2,1);
			}
			if (workProcessVO.getoBJCD3() != null) {
				objCD3 = workProcessVO.getoBJCD3();
				// objCD3 = formCodeOfNLength(objCD3,3);
			}
			qry = formIncludedWPListQry(userVO, workProcessVO, nodeVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);
			if (!objCD1.equals("")) {
				query.setParameter("objcd1", objCD1);
			}
			if (!objCD2.equals("")) {
				query.setParameter("objcd2", objCD2);
			}
			if (!objCD3.equals("")) {
				query.setParameter("objcd3", objCD3);
			}

			query.setParameter("activity", workProcessVO.getaCTIVITY());
			query.setParameter("version", workProcessVO.getvERSION());
			query.setParameter("location", workProcessVO.getlOCATION());
			query.setParameter("installCon", workProcessVO.getiNSTALLCON());
			query.setParameter("jobtype", workProcessVO.getjOBTYPE());
			// if (userVO.getModel().equalsIgnoreCase("All")) {
			// query.setParameter("range", "%");
			// } else {
			// query.setParameter("range", userVO.getModel());
			// }
			query.setParameter("range", workProcessVO.getrANGE());
			// if (!userVO.getVariant().equalsIgnoreCase("All")) {
			// query.setParameter("variant", userVO.getVariant());
			// }
			query.setParameter("variant", workProcessVO.getlBRVARIANT());
			query.setParameter("language", userVO.getLanguage());

			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBRVAL.class)).list();
			populateIncludedWPDataInVO(result, voList);
		} catch (Exception e) {
			errorCode = "e013";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return voList;
	}

	/**
	 * Checks if is wP having not included wp list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return true, if is wP having not included wp list
	 * @throws EOIException
	 *             the eOI exception
	 */
	public boolean isWPHavingNotIncludedWPList(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) throws EOIException {

		boolean returnVal = false;
		List result = null;
		Session laborValSession = null;
		try {
			String qry = "";
			String objCD1 = "";
			String objCD2 = "";
			String objCD3 = "";
			if (workProcessVO.getoBJCD1() != null) {
				objCD1 = workProcessVO.getoBJCD1().trim();
				// objCD1 = formCodeOfNLength(objCD1,3);
			}
			if (workProcessVO.getoBJCD2() != null) {
				objCD2 = workProcessVO.getoBJCD2().trim();
				// objCD2 = formCodeOfNLength(objCD2,1);
			}
			if (workProcessVO.getoBJCD3() != null) {
				objCD3 = workProcessVO.getoBJCD3().trim();
				// objCD3 = formCodeOfNLength(objCD3,3);
			}
			qry = formNotIncludedWPListQry(userVO, workProcessVO, nodeVO);

			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);
			query.setParameter("objcd1", objCD1);
			if (!objCD2.equals("")) {
				query.setParameter("objcd2", objCD2);
			}
			if (!objCD3.equals("")) {
				query.setParameter("objcd3", objCD3);
			}
			query.setParameter("activity", workProcessVO.getaCTIVITY());
			query.setParameter("version", workProcessVO.getvERSION());
			query.setParameter("location", workProcessVO.getlOCATION());
			query.setParameter("installCon", workProcessVO.getiNSTALLCON());
			query.setParameter("jobtype", workProcessVO.getjOBTYPE());
			// if (userVO.getModel().equalsIgnoreCase("All")) {
			// query.setParameter("range", "%");
			// } else {
			// query.setParameter("range", userVO.getModel());
			// }
			query.setParameter("range", workProcessVO.getrANGE());

			// if (!userVO.getVariant().equalsIgnoreCase("All")) {
			// query.setParameter("variant", userVO.getVariant());
			// }
			query.setParameter("variant", workProcessVO.getlBRVARIANT());
			query.setParameter("language", userVO.getLanguage());
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBRVAL.class)).list();
			if (result.size() > 0) {
				returnVal = true;
			}
		} catch (Exception e) {
			errorCode = "e014";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return returnVal;
	}

	// ** Hibernate function 11
	/**
	 * Fetch not included wp with details list.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the hash map
	 * @throws EOIException
	 *             the eOI exception
	 */
	public List<WorkProcessVO> fetchNotIncludedWPWithDetailsList(FetchMostValidWPAttributesVO fetchMostValidWPAttributesVO) throws EOIException {
		Long inTime = System.currentTimeMillis();
		List result = null;
		List<WorkProcessVO> topWPList = new ArrayList<WorkProcessVO>();
		HashMap hMap = new HashMap();
		List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
		Session laborValSession = null;
		WorkProcessVO workProcessVO = fetchMostValidWPAttributesVO.getWorkProcessVO();
		UserVO userVO = fetchMostValidWPAttributesVO.getUserVO();
		NodeVO nodeVO = fetchMostValidWPAttributesVO.getNodeVO();
		try {
			// LOGGER.info("Inside ** Hibernate Function 11 -> fetchNotIncludedWPWithDetailsListHibernate ");
			String qry = "";
			String objCD1 = "";
			String objCD2 = "";
			String objCD3 = "";
			if (workProcessVO.getoBJCD1() != null) {
				objCD1 = workProcessVO.getoBJCD1().trim();
				// objCD1 = formCodeOfNLength(objCD1,3);
			}
			if (workProcessVO.getoBJCD2() != null) {
				objCD2 = workProcessVO.getoBJCD2().trim();
				// objCD2 = formCodeOfNLength(objCD2,1);
			}
			if (workProcessVO.getoBJCD3() != null) {
				objCD3 = workProcessVO.getoBJCD3().trim();
				// objCD3 = formCodeOfNLength(objCD3,3);
			}
			qry = formNotIncludedWPListQry(userVO, workProcessVO, nodeVO);
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);
			if (!objCD1.equals("")) {
				query.setParameter("objcd1", objCD1);
			}
			if (!objCD2.equals("")) {
				query.setParameter("objcd2", objCD2);
			}
			if (!objCD3.equals("")) {
				query.setParameter("objcd3", objCD3);
			}
			query.setParameter("activity", workProcessVO.getaCTIVITY());
			query.setParameter("version", workProcessVO.getvERSION());
			query.setParameter("location", workProcessVO.getlOCATION());
			query.setParameter("installCon", workProcessVO.getiNSTALLCON());
			query.setParameter("jobtype", workProcessVO.getjOBTYPE());

			// if (userVO.getModel().equalsIgnoreCase("All")) {
			// query.setParameter("range", "%");
			// } else {
			// query.setParameter("range", userVO.getModel());
			// }
			query.setParameter("range", workProcessVO.getrANGE());

			// if (!userVO.getVariant().equalsIgnoreCase("All")) {
			// query.setParameter("variant", userVO.getVariant());
			// }
			query.setParameter("variant", workProcessVO.getlBRVARIANT());

			query.setParameter("language", userVO.getLanguage());
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.setResultTransformer(
					Transformers.aliasToBean(WSGLBRVAL.class)).list();
			populateIncludedWPDataInVO(result, voList);
			result = null;

			objCD1 = "";
			objCD2 = "";
			objCD3 = "";
			if (workProcessVO.getoBJCD1() != null) {
				objCD1 = workProcessVO.getoBJCD1();
				objCD1 = UIUtil.formCodeOfNLength(objCD1, 3);
			}
			if (workProcessVO.getoBJCD2() != null) {
				objCD2 = workProcessVO.getoBJCD2();
				objCD2 = UIUtil.formCodeOfNLength(objCD2, 1);
			}
			if (workProcessVO.getoBJCD3() != null) {
				objCD3 = workProcessVO.getoBJCD3();
				objCD3 = UIUtil.formCodeOfNLength(objCD3, 3);
			}
			String code = objCD1 + objCD2 + objCD3;
			if (workProcessVO.getaCTIVITY() == null) {
				workProcessVO.setaCTIVITY("");
			}
			if (workProcessVO.getvERSION() == null) {
				workProcessVO.setvERSION("");
			}
			if (workProcessVO.getlOCATION() == null) {
				workProcessVO.setlOCATION("");
			}
			if (workProcessVO.getiNSTALLCON() == null) {
				workProcessVO.setiNSTALLCON("");
			}
			for (int i = 0; i < voList.size(); i++) {
				WorkProcessVO vo = (WorkProcessVO) voList.get(i);
				qry = formNotIncludedWPDetailsQry(userVO, vo, nodeVO);
				objCD1 = "";
				objCD2 = "";
				objCD3 = "";
				if (vo.getoBJCD1() != null) {
					objCD1 = vo.getoBJCD1();
					objCD1 = UIUtil.formCodeOfNLength(objCD1, 3);
				}
				if (vo.getoBJCD2() != null) {
					objCD2 = vo.getoBJCD2();
					objCD2 = UIUtil.formCodeOfNLength(objCD2, 1);
				}
				if (vo.getoBJCD3() != null) {
					objCD3 = vo.getoBJCD3();
					objCD3 = UIUtil.formCodeOfNLength(objCD3, 3);
				}
				code = objCD1 + objCD2 + objCD3;

				List<WorkProcessVO> voDetailsList = new ArrayList<WorkProcessVO>();
				Query query1 = laborValSession.createSQLQuery(qry);
				// if (userVO.getModel().equalsIgnoreCase("All")) {
				// query1.setParameter("range", "%");
				// } else {
				// query1.setParameter("range", userVO.getModel());
				// }
				// BOC: Range and Variant parameters for query should be equal the one selected in UI - 14.02.2017 - R4867
				query1.setParameter("range", workProcessVO.getrANGE());
				// if (!userVO.getVariant().equalsIgnoreCase("All")) {
				// query1.setParameter("variant", userVO.getVariant());
				// }
				query1.setParameter("variant", workProcessVO.getlBRVARIANT());
				// EOC: Range and Variant parameters for query should be equal the one selected in UI - 14.02.2017 - R4867
				query1.setParameter("language", userVO.getLanguage());
				if (vo.getaCTIVITY() != null && !vo.getaCTIVITY().equals("")) {
					query1.setParameter("activity", vo.getaCTIVITY());
				} else {
					query1.setParameter("activity", "%");
				}
				if (vo.getvERSION() != null && !vo.getvERSION().equals("")) {
					query1.setParameter("version", vo.getvERSION());
				} else {
					query1.setParameter("version", "%");
				}
				if (vo.getlOCATION() != null && !vo.getlOCATION().equals("")) {
					query1.setParameter("location", vo.getlOCATION());
				} else {
					query1.setParameter("location", "%");
				}
				if (vo.getiNSTALLCON() != null
						&& !vo.getiNSTALLCON().equals("")) {
					query1.setParameter("installCon", vo.getiNSTALLCON());
				} else {
					query1.setParameter("installCon", "%");
				}
				query1.setParameter("code", code + "%");
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
				populateNotIncludedWPDetailsDataInVO(result, voDetailsList);
				vo.setnOOFNOTINCLUDEDWP(Integer
						.valueOf(voDetailsList.size()));
				if (voDetailsList.size() == 1) {
					if (((WorkProcessVO) voDetailsList.get(0)).getlBRVALUE()
							.equalsIgnoreCase("****")) {
						vo.setnOOFNOTINCLUDEDWP(Integer.valueOf(2));
					}
				}
				vo.setSubWorkProcessVOs(voDetailsList);
				topWPList.add(vo);
				//hMap.put(vo, voDetailsList);
				//topWPList = this.updateWorkProcessCount(hMap);
			}
		} catch (Exception e) {
			errorCode = "e015";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		Long outTime = System.currentTimeMillis();
		LOGGER.info(">>>Total mili seconds<<<" + (outTime - inTime));
		return topWPList;
	}
	/**
	 * 
	 * @param hMap
	 * @return 
	 */
	/*private List updateWorkProcessCount(HashMap hMap) {
		Iterator iterator = hMap.entrySet().iterator();
		List<WorkProcessVO> topWPList = new ArrayList();
		while (iterator.hasNext()) {
			Map.Entry mapEntry = (Map.Entry) iterator.next();
			WorkProcessVO keyWorkProcessVO = (WorkProcessVO) mapEntry.getKey();
			List workProcessVOList = (List) mapEntry.getValue();
			keyWorkProcessVO.setnOOFNOTINCLUDEDWP(Integer
					.valueOf(workProcessVOList.size()));
			if (workProcessVOList.size() == 1) {
				if (((WorkProcessVO) workProcessVOList.get(0)).getlBRVALUE()
						.equalsIgnoreCase("****")) {
					keyWorkProcessVO.setnOOFNOTINCLUDEDWP(Integer.valueOf(2));
				}
			}
			topWPList.add(keyWorkProcessVO);
		}
		Collections.sort(topWPList);
		return topWPList;
	}*/

	// ** Hibernate function 12
	/**
	 * Fetch wp search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchWPSearchList(String searchText, String objectCode,
			UserVO userVO, PaginationVO paginationVO) throws EOIException {
		List result = null;
		Session laborValSession = null;
		LOGGER.info("Received message to fetch work processes at Hibernate Layer");
		
		String changedSearchText = searchText.replace("~", "%");
		String changedObjectCode = objectCode.replace("~", "%");
		try {
			// LOGGER.info("Inside ** Hibernate Function 12 -> fetchWPSearchListHibernate ");
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchWPSearchListCount(changedSearchText, changedObjectCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query1.setParameter("range", "%");
				} else {
					query1.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query1.setParameter("variant", userVO.getVariant());
				}
				query1.setParameter("language", userVO.getLanguage());
				query1.setParameter("searchText", changedSearchText);
				query1.setParameter("objectCode", changedObjectCode);
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());

				qry = formQryToFetchWPSearchList(changedSearchText, changedObjectCode,
						userVO, paginationVO);
				LOGGER.info("query2------query2--------------------------------------"+qry);
				Query query2 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query2.setParameter("range", "%");
				} else {
					query2.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query2.setParameter("variant", userVO.getVariant());
				}
				query2.setParameter("language", userVO.getLanguage());
				query2.setParameter("searchText", changedSearchText);
				query2.setParameter("objectCode", changedObjectCode);
				if (paginationVO.getCurrentPage() != 0) {
					query2.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query2.setParameter("endRowNum",
							paginationVO.getEndRowNum());
				}
				query2.setCacheable(true);
				query2.setCacheRegion("eoicatalog.ehcache");
				result = query2.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
			} else {
				qry = formQryToFetchWPSearchList(changedSearchText, changedObjectCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("searchText", changedSearchText);
				query.setParameter("objectCode", changedObjectCode);
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e016";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return paginationVO;
	}

	// ** Hibernate function 13
	/**
	 * Fetch object search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchObjectSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session laborValSession = null;
		LOGGER.info("Inside ** Hibernate Function 13 -> fetchObjectSearchListHibernate ");
	      String changedSearchText = searchText.replace("~","%");
         String changedObjectCode = objectCode.replace("~", "%");

		try {
			// LOGGER.info("Inside ** Hibernate Function 13 -> fetchObjectSearchListHibernate ");
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchObjSearchListCount(changedSearchText,changedObjectCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query1.setParameter("range", "%");
				} else {
					query1.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query1.setParameter("variant", userVO.getVariant());
				}
				query1.setParameter("language", userVO.getLanguage());
				query1.setParameter("searchText",changedSearchText );
				query1.setParameter("objectCode", changedObjectCode);
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());

				qry = formQryToFetchObjSearchList(changedSearchText,changedObjectCode,
						userVO, paginationVO);
				Query query2 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query2.setParameter("range", "%");
				} else {
					query2.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query2.setParameter("variant", userVO.getVariant());
				}
				query2.setParameter("language", userVO.getLanguage());
				query2.setParameter("searchText",changedSearchText );
				query2.setParameter("objectCode", changedObjectCode);
				if (paginationVO.getCurrentPage() != 0) {
					query2.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query2.setParameter("endRowNum",
							paginationVO.getEndRowNum());
				}
				query2.setCacheable(true);
				query2.setCacheRegion("eoicatalog.ehcache");
				result = query2.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();

			} else {
				qry = formQryToFetchObjSearchList(changedSearchText,changedObjectCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("searchText", changedSearchText);
				query.setParameter("objectCode", changedObjectCode);
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			populateWPDataInVO(result, voList);
		
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e017";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return paginationVO;
	}

	// ** Hibernate function 14
	/**
	 * Fetch activity search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchActivitySearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session laborValSession = null;
		LOGGER.info("Inside ** Hibernate Function 13 -> fetchActivitySearchListHibernate ");
	   String changedSearchText = searchText.replace("~","%");
       String changedActivityCode = activityCode.replace("~", "%");
       searchText=changedSearchText;
       activityCode=changedActivityCode;
       
		try {
			// LOGGER.info("Inside ** Hibernate Function 14 -> fetchActivitySearchListHibernate ");
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchActSearchListCount(searchText,
						activityCode, userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query1.setParameter("range", "%");
				} else {
					query1.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query1.setParameter("variant", userVO.getVariant());
				}
				query1.setParameter("language", userVO.getLanguage());
				if (!searchText.equals("%")) {
					query1.setParameter("searchText", searchText);
				}
				query1.setParameter("activityCode", activityCode);
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());
				if (!searchText.equals("%")) {
					qry = formQryToFetchActSearchList(searchText, activityCode,
							userVO, paginationVO);
					Query query2 = laborValSession.createSQLQuery(qry);
					if (userVO.getModel().equalsIgnoreCase("All")) {
						query2.setParameter("range", "%");
					} else {
						query2.setParameter("range", userVO.getModel());
					}
					if (!userVO.getVariant().equalsIgnoreCase("All")) {
						query2.setParameter("variant", userVO.getVariant());
					}
					query2.setParameter("language", userVO.getLanguage());
					query2.setParameter("searchText", searchText);
					query2.setParameter("activityCode", activityCode);
					if (paginationVO.getCurrentPage() != 0) {
						query2.setParameter("startRowNum",
								paginationVO.getStartRowNum());
						query2.setParameter("endRowNum",
								paginationVO.getEndRowNum());
					}
					query2.setCacheable(true);
					query2.setCacheRegion("eoicatalog.ehcache");
					result = query2.setResultTransformer(
							Transformers.aliasToBean(WSGLBRVAL.class)).list();
				}
			} else {
				qry = formQryToFetchActSearchList(searchText, activityCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("searchText", searchText);
				query.setParameter("activityCode", activityCode);
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			if (!searchText.equals("%")) {
				voList = new ArrayList<WorkProcessVO>();
				populateWPDataInVO(result, voList);
			}
			paginationVO.setRows(voList);
		} catch (Exception e) {
			errorCode = "e018";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return paginationVO;
	}

	// ** Hibernate function 15
	/**
	 * Fetch version search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchVersionSearchList(String searchText,
			String versionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session laborValSession = null;
		LOGGER.info("Inside ** Hibernate Function 13 -> fetchVersionSearchListHibernate ");
		   String changedSearchText = searchText.replace("~","%");
	       String changedVersionCode = versionCode.replace("~", "%");
	       searchText=changedSearchText;
	       versionCode=changedVersionCode;
		try {
			// LOGGER.info("Inside ** Hibernate Function 15 -> fetchVersionSearchListHibernate ");
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchVerSearchListCount(searchText, versionCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query1.setParameter("range", "%");
				} else {
					query1.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query1.setParameter("variant", userVO.getVariant());
				}
				query1.setParameter("language", userVO.getLanguage());
				if (!searchText.equals("%")) {
					query1.setParameter("searchText", searchText);
				}
				query1.setParameter("versionCode", versionCode);
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());
				if (!searchText.equals("%")) {
					qry = formQryToFetchVerSearchList(searchText, versionCode,
							userVO, paginationVO);
					Query query2 = laborValSession.createSQLQuery(qry);
					if (userVO.getModel().equalsIgnoreCase("All")) {
						query2.setParameter("range", "%");
					} else {
						query2.setParameter("range", userVO.getModel());
					}
					if (!userVO.getVariant().equalsIgnoreCase("All")) {
						query2.setParameter("variant", userVO.getVariant());
					}
					query2.setParameter("language", userVO.getLanguage());
					query2.setParameter("searchText", searchText);
					query2.setParameter("versionCode", versionCode);
					if (paginationVO.getCurrentPage() != 0) {
						query2.setParameter("startRowNum",
								paginationVO.getStartRowNum());
						query2.setParameter("endRowNum",
								paginationVO.getEndRowNum());
					}
					query2.setCacheable(true);
					query2.setCacheRegion("eoicatalog.ehcache");
					result = query2.setResultTransformer(
							Transformers.aliasToBean(WSGLBRVAL.class)).list();
				}
			} else {
				qry = formQryToFetchVerSearchList(searchText, versionCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("searchText", searchText);
				query.setParameter("versionCode", versionCode);
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			if (!searchText.equals("%")) {
				voList = new ArrayList<WorkProcessVO>();
				populateWPDataInVO(result, voList);
			}
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e019";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return paginationVO;
	}

	// ** Hibernate function 16
	/**
	 * Fetch location search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchLocationSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session laborValSession = null;
		LOGGER.info("Inside ** Hibernate Function 13 -> fetchLocationSearchListHibernate ");
		   String changedSearchText = searchText.replace("~","%");
	       String changedLocationCode = locationCode.replace("~", "%");
	       searchText=changedSearchText;
	       locationCode=changedLocationCode;
		try {
			// LOGGER.info("Inside ** Hibernate Function 16 -> fetchLocationSearchListHibernate ");
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchLocSearchListCount(searchText,
						locationCode, userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query1.setParameter("range", "%");
				} else {
					query1.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query1.setParameter("variant", userVO.getVariant());
				}
				query1.setParameter("language", userVO.getLanguage());
				if (!searchText.equals("%")) {
					query1.setParameter("searchText", searchText);
				}
				query1.setParameter("locationCode", locationCode);
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());
				if (!searchText.equals("%")) {
					qry = formQryToFetchLocSearchList(searchText, locationCode,
							userVO, paginationVO);
					Query query2 = laborValSession.createSQLQuery(qry);
					if (userVO.getModel().equalsIgnoreCase("All")) {
						query2.setParameter("range", "%");
					} else {
						query2.setParameter("range", userVO.getModel());
					}
					if (!userVO.getVariant().equalsIgnoreCase("All")) {
						query2.setParameter("variant", userVO.getVariant());
					}
					query2.setParameter("language", userVO.getLanguage());
					query2.setParameter("searchText", searchText);
					query2.setParameter("locationCode", locationCode);
					if (paginationVO.getCurrentPage() != 0) {
						query2.setParameter("startRowNum",
								paginationVO.getStartRowNum());
						query2.setParameter("endRowNum",
								paginationVO.getEndRowNum());
					}
					query2.setCacheable(true);
					query2.setCacheRegion("eoicatalog.ehcache");
					result = query2.setResultTransformer(
							Transformers.aliasToBean(WSGLBRVAL.class)).list();
				}
			} else {
				qry = formQryToFetchLocSearchList(searchText, locationCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("searchText", searchText);
				query.setParameter("locationCode", locationCode);
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			if (!searchText.equals("%")) {
				voList = new ArrayList<WorkProcessVO>();
				populateWPDataInVO(result, voList);
			}
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e020";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return paginationVO;
	}

	// ** Hibernate function 17
	/**
	 * Fetch condition search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the pagination vo
	 * @throws EOIException
	 *             the eOI exception
	 */
	public PaginationVO fetchConditionSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO)
			throws EOIException {
		List result = null;
		Session laborValSession = null;
		LOGGER.info("Inside ** Hibernate Function 13 -> fetchConditionSearchListHibernate ");
		   String changedSearchText = searchText.replace("~","%");
	       String changedConditionCode = conditionCode.replace("~", "%");
	       searchText=changedSearchText;
	       conditionCode=changedConditionCode;
		try {
			// LOGGER.info("Inside ** Hibernate Function 17 -> fetchConditionSearchListHibernate ");
			String qry = "";
			if (paginationVO.getCurrentPage() == 0) {
				qry = formQryToFetchConSearchListCount(searchText,
						conditionCode, userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query1 = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query1.setParameter("range", "%");
				} else {
					query1.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query1.setParameter("variant", userVO.getVariant());
				}
				query1.setParameter("language", userVO.getLanguage());
				if (!searchText.equals("%")) {
					query1.setParameter("searchText", searchText);
				}
				query1.setParameter("conditionCode", conditionCode);
				query1.setCacheable(true);
				query1.setCacheRegion("eoicatalog.ehcache");
				result = query1.list();

				paginationVO.setTotalRecords(Integer.valueOf(
						result.get(0).toString()).intValue());
				if (!searchText.equals("%")) {
					qry = formQryToFetchConSearchList(searchText,
							conditionCode, userVO, paginationVO);
					Query query2 = laborValSession.createSQLQuery(qry);
					if (userVO.getModel().equalsIgnoreCase("All")) {
						query2.setParameter("range", "%");
					} else {
						query2.setParameter("range", userVO.getModel());
					}
					if (!userVO.getVariant().equalsIgnoreCase("All")) {
						query2.setParameter("variant", userVO.getVariant());
					}
					query2.setParameter("language", userVO.getLanguage());
					query2.setParameter("searchText", searchText);
					query2.setParameter("conditionCode", conditionCode);
					if (paginationVO.getCurrentPage() != 0) {
						query2.setParameter("startRowNum",
								paginationVO.getStartRowNum());
						query2.setParameter("endRowNum",
								paginationVO.getEndRowNum());
					}
					query2.setCacheable(true);
					query2.setCacheRegion("eoicatalog.ehcache");
					result = query2.setResultTransformer(
							Transformers.aliasToBean(WSGLBRVAL.class)).list();
				}
			} else {
				qry = formQryToFetchConSearchList(searchText, conditionCode,
						userVO, paginationVO);
				laborValSession = this.hibernateTemplate.getSessionFactory()
						.openSession();
				Query query = laborValSession.createSQLQuery(qry);
				if (userVO.getModel().equalsIgnoreCase("All")) {
					query.setParameter("range", "%");
				} else {
					query.setParameter("range", userVO.getModel());
				}
				if (!userVO.getVariant().equalsIgnoreCase("All")) {
					query.setParameter("variant", userVO.getVariant());
				}
				query.setParameter("language", userVO.getLanguage());
				query.setParameter("searchText", searchText);
				query.setParameter("conditionCode", conditionCode);
				if (paginationVO.getCurrentPage() != 0) {
					query.setParameter("startRowNum",
							paginationVO.getStartRowNum());
					query.setParameter("endRowNum", paginationVO.getEndRowNum());
				}
				query.setCacheable(true);
				query.setCacheRegion("eoicatalog.ehcache");
				result = query.setResultTransformer(
						Transformers.aliasToBean(WSGLBRVAL.class)).list();
			}
			List<WorkProcessVO> voList = new ArrayList<WorkProcessVO>();
			if (!searchText.equals("%")) {
				voList = new ArrayList<WorkProcessVO>();
				populateWPDataInVO(result, voList);
			}
			paginationVO.setRows(voList);

		} catch (Exception e) {
			errorCode = "e021";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return paginationVO;
	}

	/**
	 * Populate wp data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateWPDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			WorkProcessVO vo = new WorkProcessVO();
			vo.setrANGE(((WSGLBRVAL) result.get(i)).getRANGE());
			vo.setlBRVARIANT(((WSGLBRVAL) result.get(i)).getLBR_VARIANT());
			vo.setoBJCD1(((WSGLBRVAL) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRVAL) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRVAL) result.get(i)).getOBJCD3());
			vo.setaCTIVITY(((WSGLBRVAL) result.get(i)).getACTIVITY());
			vo.setvERSION(((WSGLBRVAL) result.get(i)).getVERSION());
			vo.setlOCATION(((WSGLBRVAL) result.get(i)).getLOCATION());
			vo.setiNSTALLCON(((WSGLBRVAL) result.get(i)).getINSTALL_CON());
			vo.setjOBTYPE(((WSGLBRVAL) result.get(i)).getJOBTYPE());
			vo.setlBRVALUE(((WSGLBRVAL) result.get(i)).getLBR_VALUE());
			vo.setlABVAL(((WSGLBRVAL) result.get(i)).getLABVAL());
			vo.settEXT(((WSGLBRVAL) result.get(i)).getTEXT());
			if (((WSGLBRVAL) result.get(i)).getNO_OF_INCLUDEDWP() != null) {
				vo.setnOOFINCLUDEDWP(Integer.valueOf((((WSGLBRVAL) result
						.get(i)).getNO_OF_INCLUDEDWP().intValue())));
			}
			if (((WSGLBRVAL) result.get(i)).getNO_OF_NOTINCLUDEDWP() != null) {
				vo.setnOOFNOTINCLUDEDWP(Integer.valueOf((((WSGLBRVAL) result
						.get(i)).getNO_OF_NOTINCLUDEDWP().intValue())));
			}

			voList.add(vo);
		}
	}

	/**
	 * Populate included wp data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateIncludedWPDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			WorkProcessVO vo = new WorkProcessVO();
			vo.setrANGE(((WSGLBRVAL) result.get(i)).getRANGE());
			vo.setlBRVARIANT(((WSGLBRVAL) result.get(i)).getLBR_VARIANT());
			vo.setlABVAL(((WSGLBRVAL) result.get(i)).getLABVAL());
			vo.setoBJCD1(((WSGLBRVAL) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRVAL) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRVAL) result.get(i)).getOBJCD3());
			vo.setaCTIVITY(((WSGLBRVAL) result.get(i)).getACTIVITY());
			vo.setvERSION(((WSGLBRVAL) result.get(i)).getVERSION());
			vo.setlOCATION(((WSGLBRVAL) result.get(i)).getLOCATION());
			vo.setiNSTALLCON(((WSGLBRVAL) result.get(i)).getINSTALL_CON());
			vo.settEXT(((WSGLBRVAL) result.get(i)).getTEXT());
			voList.add(vo);
		}
	}

	/**
	 * Populate not included wp details data in vo.
	 * 
	 * @param result
	 *            the result
	 * @param voList
	 *            the vo list
	 */
	private void populateNotIncludedWPDetailsDataInVO(List result, List voList) {
		for (int i = 0; i < result.size(); i++) {
			WorkProcessVO vo = new WorkProcessVO();
			vo.setlABVAL(((WSGLBRVAL) result.get(i)).getLABVAL());
			vo.setoBJCD1(((WSGLBRVAL) result.get(i)).getOBJCD1());
			vo.setoBJCD2(((WSGLBRVAL) result.get(i)).getOBJCD2());
			vo.setoBJCD3(((WSGLBRVAL) result.get(i)).getOBJCD3());
			vo.setaCTIVITY(((WSGLBRVAL) result.get(i)).getACTIVITY());
			vo.setvERSION(((WSGLBRVAL) result.get(i)).getVERSION());
			vo.setlOCATION(((WSGLBRVAL) result.get(i)).getLOCATION());
			vo.setiNSTALLCON(((WSGLBRVAL) result.get(i)).getINSTALL_CON());
			vo.settEXT(((WSGLBRVAL) result.get(i)).getTEXT());
			vo.setlBRVALUE(((WSGLBRVAL) result.get(i)).getLBR_VALUE());
			voList.add(vo);
		}
	}

	/**
	 * Form qry of range.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfRange(RangeVO rangeVO, UserVO userVO) {
		String qry = "";
		qry = "SELECT DISTINCT RANGE FROM {h-schema}WSGLBRRAN WHERE PRCSTAT = 'A' ORDER BY RANGE";
		return qry;
	}

	/**
	 * Form qry of unit.
	 * 
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfUnit(UserVO userVO) {
		String qry = "";
		qry = "SELECT MSEH3 FROM {h-schema}UOMT WHERE SPRAS = :language AND MSEHI = 'AW'";
		return qry;
	}

	/**
	 * Form qry for lang.
	 * 
	 * @param spras
	 *            the spras
	 * @return the string
	 */
	private String formQryForLang(String spras) {
		String qry = "";
		qry = "SELECT LAISO FROM {h-schema}LANG WHERE SPRAS = :lang";
		return qry;
	}

	// ** Hibernate function 5_a
	/**
	 * Form qry of variant.
	 * 
	 * @param rangeVO
	 *            the range vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfVariant(RangeVO rangeVO, UserVO userVO) {
		// LOGGER.info("Inside ** Hibernate Function 5_a -> formQryOfVariantHibernate ");
		String qry = "";
		qry = "SELECT DISTINCT(VARIANTE) FROM {h-schema}WSGLBRRAN WHERE PRCSTAT = 'A' AND RANGE LIKE :range ORDER BY VARIANTE";
		return qry;
	}

	// ** Hibernate function 12_a
	/**
	 * Form qry to fetch wp search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchWPSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 12_a -> formQryToFetchWPSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || L.TEXT || A.TEXT || V.TEXT || C.TEXT)  like UPPER(:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.LABVAL) DATA ";
		} else {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || L.TEXT || A.TEXT || V.TEXT || C.TEXT)  like UPPER(:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.LABVAL) DATA ";
		}
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	/**
	 * Form qry to fetch wp search List count.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchWPSearchListCount(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 12_a -> formQryToFetchWPSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || L.TEXT || A.TEXT || V.TEXT || C.TEXT)  like UPPER(:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.LABVAL) DATA ";
		} else {
			qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || L.TEXT || A.TEXT || V.TEXT || C.TEXT)  like UPPER(:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.LABVAL) DATA ";
		}

		return qry;
	}

	// ** Hibernate function 13_a
	/**
	 * Form qry to fetch obj search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchObjSearchList(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 13_a -> formQryToFetchObjSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) AS LABVAL, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, "
					+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3 "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END ) " 
					/*Edited BY Prabhat Choudharz on 19 Jan 2015*/
					//+" like UPPER(:searchText) "
					+" like (:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) DATA ";
		} else {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) AS LABVAL, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, "
					+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3 "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END )"
					/*Edited BY Prabhat Choudharz on 19 Jan 2015*/
					//+" like UPPER(:searchText) "
					+" like (:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) DATA ";
		}
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	// ** Hibernate function 13_a
	/**
	 * Form qry to fetch obj search list count.
	 * 
	 * @param searchText
	 *            the search text
	 * @param objectCode
	 *            the object code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchObjSearchListCount(String searchText,
			String objectCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 13_a -> formQryToFetchObjSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) AS LABVAL, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, "
					+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END  AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3 "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END ) "
					/*Edited BY Prabhat Choudharz on 19 Jan 2015*/
					//+" like UPPER(:searchText) "
					+" like (:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) DATA ";
		} else {
			qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) AS LABVAL, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, "
					+ "CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END  AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3 "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND UPPER(CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END  || CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END ) "
					/*Edited BY Prabhat Choudharz on 19 Jan 2015*/
					//+" like UPPER(:searchText) "
					+" like (:searchText) "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 LIKE :objectCode ORDER BY LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3) DATA ";
		}
	  
		return qry;
	}

	// ** Hibernate function 14_a
	/**
	 * Form qry to fetch act search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchActSearchList(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 14_a -> formQryToFetchActSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.ACTIVITY), "
					+ "A.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRACTT A "
					+ "WHERE LV.ACTIVITY = A.ACTIVITY "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND A.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND A.SPRAS = :language "
					+ "AND UPPER(A.TEXT)  like UPPER(:searchText) "
					+ "AND LV.ACTIVITY LIKE :activityCode ORDER BY LV.ACTIVITY) DATA ";
		} else {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.ACTIVITY), "
					+ "A.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRACTT A "
					+ "WHERE LV.ACTIVITY = A.ACTIVITY "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND A.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND A.SPRAS = :language "
					+ "AND UPPER(A.TEXT)  like UPPER(:searchText) "
					+ "AND LV.ACTIVITY LIKE :activityCode ORDER BY LV.ACTIVITY) DATA ";
		}
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	// ** Hibernate function 14_a
	/**
	 * Form qry to fetch act search list count.
	 * 
	 * @param searchText
	 *            the search text
	 * @param activityCode
	 *            the activity code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchActSearchListCount(String searchText,
			String activityCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 14_a -> formQryToFetchActSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.ACTIVITY), "
						+ "A.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRACTT A "
						+ "WHERE LV.ACTIVITY = A.ACTIVITY "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND A.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND A.SPRAS = :language "
						+ "AND UPPER(A.TEXT)  like UPPER(:searchText) "
						+ "AND LV.ACTIVITY LIKE :activityCode ORDER BY LV.ACTIVITY) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.ACTIVITY), "
						+ "A.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRACTT A "
						+ "WHERE LV.ACTIVITY = A.ACTIVITY "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND A.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND A.SPRAS = :language "
						+ "AND LV.ACTIVITY LIKE :activityCode ORDER BY LV.ACTIVITY) DATA ";
			}
		} else {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.ACTIVITY), "
						+ "A.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRACTT A "
						+ "WHERE LV.ACTIVITY = A.ACTIVITY "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND A.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND A.SPRAS = :language "
						+ "AND UPPER(A.TEXT)  like UPPER(:searchText) "
						+ "AND LV.ACTIVITY LIKE :activityCode ORDER BY LV.ACTIVITY) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.ACTIVITY), "
						+ "A.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRACTT A "
						+ "WHERE LV.ACTIVITY = A.ACTIVITY "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND A.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND A.SPRAS = :language "
						+ "AND LV.ACTIVITY LIKE :activityCode ORDER BY LV.ACTIVITY) DATA ";
			}
		}
		return qry;
	}

	// ** Hibernate function 15_a
	/**
	 * Form qry to fetch ver search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchVerSearchList(String searchText,
			String versionCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 15_a -> formQryToFetchVerSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.VERSION), "
					+ "V.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRVRST V  "
					+ "WHERE LV.VERSION = V.VERSION "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND V.SPRAS = :language "
					+ "AND UPPER(V.TEXT)  like UPPER(:searchText) "
					+ "AND LV.VERSION LIKE :versionCode ORDER BY LV.VERSION) DATA ";
		} else {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.VERSION), "
					+ "V.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRVRST V  "
					+ "WHERE LV.VERSION = V.VERSION "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND V.SPRAS = :language "
					+ "AND UPPER(V.TEXT)  like UPPER(:searchText) "
					+ "AND LV.VERSION LIKE :versionCode ORDER BY LV.VERSION) DATA ";
		}
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	// ** Hibernate function 15_a
	/**
	 * Form qry to fetch ver search list count.
	 * 
	 * @param searchText
	 *            the search text
	 * @param versionCode
	 *            the version code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchVerSearchListCount(String searchText,
			String versionCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 15_a -> formQryToFetchVerSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.VERSION), "
						+ "V.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRVRST V  "
						+ "WHERE LV.VERSION = V.VERSION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND V.SPRAS = :language "
						+ "AND UPPER(V.TEXT)  like UPPER(:searchText) "
						+ "AND LV.VERSION LIKE :versionCode ORDER BY LV.VERSION) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.VERSION), "
						+ "V.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRVRST V  "
						+ "WHERE LV.VERSION = V.VERSION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND V.SPRAS = :language "
						+ "AND LV.VERSION LIKE :versionCode ORDER BY LV.VERSION) DATA ";
			}
		} else {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.VERSION), "
						+ "V.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRVRST V  "
						+ "WHERE LV.VERSION = V.VERSION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND V.SPRAS = :language "
						+ "AND UPPER(V.TEXT)  like UPPER(:searchText) "
						+ "AND LV.VERSION LIKE :versionCode ORDER BY LV.VERSION) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.VERSION), "
						+ "V.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRVRST V  "
						+ "WHERE LV.VERSION = V.VERSION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND V.SPRAS = :language "
						+ "AND LV.VERSION LIKE :versionCode ORDER BY LV.VERSION) DATA ";
			}
		}
		return qry;
	}

	// ** Hibernate function 16_a
	/**
	 * Form qry to fetch loc search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchLocSearchList(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 16_a -> formQryToFetchLocSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.LOCATION), "
					+ "L.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRLOCT L  "
					+ "WHERE LV.LOCATION = L.LOCATION "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND L.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND L.SPRAS = :language "
					+ "AND UPPER(L.TEXT)  like UPPER(:searchText) "
					+ "AND LV.LOCATION LIKE :locationCode ORDER BY LV.LOCATION) DATA ";
		} else {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.LOCATION), "
					+ "L.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRLOCT L  "
					+ "WHERE LV.LOCATION = L.LOCATION "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND L.PRCSTAT = 'A' "
					+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND L.SPRAS = :language "
					+ "AND UPPER(L.TEXT)  like UPPER(:searchText) "
					+ "AND LV.LOCATION LIKE :locationCode ORDER BY LV.LOCATION) DATA ";
		}
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	// ** Hibernate function 16_a
	/**
	 * Form qry to fetch loc search list count.
	 * 
	 * @param searchText
	 *            the search text
	 * @param locationCode
	 *            the location code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchLocSearchListCount(String searchText,
			String locationCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 16_a -> formQryToFetchLocSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.LOCATION), "
						+ "L.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRLOCT L  "
						+ "WHERE LV.LOCATION = L.LOCATION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND L.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND L.SPRAS = :language "
						+ "AND UPPER(L.TEXT)  like UPPER(:searchText) "
						+ "AND LV.LOCATION LIKE :locationCode ORDER BY LV.LOCATION) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.LOCATION), "
						+ "L.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRLOCT L  "
						+ "WHERE LV.LOCATION = L.LOCATION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND L.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND L.SPRAS = :language "
						+ "AND LV.LOCATION LIKE :locationCode ORDER BY LV.LOCATION) DATA ";
			}
		} else {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.LOCATION), "
						+ "L.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRLOCT L  "
						+ "WHERE LV.LOCATION = L.LOCATION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND L.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND L.SPRAS = :language "
						+ "AND UPPER(L.TEXT)  like UPPER(:searchText) "
						+ "AND LV.LOCATION LIKE :locationCode ORDER BY LV.LOCATION) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.LOCATION), "
						+ "L.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRLOCT L  "
						+ "WHERE LV.LOCATION = L.LOCATION "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND L.PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND L.SPRAS = :language "
						+ "AND LV.LOCATION LIKE :locationCode ORDER BY LV.LOCATION) DATA ";
			}

		}
		return qry;
	}

	// ** Hibernate function 17_a
	/**
	 * Form qry to fetch con search list.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchConSearchList(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 17_a -> formQryToFetchConSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.INSTALL_CON), "
					+ "C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.INSTALL_CON = C.INSTALL_CON "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND C.PRCSTAT = 'A'  "
					+ "AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND C.SPRAS = :language "
					+ "AND UPPER(C.TEXT)  like UPPER(:searchText) "
					+ "AND LV.INSTALL_CON LIKE :conditionCode ORDER BY LV.INSTALL_CON) DATA ";
		} else {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT(LV.INSTALL_CON), "
					+ "C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.INSTALL_CON = C.INSTALL_CON "
					+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND C.PRCSTAT = 'A'  "
					+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND C.SPRAS = :language "
					+ "AND UPPER(C.TEXT)  like UPPER(:searchText) "
					+ "AND LV.INSTALL_CON LIKE :conditionCode ORDER BY LV.INSTALL_CON) DATA ";
		}
		if (paginationVO.getCurrentPage() != 0) {
			qry = "SELECT * FROM ( " + qry
					+ ") WHERE R_NUM > :startRowNum AND R_NUM <= :endRowNum";
		}
		return qry;
	}

	// ** Hibernate function 17_a
	/**
	 * Form qry to fetch con search list count.
	 * 
	 * @param searchText
	 *            the search text
	 * @param conditionCode
	 *            the condition code
	 * @param userVO
	 *            the user vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formQryToFetchConSearchListCount(String searchText,
			String conditionCode, UserVO userVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 17_a -> formQryToFetchConSearchListHibernate ");
		String qry = "";
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.INSTALL_CON), "
						+ "C.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRCONT C  "
						+ "WHERE LV.INSTALL_CON = C.INSTALL_CON "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND C.PRCSTAT = 'A'  "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND C.SPRAS = :language "
						+ "AND UPPER(C.TEXT)  like UPPER(:searchText) "
						+ "AND LV.INSTALL_CON LIKE :conditionCode ORDER BY LV.INSTALL_CON) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.INSTALL_CON), "
						+ "C.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRCONT C  "
						+ "WHERE LV.INSTALL_CON = C.INSTALL_CON "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND C.PRCSTAT = 'A'  "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND C.SPRAS = :language "
						+ "AND LV.INSTALL_CON LIKE :conditionCode ORDER BY LV.INSTALL_CON) DATA ";

			}
		} else {
			if (!searchText.equals("%")) {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.INSTALL_CON), "
						+ "C.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRCONT C  "
						+ "WHERE LV.INSTALL_CON = C.INSTALL_CON "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND C.PRCSTAT = 'A'  "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND C.SPRAS = :language "
						+ "AND UPPER(C.TEXT)  like UPPER(:searchText) "
						+ "AND LV.INSTALL_CON LIKE :conditionCode ORDER BY LV.INSTALL_CON) DATA ";
			} else {
				qry = "SELECT COUNT(*) AS TOTALCOUNT FROM (SELECT DISTINCT(LV.INSTALL_CON), "
						+ "C.TEXT AS TEXT "
						+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBRCONT C  "
						+ "WHERE LV.INSTALL_CON = C.INSTALL_CON "
						+ "AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
						+ "AND LV.PRCSTAT = 'A' AND C.PRCSTAT = 'A'  "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND C.SPRAS = :language "
						+ "AND LV.INSTALL_CON LIKE :conditionCode ORDER BY LV.INSTALL_CON) DATA ";
			}
		}
		return qry;
	}

	// ** Hibernate function 6_a
	/**
	 * Form qry of child objects.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildObjects(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) {
		// LOGGER.info("Inside ** Hibernate Function 6_a -> formQryOfChildObjectsHibernate ");
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 IN (SELECT DISTINCT(SUBSTR(LABVAL,1,2)) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 like :code "
						+ "AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			} else {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 IN (SELECT DISTINCT(SUBSTR(LABVAL,1,2)) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 like :code "
						+ "AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			}
		} else if (nodeVO.getLevel() == 2) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 IN (SELECT DISTINCT(SUBSTR(LABVAL,1,3)) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 like :code "
						+ "AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			} else {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD2 IS NULL AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 IN (SELECT DISTINCT(SUBSTR(LABVAL,1,3)) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 like :code "
						+ "AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			}
		} else if (nodeVO.getLevel() == 3) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 = :code AND OBJCD2 IN (SELECT DISTINCT(SUBSTR(LABVAL,4,1)) FROM {h-schema}WSGLBRVAL "
						+ "WHERE OBJCD1 = :code AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			} else {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND OBJCD3 IS NULL AND SPRAS = :language "
						+ "AND OBJCD1 = :code AND OBJCD2 IN (SELECT DISTINCT(SUBSTR(LABVAL,4,1)) FROM {h-schema}WSGLBRVAL "
						+ "WHERE OBJCD1 = :code AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			}
		} else if (nodeVO.getLevel() == 4) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND OBJCD1 = :code1 AND OBJCD2 = :code2  AND OBJCD3 IN "
						+ "(SELECT DISTINCT(SUBSTR(LABVAL,5,3)) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			} else {
				qry = "SELECT DISTINCT OBJCD1, OBJCD2, OBJCD3, TEXT FROM {h-schema}WSGLBROBJT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND OBJCD1 = :code1 AND OBJCD2 = :code2  AND OBJCD3 IN "
						+ "(SELECT DISTINCT(SUBSTR(LABVAL,5,3)) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND ACTIVITY IS NOT NULL AND JOBTYPE <> 'H') ORDER BY OBJCD1, OBJCD2, OBJCD3";
			}
		}
		return qry;
	}

	// ** Hibernate function 7_a
	/**
	 * Form qry of child activities.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildActivities(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) {
		// LOGGER.info("Inside ** Hibernate Function 7_a -> formQryOfChildActivitiesHibernate ");
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY IN (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			} else {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY IN (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			}
		} else if (nodeVO.getLevel() == 2) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			} else {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			}
		} else if (nodeVO.getLevel() == 3) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			} else {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			}
		} else if (nodeVO.getLevel() == 4) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			} else {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 is null AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			}
		} else if (nodeVO.getLevel() == 5) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 = :code3 AND PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			} else {
				qry = "SELECT DISTINCT ACTIVITY, TEXT FROM {h-schema}WSGLBRACTT WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND ACTIVITY in (SELECT DISTINCT(ACTIVITY) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 = :code3 AND PRCSTAT = 'A' "
						+ "AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY ACTIVITY";
			}
		}
		return qry;
	}

	// ** Hibernate function 8_a
	/**
	 * Form qry of child versions.
	 * 
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param userVO
	 *            the user vo
	 * @return the string
	 */
	private String formQryOfChildVersions(WorkProcessVO workProcessVO,
			NodeVO nodeVO, UserVO userVO) {
		// LOGGER.info("Inside ** Hibernate Function 8_a -> formQryOfChildVersionsHibernate ");
		String qry = "";
		if (nodeVO.getLevel() == 1) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION IN (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND ACTIVITY = :activity AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			} else {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION IN (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND ACTIVITY = :activity AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			}
		} else if (nodeVO.getLevel() == 2) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND ACTIVITY = :activity AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			} else {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null AND ACTIVITY = :activity AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			}
		} else if (nodeVO.getLevel() == 3) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null  AND ACTIVITY = :activity AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			} else {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 is null AND OBJCD3 is null  AND ACTIVITY = :activity AND PRCSTAT = 'A' AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			}
		} else if (nodeVO.getLevel() == 4) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 is null  AND ACTIVITY = :activity AND PRCSTAT = 'A' "
						+ "AND RANGE like :range "
						+ "AND LBR_VARIANT like '%' AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			} else {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 is null  AND ACTIVITY = :activity AND PRCSTAT = 'A' "
						+ "AND RANGE like :range "
						+ "AND LBR_VARIANT in (:variant,'*') AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			}
		} else if (nodeVO.getLevel() == 5) {
			if (userVO.getVariant().equalsIgnoreCase("All")) {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 = :code3 AND ACTIVITY = :activity "
						+ "AND PRCSTAT = 'A' AND RANGE like :range AND LBR_VARIANT like '%' "
						+ "AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			} else {
				qry = "SELECT DISTINCT VERSION, TEXT FROM {h-schema}WSGLBRVRST WHERE PRCSTAT = 'A' AND SPRAS = :language "
						+ "AND VERSION in (SELECT DISTINCT(VERSION) FROM {h-schema}WSGLBRVAL WHERE OBJCD1 = :code1 "
						+ "AND OBJCD2 = :code2 AND OBJCD3 = :code3 AND ACTIVITY = :activity "
						+ "AND PRCSTAT = 'A' AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
						+ "AND ACTIVITY NOT IN ('0','00','000') AND JOBTYPE <> 'H') ORDER BY VERSION";
			}
		}
		return qry;
	}

	// ** Hibernate function 9_a
	/**
	 * Form wp list qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formWPListQry(UserVO userVO, WorkProcessVO workProcessVO,
			NodeVO nodeVO, PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 9_a -> formWPListQryHibernate ");
		String qry = "";
		workProcessVO.setoBJCD1("");
		workProcessVO.setoBJCD2("");
		workProcessVO.setoBJCD3("");

		if (null != workProcessVO.getlABVAL()) {
			if (workProcessVO.getlABVAL().length() >= 3) {
				workProcessVO.setoBJCD1(workProcessVO.getlABVAL().substring(0,
						3));
			} else {
				workProcessVO.setoBJCD1(workProcessVO.getlABVAL().substring(0,
						workProcessVO.getlABVAL().length()));
			}

			if (workProcessVO.getlABVAL().length() >= 4) {
				workProcessVO.setoBJCD2(workProcessVO.getlABVAL().substring(3,
						4));
			}

			if (workProcessVO.getlABVAL().length() >= 5) {
				if (workProcessVO.getlABVAL().length() >= 7) {
					workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
							.substring(4, 7));
				} else {
					workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
							.substring(4, workProcessVO.getlABVAL().length()));
				}
			}
		} else {
			if (nodeVO.getCode().length() >= 3) {
				workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3));
			} else {
				workProcessVO.setoBJCD1(nodeVO.getCode().substring(0,
						nodeVO.getCode().length()));
			}

			if (nodeVO.getCode().length() >= 4) {
				workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4));
			}

			if (nodeVO.getCode().length() >= 5) {
				if (nodeVO.getCode().length() >= 7) {
					workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7));
				} else {
					workProcessVO.setoBJCD3(nodeVO.getCode().substring(4,
							nodeVO.getCode().length()));
				}
			}
		}
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND LABVAL LIKE :code "
					+ "AND "
					+ (workProcessVO.getoBJCD1().trim().equals("") ? "LV.OBJCD1 IS NULL "
							: "LV.OBJCD1 = :objcd1 ")
					+ "AND "
					+ (workProcessVO.getoBJCD2().trim().equals("") ? "LV.OBJCD2 IS NULL "
							: "LV.OBJCD2 = :objcd2 ")
					+ "AND "
					+ (workProcessVO.getoBJCD3().trim().equals("") ? "LV.OBJCD3 IS NULL "
							: "LV.OBJCD3 = :objcd3 ")
					+ "ORDER BY LABVAL) DATA ";
		} else {
			qry = "SELECT ROWNUM R_NUM, DATA.* FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND LABVAL LIKE :code "
					+ "AND "
					+ (workProcessVO.getoBJCD1().trim().equals("") ? "LV.OBJCD1 IS NULL "
							: "LV.OBJCD1 = :objcd1 ")
					+ "AND "
					+ (workProcessVO.getoBJCD2().trim().equals("") ? "LV.OBJCD2 IS NULL "
							: "LV.OBJCD2 = :objcd2 ")
					+ "AND "
					+ (workProcessVO.getoBJCD3().trim().equals("") ? "LV.OBJCD3 IS NULL "
							: "LV.OBJCD3 = :objcd3 ")
					+ "ORDER BY LABVAL) DATA ";
		}
		if (paginationVO.getCurrentPage() != 0) {
			// qry = "SELECT * FROM ( " + qry + ") WHERE R_NUM > " +
			// paginationVO.getStartRowNum() + " AND R_NUM <= " +
			// paginationVO.getEndRowNum() + "";
			qry = "SELECT DISTINCT FETCHEDWPDATA.R_NUM, FETCHEDWPDATA.RANGE, FETCHEDWPDATA.LBR_VARIANT, FETCHEDWPDATA.OBJCD1, FETCHEDWPDATA.OBJCD2, "
					+ "FETCHEDWPDATA.OBJCD3, FETCHEDWPDATA.ACTIVITY, FETCHEDWPDATA.VERSION, FETCHEDWPDATA.LOCATION, FETCHEDWPDATA.INSTALL_CON, FETCHEDWPDATA.JOBTYPE, "
					+ "FETCHEDWPDATA.LBR_VALUE, FETCHEDWPDATA.LABVAL, FETCHEDWPDATA.TEXT, SUM(CASE WHEN TEXT.TXT_TYPE = 1 THEN 1 ELSE 0 END) NO_OF_INCLUDEDWP, "
					+ "SUM(CASE WHEN TEXT.TXT_TYPE = 2 "
					//:: Start Change Req 17-02-2014::Prabhat Choudhary

				//	+"AND TEXT.LBR_VARIANT = FETCHEDWPDATA.LBR_VARIANT " +
					//:: End Change Req 17-02-2014 ::Prabhat Choudhary

					
		             + "THEN 1 ELSE 0 END) NO_OF_NOTINCLUDEDWP FROM (SELECT * FROM ( "
					+ qry
					+ ") WHERE R_NUM > :startRowNum "
					+ "AND R_NUM <= :endRowNum ) FETCHEDWPDATA LEFT JOIN {h-schema}WSGLBRTEXT TEXT ON FETCHEDWPDATA.RANGE = TEXT.RANGE AND "
					+ "(TEXT.LBR_VARIANT = FETCHEDWPDATA.LBR_VARIANT OR TEXT.LBR_VARIANT = '*') AND FETCHEDWPDATA.OBJCD1 || FETCHEDWPDATA.OBJCD2 || FETCHEDWPDATA.OBJCD3 = "
					+ "TEXT.OBJCD1 || TEXT.OBJCD2 || TEXT.OBJCD3 AND FETCHEDWPDATA.ACTIVITY = TEXT.ACTIVITY AND FETCHEDWPDATA.VERSION = TEXT.VERSION AND "
					+ "FETCHEDWPDATA.LOCATION = TEXT.LOCATION AND FETCHEDWPDATA.INSTALL_CON = TEXT.INSTALL_CON AND FETCHEDWPDATA.JOBTYPE = TEXT.JOBTYPE AND "
					+ "TEXT.PRCSTAT = 'A' AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL OR "
					+ "RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) GROUP BY FETCHEDWPDATA.R_NUM, FETCHEDWPDATA.RANGE,FETCHEDWPDATA.LBR_VARIANT, "
					+ "FETCHEDWPDATA.OBJCD1, FETCHEDWPDATA.OBJCD2, FETCHEDWPDATA.OBJCD3, FETCHEDWPDATA.ACTIVITY, FETCHEDWPDATA.VERSION, FETCHEDWPDATA.LOCATION, "
					+ "FETCHEDWPDATA.INSTALL_CON, FETCHEDWPDATA.JOBTYPE, FETCHEDWPDATA.LBR_VALUE,FETCHEDWPDATA.LABVAL, FETCHEDWPDATA.TEXT ORDER BY FETCHEDWPDATA.R_NUM";
		}

		return qry;
	}

	/**
	 * Form wp list count qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @param paginationVO
	 *            the pagination vo
	 * @return the string
	 */
	private String formWPListCountQry(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO,
			PaginationVO paginationVO) {
		// LOGGER.info("Inside ** Hibernate Function 9_a -> formWPListQryHibernate ");
		String qry = "";
		workProcessVO.setoBJCD1("");
		workProcessVO.setoBJCD2("");
		workProcessVO.setoBJCD3("");

		if (null != workProcessVO.getlABVAL()) {
			if (workProcessVO.getlABVAL().length() >= 3) {
				workProcessVO.setoBJCD1(workProcessVO.getlABVAL().substring(0,
						3));
			} else {
				workProcessVO.setoBJCD1(workProcessVO.getlABVAL().substring(0,
						workProcessVO.getlABVAL().length()));
			}

			if (workProcessVO.getlABVAL().length() >= 4) {
				workProcessVO.setoBJCD2(workProcessVO.getlABVAL().substring(3,
						4));
			}

			if (workProcessVO.getlABVAL().length() >= 5) {
				if (workProcessVO.getlABVAL().length() >= 7) {
					workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
							.substring(4, 7));
				} else {
					workProcessVO.setoBJCD3(workProcessVO.getlABVAL()
							.substring(4, workProcessVO.getlABVAL().length()));
				}
			}
		} else {
			if (nodeVO.getCode().length() >= 3) {
				workProcessVO.setoBJCD1(nodeVO.getCode().substring(0, 3));
			} else {
				workProcessVO.setoBJCD1(nodeVO.getCode().substring(0,
						nodeVO.getCode().length()));
			}

			if (nodeVO.getCode().length() >= 4) {
				workProcessVO.setoBJCD2(nodeVO.getCode().substring(3, 4));
			}

			if (nodeVO.getCode().length() >= 5) {
				if (nodeVO.getCode().length() >= 7) {
					workProcessVO.setoBJCD3(nodeVO.getCode().substring(4, 7));
				} else {
					workProcessVO.setoBJCD3(nodeVO.getCode().substring(4,
							nodeVO.getCode().length()));
				}
			}
		}
		if (userVO.getVariant().equalsIgnoreCase("All")) {
			qry = "SELECT COUNT(*) as TOTALCOUNT FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT like '%' "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND LABVAL LIKE :code "
					+ "AND "
					+ (workProcessVO.getoBJCD1().trim().equals("") ? "LV.OBJCD1 IS NULL "
							: "LV.OBJCD1 = :objcd1 ")
					+ "AND "
					+ (workProcessVO.getoBJCD2().trim().equals("") ? "LV.OBJCD2 IS NULL "
							: "LV.OBJCD2 = :objcd2 ")
					+ "AND "
					+ (workProcessVO.getoBJCD3().trim().equals("") ? "LV.OBJCD3 IS NULL "
							: "LV.OBJCD3 = :objcd3 ")
					+ "ORDER BY LABVAL) DATA ";
		} else {
			qry = "SELECT COUNT(*) as TOTALCOUNT FROM (SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE <> 'H' AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE like :range AND LBR_VARIANT in (:variant,'*') "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND LABVAL LIKE :code "
					+ "AND "
					+ (workProcessVO.getoBJCD1().trim().equals("") ? "LV.OBJCD1 IS NULL "
							: "LV.OBJCD1 = :objcd1 ")
					+ "AND "
					+ (workProcessVO.getoBJCD2().trim().equals("") ? "LV.OBJCD2 IS NULL "
							: "LV.OBJCD2 = :objcd2 ")
					+ "AND "
					+ (workProcessVO.getoBJCD3().trim().equals("") ? "LV.OBJCD3 IS NULL "
							: "LV.OBJCD3 = :objcd3 ")
					+ "ORDER BY LABVAL) DATA ";
		}

		return qry;
	}

	// ** Hibernate function 10_a
	/**
	 * Form included wp list qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the string
	 */
	private String formIncludedWPListQry(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) {
		// LOGGER.info("Inside ** Hibernate Function 10_a -> formIncludedWPListQryHibernate ");
		String qry = "";
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		if (workProcessVO.getoBJCD1() != null) {
			objCD1 = workProcessVO.getoBJCD1();
			// objCD1 = formCodeOfNLength(objCD1,3);
		}
		if (workProcessVO.getoBJCD2() != null) {
			objCD2 = workProcessVO.getoBJCD2();
			// objCD2 = formCodeOfNLength(objCD2,1);
		}
		if (workProcessVO.getoBJCD3() != null) {
			objCD3 = workProcessVO.getoBJCD3();
			// objCD3 = formCodeOfNLength(objCD3,3);
		}
		String code = objCD1 + objCD2 + objCD3;
		qry = "SELECT DISTINCT CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
				+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || ACT.TEXT AS TEXT, TEXT.RANGE, TEXT.LBR_VARIANT, TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 AS LABVAL, "
				+ "TEXT.RACTIVITY AS ACTIVITY, TEXT.RVERSION AS VERSION, TEXT.RLOCATION AS LOCATION, TEXT.RINSTALL_CON AS INSTALL_CON FROM {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRACTT ACT, {h-schema}WSGLBRTEXT TEXT "
				+ "WHERE ";
		if (!objCD1.equals("")) {
			qry = qry + "TEXT.OBJCD1 = :objcd1 ";
		} else {
			qry = qry + "TEXT.OBJCD1 IS NULL ";
		}
		if (!objCD2.equals("")) {
			qry = qry + "AND TEXT.OBJCD2 = :objcd2 ";
		} else {
			qry = qry + "AND TEXT.OBJCD2 IS NULL ";
		}
		if (!objCD3.equals("")) {
			qry = qry + "AND TEXT.OBJCD3 = :objcd3 ";
		} else {
			qry = qry + "AND TEXT.OBJCD3 IS NULL ";
		}
		// "OBJCD1 || OBJCD2 || OBJCD3 LIKE '" + code + "%' " +
		if (userVO.getVariant().equalsIgnoreCase("All1")) {
			qry = qry
					+ "AND TEXT.ROBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND TEXT.ACTIVITY = :activity "
					+ "AND VERSION = :version "
					+ "AND LOCATION = :location "
					+ "AND INSTALL_CON = :installCon "
					+ "AND JOBTYPE = :jobtype "
					+ "AND RANGE like :range "
					+ "AND LBR_VARIANT like '%' "
					+ "AND TXT_TYPE = '1' "
					+ "AND ACT.SPRAS(+) = :language AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL "
					+ "OR RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) "
					+ "AND TEXT.RACTIVITY = ACT.ACTIVITY(+) AND ACT.PRCSTAT(+) = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' "
					+ "ORDER BY LABVAL, ACTIVITY, VERSION, LOCATION, INSTALL_CON, TEXT";
		} else {
			qry = qry
					+ "AND TEXT.ROBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND TEXT.ACTIVITY = :activity "
					+ "AND VERSION = :version "
					+ "AND LOCATION = :location "
					+ "AND INSTALL_CON = :installCon "
					+ "AND JOBTYPE = :jobtype "
					+ "AND RANGE like :range "
					+ "AND LBR_VARIANT in (:variant,'*') "
					+ "AND TXT_TYPE = '1' "
					+ "AND ACT.SPRAS(+) = :language AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL "
					+ "OR RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) "
					+ "AND TEXT.RACTIVITY = ACT.ACTIVITY(+) AND ACT.PRCSTAT(+) = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' "
					+ "ORDER BY LABVAL, ACTIVITY, VERSION, LOCATION, INSTALL_CON, TEXT";
		}

		return qry;
	}

	public boolean isValidSearch(UserVO userVO, String searchText,
			Integer textBoxId) throws EOIException {
		List result = null;
		String qry = "";
		Session laborValSession = null;
		try {
			switch (textBoxId) {
			case 1:
				qry = "SELECT OBJCD1||OBJCD2||OBJCD3 as OBJCD FROM {h-schema}WSGLBRVAL WHERE OBJCD1||OBJCD2||OBJCD3 =:searchText and "
						+ "RANGE like :range and LBR_VARIANT like :variant";
				break;
			case 2:
				qry = "SELECT ACTIVITY FROM {h-schema}WSGLBRVAL WHERE ACTIVITY =:searchText and "
						+ "RANGE like :range and LBR_VARIANT like :variant";
				break;
			case 3:
				qry = "SELECT VERSION FROM {h-schema}WSGLBRVAL WHERE VERSION =:searchText and "
						+ "RANGE like :range and LBR_VARIANT like :variant";
				break;
			case 4:
				qry = "SELECT LOCATION FROM {h-schema}WSGLBRVAL WHERE LOCATION =:searchText and "
						+ "RANGE like :range and LBR_VARIANT like :variant";
				break;
			case 5:
				qry = "SELECT INSTALL_CON FROM {h-schema}WSGLBRVAL WHERE INSTALL_CON =:searchText and "
						+ "RANGE like :range and LBR_VARIANT like :variant";
				break;
			}
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createQuery(qry);
			query.setParameter("searchText", searchText);
			if (!userVO.getModel().equalsIgnoreCase("All")) {
				query.setParameter("range", userVO.getModel());
			} else {
				query.setParameter("range", "%");
			}
			if (!userVO.getVariant().equalsIgnoreCase("All")) {
				query.setParameter("variant", userVO.getVariant());
			} else {
				query.setParameter("variant", "%");
			}
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
		} catch (Exception e) {
			errorCode = "e546";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		if (result.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	// ** Hibernate function 11_a
	/**
	 * Form not included wp list qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the string
	 */
	private String formNotIncludedWPListQry(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) {
		// LOGGER.info("Inside ** Hibernate Function 11_a -> formNotIncludedWPListQryHibernate ");
		String qry = "";
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		if (workProcessVO.getoBJCD1() != null) {
			objCD1 = workProcessVO.getoBJCD1().trim();
			// objCD1 = formCodeOfNLength(objCD1,3);
		}
		if (workProcessVO.getoBJCD2() != null) {
			objCD2 = workProcessVO.getoBJCD2().trim();
			// objCD2 = formCodeOfNLength(objCD2,1);
		}
		if (workProcessVO.getoBJCD3() != null) {
			objCD3 = workProcessVO.getoBJCD3().trim();
			// objCD3 = formCodeOfNLength(objCD3,3);
		}
		// String code = objCD1 + objCD2 + objCD3;
		qry = "SELECT DISTINCT TEXT.RANGE, TEXT.LBR_VARIANT, ROBJCD1 AS OBJCD1, ROBJCD2 AS OBJCD2, ROBJCD3 AS OBJCD3, TEXT.RACTIVITY AS ACTIVITY, "
				+ "TEXT.RVERSION AS VERSION, TEXT.RLOCATION AS LOCATION, TEXT.RINSTALL_CON AS INSTALL_CON, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
				+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || ACT.TEXT AS TEXT, TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 AS LABVAL "
				+ "FROM {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRACTT ACT, {h-schema}WSGLBRTEXT TEXT "
				+ "WHERE ";
		// TEXT.OBJCD1 || TEXT.OBJCD2 || TEXT.OBJCD3 LIKE '" + code + "%' ";
		if (!objCD1.equals("")) {
			qry = qry + "TEXT.OBJCD1 = :objcd1 ";
		} else {
			qry = qry + "TEXT.OBJCD1 IS NULL ";
		}
		if (!objCD2.equals("")) {
			qry = qry + "AND TEXT.OBJCD2 = :objcd2 ";
		} else {
			qry = qry + "AND TEXT.OBJCD2 IS NULL ";
		}
		if (!objCD3.equals("")) {
			qry = qry + "AND TEXT.OBJCD3 = :objcd3 ";
		} else {
			qry = qry + "AND TEXT.OBJCD3 IS NULL ";
		}

		if (userVO.getVariant().equalsIgnoreCase("All1")) {
			qry = qry
					+ "AND TEXT.ROBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND TEXT.ACTIVITY = :activity "
					+ "AND VERSION = :version "
					+ "AND LOCATION = :location "
					+ "AND INSTALL_CON = :installCon "
					+ "AND JOBTYPE = :jobtype "
					+ "AND RANGE like :range "
					+ "AND LBR_VARIANT like '%' "
					+ "AND TXT_TYPE = '2' "
					+ "AND ACT.SPRAS(+) = :language AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL "
					+ "OR RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) "
					+ "AND TEXT.RACTIVITY = ACT.ACTIVITY(+) AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND ACT.PRCSTAT(+) = 'A' AND TEXT.PRCSTAT = 'A'";
		} else {
			qry = qry
					+ "AND TEXT.ROBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND TEXT.ROBJCD1 || TEXT.ROBJCD2 || TEXT.ROBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND TEXT.ACTIVITY = :activity "
					+ "AND VERSION = :version "
					+ "AND LOCATION = :location "
					+ "AND INSTALL_CON = :installCon "
					+ "AND JOBTYPE = :jobtype "
					+ "AND RANGE like :range "
					//:: Start Change Req 17-02-2014 ::Prabhat Choudhary

					//+ "AND LBR_VARIANT in (:variant) " //
					//::End Change Req 17-02-2014 ::Prabhat Choudhary
					
					+"AND LBR_VARIANT in (:variant,'*') "

				    + "AND TXT_TYPE = '2' "
					+ "AND ACT.SPRAS(+) = :language AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language "
					+ "AND (ROBJCD1 IS NOT NULL OR ROBJCD2 IS NOT NULL OR ROBJCD3 IS NOT NULL OR RVERSION IS NOT NULL OR RLOCATION IS NOT NULL "
					+ "OR RINSTALL_CON IS NOT NULL OR RACTIVITY IS NOT NULL) "
					+ "AND TEXT.RACTIVITY = ACT.ACTIVITY(+) AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND ACT.PRCSTAT(+) = 'A' AND TEXT.PRCSTAT = 'A'";
		}
		return qry;
	}

	// ** Hibernate function 11_b
	/**
	 * Form not included wp details qry.
	 * 
	 * @param userVO
	 *            the user vo
	 * @param workProcessVO
	 *            the work process vo
	 * @param nodeVO
	 *            the node vo
	 * @return the string
	 */
	private String formNotIncludedWPDetailsQry(UserVO userVO,
			WorkProcessVO workProcessVO, NodeVO nodeVO) {
		String qry = "";
		String objCD1 = "";
		String objCD2 = "";
		String objCD3 = "";
		if (workProcessVO.getoBJCD1() != null) {
			objCD1 = workProcessVO.getoBJCD1();
			objCD1 = UIUtil.formCodeOfNLength(objCD1, 3);
		}
		if (workProcessVO.getoBJCD2() != null) {
			objCD2 = workProcessVO.getoBJCD2();
			objCD2 = UIUtil.formCodeOfNLength(objCD2, 1);
		}
		if (workProcessVO.getoBJCD3() != null) {
			objCD3 = workProcessVO.getoBJCD3();
			objCD3 = UIUtil.formCodeOfNLength(objCD3, 3);
		}
		String code = objCD1 + objCD2 + objCD3;
		if (workProcessVO.getaCTIVITY() == null) {
			workProcessVO.setaCTIVITY("");
		}
		if (workProcessVO.getvERSION() == null) {
			workProcessVO.setvERSION("");
		}
		if (workProcessVO.getlOCATION() == null) {
			workProcessVO.setlOCATION("");
		}
		if (workProcessVO.getiNSTALLCON() == null) {
			workProcessVO.setiNSTALLCON("");
		}

		if (userVO.getVariant().equalsIgnoreCase("All1")) {
			// BOC: Work Processes with JOBTYPE V must be selectable - 20.02.2017 - R4867
			qry = "SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE IN ('0', 'V') AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE in (:range,'*') AND LBR_VARIANT like '%' "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND LV.ACTIVITY like :activity "
					+ "AND LV.VERSION like :version "
					+ "AND LV.LOCATION like :location "
					+ "AND LV.INSTALL_CON like :installCon "
					+ "AND LV.JOBTYPE like '%' "
					+ "AND LABVAL LIKE :code ORDER BY LABVAL ";
		} else {
			qry = "SELECT DISTINCT LV.RANGE, LV.LBR_VARIANT, LV.OBJCD1, LV.OBJCD2, LV.OBJCD3, LV.ACTIVITY, LV.VERSION, LV.LOCATION, "
					+ "LV.INSTALL_CON, LV.JOBTYPE, LV.LBR_VALUE, LV.LABVAL, CASE WHEN O2.OBJCD2 IS NULL AND O3.OBJCD3 IS NULL THEN O1.TEXT ELSE '' END || CASE WHEN O2.OBJCD2 IS NOT NULL AND O3.OBJCD3 IS NULL THEN O2.TEXT ELSE '' END "
					+ "|| CASE WHEN O3.OBJCD3 IS NOT NULL THEN O3.TEXT ELSE '' END || ' ' || A.TEXT || ' ' || V.TEXT || ' ' || L.TEXT || ' ' || C.TEXT AS TEXT "
					+ "FROM {h-schema}WSGLBRVAL LV, {h-schema}WSGLBROBJT O1, {h-schema}WSGLBROBJT O2, {h-schema}WSGLBROBJT O3, {h-schema}WSGLBRLOCT L, {h-schema}WSGLBRACTT A, {h-schema}WSGLBRVRST V, {h-schema}WSGLBRCONT C  "
					+ "WHERE LV.OBJCD1 = O1.OBJCD1 AND O1.OBJCD2 IS NULL AND O1.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 = O2.OBJCD1 || O2.OBJCD2 AND O2.OBJCD3 IS NULL "
					+ "AND LV.OBJCD1 || LV.OBJCD2 || LV.OBJCD3 = O3.OBJCD1 || O3.OBJCD2 || O3.OBJCD3 "
					+ "AND LV.LOCATION = L.LOCATION AND LV.ACTIVITY = A.ACTIVITY AND LV.VERSION = V.VERSION "
					+ "AND LV.INSTALL_CON = C.INSTALL_CON AND JOBTYPE IN ('0', 'V') AND LV.ACTIVITY NOT IN ('0','00','000')  "
					+ "AND LV.PRCSTAT = 'A' AND O1.PRCSTAT = 'A' AND O2.PRCSTAT = 'A' AND O3.PRCSTAT = 'A' AND L.PRCSTAT = 'A' AND A.PRCSTAT = 'A' AND V.PRCSTAT = 'A' "
					+ "AND C.PRCSTAT = 'A'  AND RANGE in (:range,'*') AND LBR_VARIANT in (:variant,'*') "
					+ "AND O1.SPRAS = :language AND O2.SPRAS = :language "
					+ "AND O3.SPRAS = :language AND L.SPRAS = :language AND A.SPRAS = :language "
					+ "AND V.SPRAS = :language AND C.SPRAS = :language "
					+ "AND LV.ACTIVITY like :activity "
					+ "AND LV.VERSION like :version "
					+ "AND LV.LOCATION like :location "
					+ "AND LV.INSTALL_CON like :installCon "
					+ "AND LV.JOBTYPE like '%' "
					+ "AND LABVAL LIKE :code ORDER BY LABVAL ";
		}
		// EOC: Work Processes with JOBTYPE V must be selectable - 20.02.2017 - R4867
		return qry;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.man.mn.esa.eoicatalog.laborvalue.helper.ILaborValHelper#fetchCodeText
	 * (de.man.mn.esa.eoicatalog.share.common.vo.UserVO, java.lang.String,
	 * java.lang.String, java.lang.Integer)
	 */
	public String fetchCodeText(UserVO userVO, String text, Integer textId)
			throws EOIException {
		String returnText = "-1MISSINGCODE1-";
		List result = null;
		Session laborValSession = null;
		String qry = "";
		try {
			switch (textId) {
			case 1:
				qry = "SELECT TEXT FROM {h-schema}WSGLBROBJT WHERE OBJCD1||OBJCD2||OBJCD3 =:searchText and SPRAS = :language";
				break;
			case 2:
				qry = "SELECT TEXT FROM {h-schema}WSGLBRACTT WHERE ACTIVITY =:searchText and SPRAS = :language";
				break;
			case 3:
				qry = "SELECT TEXT FROM {h-schema}WSGLBRVRST WHERE VERSION =:searchText and SPRAS = :language";
				break;
			case 4:
				qry = "SELECT TEXT FROM {h-schema}WSGLBRLOCT WHERE LOCATION =:searchText and SPRAS = :language";
				break;
			case 5:
				qry = "SELECT TEXT FROM {h-schema}WSGLBRCONT WHERE INSTALL_CON =:searchText and SPRAS = :language";
				break;
			}
			laborValSession = this.hibernateTemplate.getSessionFactory()
					.openSession();
			Query query = laborValSession.createSQLQuery(qry);
			query.setParameter("searchText", text);
			query.setParameter("language", userVO.getLanguage());
			query.setCacheable(true);
			query.setCacheRegion("eoicatalog.ehcache");
			result = query.list();
			if (result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {
					returnText = result.get(i) + "";
				}
			} else {
				returnText = "-1MISSINGCODE1-";
			}
		} catch (Exception e) {
			errorCode = "e546";
			errorMsg = errorMessages.getProperty(errorCode);
			LOGGER.error("User Name: " + userVO.getUserID() + "\n\nMessage: "
					+ errorMsg + ", full stack trace follows:", e);
			throw new EOIException(errorMsg, errorCode);
		} finally {
			if (laborValSession != null) {
				laborValSession.close();
			}
		}
		return returnText;
	}
}
