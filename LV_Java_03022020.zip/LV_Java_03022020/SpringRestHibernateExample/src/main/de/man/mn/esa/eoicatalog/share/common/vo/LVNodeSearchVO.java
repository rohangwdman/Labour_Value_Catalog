/**
 * Copyright (c) 2011 Infosys Technologies Ltd. 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are not permitted.
 */
package de.man.mn.esa.eoicatalog.share.common.vo;

import de.man.mn.esa.eoicatalog.share.common.BaseVO;

/**
 * The Class LVNodeSearchVO.
 * 
 * Author: Aathavan Sivasubramonian
 */
public class LVNodeSearchVO extends BaseVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8522433151602402466L;

	/** The node vo. */
	private NodeVO nodeVO;

	/** The level. */
	private int level;

	/** The pn condition search. */
	private boolean pnConditionSearch;

	/** The defect search. */
	private boolean defectSearch;

	/**
	 * Instantiates a new lV node search vo.
	 */
	public LVNodeSearchVO() {
		pnConditionSearch = false;
		defectSearch = false;
	}

	/**
	 * Gets the node vo.
	 * 
	 * @return the node vo
	 */
	public NodeVO getNodeVO() {
		return nodeVO;
	}

	/**
	 * Sets the node vo.
	 * 
	 * @param inNodeVO
	 *            the new node vo
	 */
	public void setNodeVO(NodeVO inNodeVO) {
		this.nodeVO = inNodeVO;
	}

	/**
	 * Gets the level.
	 * 
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * Sets the level.
	 * 
	 * @param level
	 *            the new level
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * Sets the pn condition search on.
	 */
	public void setPnConditionSearchOn() {
		pnConditionSearch = true;
	}

	/**
	 * Checks if is pn condition search.
	 * 
	 * @return true, if is pn condition search
	 */
	public boolean isPnConditionSearch() {
		return pnConditionSearch;
	}

	/**
	 * Checks if is defect search.
	 * 
	 * @return true, if is defect search
	 */
	public boolean isDefectSearch() {
		return defectSearch;
	}

	/**
	 * Sets the defect search on.
	 */
	public void setDefectSearchOn() {
		defectSearch = true;
	}

}
