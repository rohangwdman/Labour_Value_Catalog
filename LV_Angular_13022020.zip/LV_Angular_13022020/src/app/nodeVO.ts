import { TreeNode } from 'angular-tree-component';
export class NodeVO{
    type: number;
    code: number;
    name: string;
    toolTipText: string;
    level: number;
    hasChildren: boolean;
    childNodesHaveBeenFetched: boolean;
    children: any[];
    constructor() { 
    }
}