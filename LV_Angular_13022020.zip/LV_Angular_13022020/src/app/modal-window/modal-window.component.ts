import { Component, OnInit,Input, OnDestroy } from '@angular/core';
import { DataTable,DataTableResource,DataTableTranslations } from 'angular5-data-table';
import { TableData } from '../table-data';
import { UserVO } from '../userVO';
import { FetchSearchVO } from '../fetchSearchVO';
import { Subscription, ReplaySubject } from 'rxjs';
//import { ModalModule } from 'ngx-bootstrap/modal';
import {BsModalRef,BsModalService } from 'ngx-bootstrap/modal';
import { FormComponent } from '../form/form.component';
import { TreeToTableService } from '../common.service';
import { TreeModel } from 'angular-tree-component';
import { TreeComponent } from '../tree/tree.component';
import { DataTableComponent } from '../data-table/data-table.component';
import { TreeService } from '../tree.service';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
//import { takeUntil } from 'rxjs/operators/takeUntil';


@Component({
  selector: 'app-modal-window',
  templateUrl: './modal-window.component.html',
  styleUrls: ['./modal-window.component.css']
})
export class ModalWindowComponent implements OnInit,OnDestroy {

  @Input() title: string;
  @Input() close;
  @Input() dismiss;
  @Input() modalType:string;
  @Input() searchResultTitle: string;

  searchObjectCode = '';
  searchText = '';
  //private parentSubscription:Subscription;
  items:Array<any> = TableData;
  searchData:Array<any> = [];
  userVO:UserVO;
  fetchSearchVO:FetchSearchVO;
  itemResource: DataTableResource<any>;
  limits = [10, 20, 40, 80];
  searchDataCount = 0;
  closeResult: string;
  private subscription: Subscription;
  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  constructor(private spinner: NgxSpinnerService,public modalService: BsModalService,private treeService: TreeService,private http: HttpClient,public commonService: TreeToTableService) { }
    
    
    public ngOnInit():void {
      this.commonService.notifyObservable$.subscribe((res) => {
          
        if (res.hasOwnProperty('option') && res.option === 'title') {
          console.log("Received value: ",res);
          // perform your other action from here
          this.title = res.value;
        }
        if (res.hasOwnProperty('option') && res.option === 'modalType') {
          console.log("Received modal value: ",res);
          // perform your other action from here
          this.modalType = res.value;
        }
        if (res.hasOwnProperty('option') && res.option === 'searchResultTitle') {
          console.log("Received modal value: ",res);
          // perform your other action from here
          this.searchResultTitle = res.value;
        }
      });
}

  searchNodes(text:string,objectCode:string){
    this.spinner.show();
    console.log("in search nodes",this.modalType);
    this.fetchSearchVO = {
      code : objectCode+'~',
      searchText : '~'+text+'~',
      userVO : {
        userID:'002',
        language:'EN',
        model:'All',
        variant:'All',
        rearAxel1Type:'',
        motorType:'',
        transmissionType:'',
        catalog:'LABORVALCAT',
        unit:null,
        objectCode1:'',
        objectCode2:'',
        objectCode3:'',
        dmsOrder:''
      },
      paginationVO: {
        numberOfPages:0,
        currentPage:0,
        pageSize:50,
        rows:[],
        totalRecords:0,
        isNextEnabled:false,
        isPreviousEnabled:false,
        isFirstEnabled:false,
        isLastEnabled:false,
        startRowNum:0,
        endRowNum:0,
      }
    }
    
    switch(this.modalType){
      
        case "WP": {
          console.log("in WP search nodes",objectCode);
          this.treeService.getChildObjects(
              'http://localhost:8081/SpringRestHibernateExample/laborval/fetchWPSearchList', this.fetchSearchVO)
          .pipe()    
          .subscribe(result => {
            this.processSearchResult(result)
           }),
          (error:any) => {console.log(error); return [];};
            break;
        }  
        case "Object": {
          console.log("in Object search nodes",this.fetchSearchVO);
          this.treeService.getChildObjects(
              'http://localhost:8081/SpringRestHibernateExample/laborval/fetchObjectSearchList', this.fetchSearchVO)
          .pipe()    
          .subscribe(result => {
            this.processSearchResult(result)
           }),
          (error:any) => {console.log(error); return [];};
          break;
        }
        case "Activity": {
          this.treeService.getChildObjects(
              'http://localhost:8081/SpringRestHibernateExample/laborval/fetchActivitySearchList', this.fetchSearchVO)
          .pipe()    
          .subscribe(result => {
            this.processSearchResult(result)
           }),
          (error:any) => {console.log(error); return [];};
          break;
        }
        case "Version": {
          this.treeService.getChildObjects(
              'http://localhost:8081/SpringRestHibernateExample/laborval/fetchVersionSearchList', this.fetchSearchVO)
          .pipe()    
          .subscribe(result => {
            this.processSearchResult(result)
           }),
          (error:any) => {console.log(error); return [];};
          break;
        }
        case "Position": {
          this.treeService.getChildObjects(
              'http://localhost:8081/SpringRestHibernateExample/laborval/fetchLocationSearchList', this.fetchSearchVO)
          .pipe()    
          .subscribe(result => {
            this.processSearchResult(result)
           }),
          (error:any) => {console.log(error); return [];};
          break;
        }
        case "Condition": {
          this.treeService.getChildObjects(
              'http://localhost:8081/SpringRestHibernateExample/laborval/fetchConditionSearchList', this.fetchSearchVO)
          .pipe()    
          .subscribe(result => {
            this.processSearchResult(result)
           }),
          (error:any) => {console.log(error); return [];};
          break;
        }
    }  
  }

  processSearchResult(result){
    console.log("result:",result);
    for(let workProcessVO of result.rows){
      console.log("text:",workProcessVO);
      this.searchData.push({'name':workProcessVO.lBRVALUE,'info':workProcessVO.lBRVALUE,'text':workProcessVO.tEXT,'model':workProcessVO.rANGE,'variant':workProcessVO.lBRVARIANT,'lvcode':workProcessVO.lBRVALUESepratedWithPipe});
      //this.reloadItems(this.data);
    }
      this.searchDataCount = this.searchData.length;
      this.itemResource = new DataTableResource(this.searchData);
      this.itemResource.query(this.searchData).then(items => this.items = items);
      this.itemResource.count().then(count => this.searchDataCount = count);
      this.spinner.hide();
  }

  reloadItems(params) {
    this.itemResource.query(params).then(data => this.searchData = data);
  }
   
  ngOnDestroy(){
    //this.expandedNode = {};
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  clearModalData(event){
    //console.log("in clear nodes",this.searchObjectCodeValue);
    this.searchObjectCode = '';
    this.searchText = '';
    this.searchData = [];
    this.items = [];
    this.searchDataCount = 0;
  }
}
