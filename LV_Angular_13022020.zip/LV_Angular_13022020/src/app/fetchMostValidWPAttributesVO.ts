import { UserVO } from './userVO';
import { WorkProcessVO } from './workProcessVO';
import { NodeVO } from './nodeVO';
import { PaginationVO } from './paginationVO';


export class FetchMostValidWPAttributesVO{

    nodeVO:NodeVO;
    workProcessVO:WorkProcessVO;
    userVO:UserVO;
    paginationVO:PaginationVO;
    constructor(){
        
    }
}