import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkBasketComponent } from './work-basket.component';

describe('WorkBasketComponent', () => {
  let component: WorkBasketComponent;
  let fixture: ComponentFixture<WorkBasketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkBasketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkBasketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
