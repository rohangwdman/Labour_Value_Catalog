import { Component, AfterViewInit,Input,ViewChild } from '@angular/core';
import { TreeToTableService } from '../common.service';
//import { Subscription } from 'rxjs/Subscription';
import { DataTable,DataTableResource,DataTableTranslations } from 'angular5-data-table';
import { TableData } from '../table-data';
import { DataTableComponent } from '../data-table/data-table.component';
import { ClipboardService } from 'ngx-clipboard';
import { saveAs } from 'file-saver';

@Component({
  selector: 'work-basket',
  templateUrl: './work-basket.component.html',
  styleUrls: ['./work-basket.component.css'],
  providers: [],
})
export class WorkBasketComponent implements AfterViewInit  {

  constructor(private commonService: TreeToTableService,private _clipboardService: ClipboardService) { }
  //private subscription: Subscription;
  objects:Array<any> = [];
  receivedObjects:Array<any> = [];
  message:any = [];
  rowSelected:boolean = false;
  textToCopy:string = '';
  hiddenXmlContent:any = [];
  public ngAfterViewInit():void {
    this.commonService.transferObservable$.subscribe((res) => {
         
      if (res.hasOwnProperty('option') && res.option === 'onDoubleClick' && res.value != null) {
             console.log("Received value in work basket is:",res.value);
             this.objects.push({'name':res.value.text != null ? res.value.text:res.value.desc});
             this.receivedObjects.push(res.value);
      }
    });
  }

  rowClick(rowEvent) {
    this.rowSelected = true;
    console.log('Clicked: ' + JSON.stringify(rowEvent.row.item) );
    console.log('Clicked row pbject: ' + JSON.stringify(this.receivedObjects) );
    this.textToCopy = '<EOICatalog type="laborvalue"><Model>'+this.receivedObjects[0].model+'</Model><Variant>'+this.receivedObjects[0].variant+'</Variant><Language>EN</Language><MotorType></MotorType><TransmissionType></TransmissionType><RearAxle1Type></RearAxle1Type><LaborValue><LabVal>'+this.receivedObjects[0].lvcode+'</LabVal><Quantity>0008</Quantity><Unit>TU</Unit><Description>'+this.receivedObjects[0].text+'</Description><PositionType>000</PositionType></LaborValue></EOICatalog>';
    console.log("Updated XML content: ",this.textToCopy);
    //document.execCommand('copy',false,this.textToCopy);
    this.hiddenXmlContent = this.textToCopy;
  }

  copyXmlContent(){
    console.log("text to be copied:",this.textToCopy);
    this._clipboardService.copyFromContent(this.textToCopy);
  }

  downLoadFile() {
    console.log("Value:",this.textToCopy);
    if(this.textToCopy){
      var blob = new Blob([this.textToCopy], { type: 'text/xml charset=utf-8' });
      var url = window.URL.createObjectURL(blob);
      saveAs(blob,"test.xml");
      //window.open(url);
    }
  }

}
