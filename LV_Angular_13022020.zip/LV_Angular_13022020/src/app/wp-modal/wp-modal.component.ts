import { Component, OnInit,Input,OnDestroy, HostListener } from '@angular/core';
import { DataTable,DataTableResource,DataTableTranslations } from 'angular5-data-table';
import { TableData } from '../table-data';
import { UserVO } from '../userVO';
import { FetchSearchVO } from '../fetchSearchVO';
import { Subscription, ReplaySubject } from 'rxjs';
//import { ModalModule } from 'ngx-bootstrap/modal';
import {BsModalRef,BsModalService } from 'ngx-bootstrap/modal';
import { FormComponent } from '../form/form.component';
import { TreeToTableService } from '../common.service';
import { TreeService } from '../tree.service';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { FetchMostValidWPAttributesVO } from '../fetchMostValidWPAttributesVO';
import { IActionMapping } from 'angular-tree-component';
import { WorkProcessVO } from '../workProcessVO';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { analyzeAndValidateNgModules } from '@angular/compiler';
//import { takeUntil } from 'rxjs/operators/takeUntil';
import { faCaretUp,faSquare,faCircle,faBold } from '@fortawesome/free-solid-svg-icons';

const actionMapping:IActionMapping = {
  
}
@Component({
  selector: 'app-wp-modal',
  templateUrl: './wp-modal.component.html',
  styleUrls: ['./wp-modal.component.css']
})
export class WpModalComponent implements OnInit,OnDestroy {

  @Input() title: string;
  @Input() close;
  @Input() dismiss;
  @Input() modalType:string;
  @Input() searchResultTitle: string;

  searchObjectCode = '';
  searchText = '';
  items:Array<any> = TableData;
  searchData:Array<any> = [];
  middleTabData:Array<any> = [];
  finalTabData:Array<any> = [];
  userVO:UserVO;
  fetchSearchVO:FetchSearchVO;
  itemResource = new DataTableResource(this.searchData);
  limits = [10, 20, 40, 80];
  searchDataCount = 0;
  middleTabDataCount = 0;
  closeResult: string;
  subscription: Subscription;
  fetchMostValidWPAttributesVO:FetchMostValidWPAttributesVO;
  selectedNode = {data:{name:'', level:1,type:1,code:0,id:0}};
  selectedWorkProcessVO:WorkProcessVO;
  tableData:Array<any> = [];
  bsModalRef: BsModalRef;
  workProcessToTransfer = [];
  editField: any;
  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  times = 0;
  selectedRowId:any;
  selectedRowUniqueId: any;
  txtValue:string = null;
  message : string;
  faCaretUp = faCaretUp;
  faSquare = faSquare;
  faCircle = faCircle;
  faBold = faBold;
  constructor(private spinner: NgxSpinnerService,public modalService: BsModalService,private treeService: TreeService,private http: HttpClient,public commonService: TreeToTableService) { }
 
  ngOnInit() {
    this.spinner.show();
    this.subscription = this.commonService.passDataObservable$.subscribe((res) => {
          
      if (res.hasOwnProperty('option') && res.option === 'title') {
        console.log("Received value title: ",res);
        // perform your other action from here
        this.title = res.value;
      }
      if (res.hasOwnProperty('option') && res.option === 'modalType') {
        console.log("Received modal value modalType: ",res);
        // perform your other action from here
        this.modalType = res.value;
        this.searchData = this.fillEmptySearchDataInTable(this.searchData);   
        this.middleTabData = this.fillEmptyDataInTable(this.middleTabData);
        this.finalTabData = this.fillEmptyDataInTable(this.finalTabData);
        console.log("Middle tab data:",this.middleTabData.length);
        setTimeout(()=>{    
          this.getWorkProcesses();
        }, 10000);
      }
      if (res.hasOwnProperty('option') && res.option === 'searchResultTitle') {
        console.log("Received modal value searchResultTitle: ",res);
        // perform your other action from here
        this.searchResultTitle = res.value;
      }
      if(res.hasOwnProperty('option') && res.option === 'selectedData'){
        console.log("Received modal value selectedData: ",res);
        // perform your other action from here
        this.selectedNode = res.value;
      }
      if (res.hasOwnProperty('option') && res.option === 'workProcessVO') {
        console.log("Received value title: ",res);
        // perform your other action from here
        this.selectedWorkProcessVO= res.value;
      }  
      
    });
  }
  ngOnDestroy(){
    //this.subscription.unsubscribe();
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
  fillEmptySearchDataInTable(tableName:any){
    for(let i=0;i<=1;i++){
      tableName.push({
        'desc':"",
        'object':"",
        'activity':"",
        'version':"",
        'position':"",
        'condition':""});
    }
    return tableName;
  }
  fillEmptyDataInTable(tableName:any){
    for(let i=0;i<=1;i++){
      tableName.push({
        'desc':"",
        'middlelBRVALUE':"",
        'lBRVALUECODE':""
       });
    }
    return tableName;
  }
  getWorkProcesses(){
      console.log("selected node at modal: ",this.selectedNode);
      this.fetchMostValidWPAttributesVO = {
        userVO: {
          userID:'eoiread',
          language:'EN',
          model:'All',
          variant:'All',
          rearAxel1Type:'',
          motorType:'',
          transmissionType:'',
          catalog:'LABORVALCAT',
          unit:'TU',
          objectCode1:'',
          objectCode2:'',
          objectCode3:'',
          dmsOrder:''
        },
        workProcessVO: {
          rANGE:this.selectedWorkProcessVO.rANGE,
          lBRVARIANT:this.selectedWorkProcessVO.lBRVARIANT,
          oBJCD1:this.selectedWorkProcessVO.oBJCD1,
          oBJCD2:this.selectedWorkProcessVO.oBJCD2,
          oBJCD3:this.selectedWorkProcessVO.oBJCD3,
          vERSION:this.selectedWorkProcessVO.vERSION,
          lOCATION:this.selectedWorkProcessVO.lOCATION,
          iNSTALLCON:this.selectedWorkProcessVO.iNSTALLCON,
          aCTIVITY:this.selectedWorkProcessVO.aCTIVITY,
          vKORG:null,
          lBRVALUE:this.selectedWorkProcessVO.lBRVALUE,
          lABVAL:this.selectedWorkProcessVO.lABVAL,
          pRCSTAT:null,
          tEXT:this.selectedWorkProcessVO.tEXT,
          tXTTYPE:null,
          nOOFINCLUDEDWP:this.selectedWorkProcessVO.nOOFINCLUDEDWP,
          nOOFNOTINCLUDEDWP:this.selectedWorkProcessVO.nOOFNOTINCLUDEDWP,
          pOSITIONTYPE:null,
          jOBTYPE:this.selectedWorkProcessVO.jOBTYPE
        },
        nodeVO: {
          type:null,
          code:null,
          name:null,
          toolTipText:null,
          level:null,
          hasChildren:null,
          childNodesHaveBeenFetched: false,
          children:[]
        },
        paginationVO: {
          numberOfPages:0,
          currentPage:0,
          pageSize:50,
          rows:[],
          totalRecords:0,
          isNextEnabled:false,
          isPreviousEnabled:false,
          isFirstEnabled:false,
          isLastEnabled:false,
          startRowNum:0,
          endRowNum:0,
        }
     }
     if(this.modalType == "Included"){
       this.getIncludedWorkProcesses();
     }else{
       this.getNotIncludedWorkProcesses();
     }
     //this.bsModalRef = this.modalService.show(this, {class: 'modal-lg'});
     this.searchDataCount = this.searchData.length; 
     this.itemResource.count().then(count => this.searchDataCount = count);
     //this.reloadItems(this.searchData);
     this.spinner.hide();
   }
   getIncludedWorkProcesses(){
    this.treeService.getChildObjects(
        'http://localhost:8081/SpringRestHibernateExample/laborval/fetchIncludedWPList', this.fetchMostValidWPAttributesVO)
    .pipe()     
    .subscribe(result => {
      this.processResponse(result)
     }),
    (error:any) => {console.log(error); return [];};
   }
   getNotIncludedWorkProcesses(){
      console.log("fetchMostValidWPAttributesVO: ",this.fetchMostValidWPAttributesVO);
      this.treeService.getChildObjects(
          'http://localhost:8081/SpringRestHibernateExample/laborval/fetchNotIncludedWPWithDetailsList', this.fetchMostValidWPAttributesVO)
      .pipe()     
      .subscribe(result => {
        this.processResponse(result)
       }),
      (error:any) => {console.log(error); return [];};
   }
   reloadItems(params) {
     this.itemResource.query(params).then(items =>{
       this.items = items;
       console.log("params qqq: "+items);  
       this.itemResource.count().then(count => this.searchDataCount = count);
     });
   }
   reloadMiddleTabItems(params){
    this.itemResource.query(params).then(items =>{
      this.items = items;
      console.log("params middle tab: "+items);  
      this.itemResource.count().then(count => this.middleTabDataCount = count);
    });
   }
   getSubProcesses(rowId:any,uniqueRowId:any){
     console.log("workProcessVO 11: ",uniqueRowId);
     let item :any;
     if(this.modalType != null && this.modalType != "Included"){
      this.middleTabData = [];
      if(this.searchData != null && this.searchData.length > 0){
        item = this.getSelectedWorkProcess(rowId,uniqueRowId);
        console.log("Received SubworkProcesses : ",item,"Test:",item.uniqueId == uniqueRowId);
        if(item.uniqueId == uniqueRowId){
          item.subWorkProcesses.forEach(workProcessVO => {
            console.log("Received SubworkProcesses 1 : ",workProcessVO);
            this.middleTabData.push({
              'uniqueId':Math.floor(1000 + Math.random() * 9000),
              'desc':workProcessVO.tEXT,
              'middlelBRVALUE':workProcessVO.lBRVALUE,
              'lBRVALUECODE':workProcessVO.lBRVALUECODE
              });
            });
          console.log("SubworkProcesses 1: ",this.middleTabData);
            const data = [];
            this.middleTabData.map(wp => {
              if (wp.desc != null && wp.desc != '') {
                data.push(wp);
              }
            }); 
            this.middleTabData = data;
        }
          
          //this.reloadMiddleTabItems(this.middleTabData);
        }   
     }
   }
  getSelectedWorkProcess(uniqueRowId: any,uniqueId:any): any {
    console.log("getSelectedWorkProcess:",uniqueId + "uniqueRowId :", uniqueRowId);
    let validWorkProcess = null;
    if(uniqueId != null && uniqueId != "" && 
       uniqueRowId != null && uniqueRowId == "firstTableData"){
        this.searchData.forEach(workProcessVO => {
            console.log("getSelectedWorkProcess:",workProcessVO.uniqueId);
             if(workProcessVO.uniqueId == uniqueId){
                  console.log("getSelectedWorkProcess 1:",workProcessVO);
                  validWorkProcess =  workProcessVO;
            }
           //validWorkProcess = this.searchData.filter(item => item.indexOf(uniqueId) !== -1);
        });
    }else if(uniqueId != "" && uniqueRowId == "secondTableData"){
          this.middleTabData.forEach(workProcessVO => {
            console.log("getSelectedWorkProcess middleTabData:",workProcessVO.uniqueId);
             if(workProcessVO.uniqueId == uniqueId){
                  console.log("getSelectedWorkProcess middleTabData 1:",workProcessVO);
                  validWorkProcess =  workProcessVO;
            }
           //validWorkProcess = this.searchData.filter(item => item.indexOf(uniqueId) !== -1);
        });
    }else{
      this.finalTabData.forEach(workProcessVO => {
        console.log("getSelectedWorkProcess finalTabData:",workProcessVO.uniqueId);
         if(workProcessVO.uniqueId == uniqueId){
              console.log("getSelectedWorkProcess finalTabData 1:",workProcessVO);
              validWorkProcess =  workProcessVO;
        }
       //validWorkProcess = this.searchData.filter(item => item.indexOf(uniqueId) !== -1);
    });
    }
        console.log("getSelectedWorkProcess returning:",validWorkProcess);
        return validWorkProcess;
  }
  
   middleTabRowDoubleClick(rowId:any,uniqueRowId:any){
      console.log("middletab double click",rowId,uniqueRowId);
      let item :any;
           
      item = this.getSelectedWorkProcess(rowId,uniqueRowId);
      console.log("Received SubworkProcesses : ",item,"Test:",item.uniqueId == uniqueRowId);
      if(item.middlelBRVALUE == "****" && (this.txtValue == "" || this.txtValue == undefined || this.txtValue == 'undefined')){
        console.log("value not present...",this.txtValue);
        return;
      }
      if(item.uniqueId == uniqueRowId){
        this.finalTabData.push({
          'uniqueId':uniqueRowId,
          'desc':item.desc,
          'middlelBRVALUE':item.middlelBRVALUE != "" && item.middlelBRVALUE != "****"?item.middlelBRVALUE:this.txtValue,
          'lBRVALUECODE':item.lBRVALUECODE
        });
      console.log("SubworkProcesses : ",this.finalTabData);
      const data = [];
      this.finalTabData.map(wp => {
        if (wp.desc != null && wp.desc != '') {
          data.push(wp);
        } 
      this.finalTabData = data;
    });
    }
    this.txtValue = "";
   }
   finalTabRowClick(rowId,uniqueRowId){
      //let rowId = e.target.parentElement.id.split('_')[0] != ""?e.target.parentElement.id.split('_')[0]:e.target.parentElement.parentElement.id.split('_')[0];
      //let uniqueRowId = e.target.parentElement.id.split('_')[0] != ""?e.target.parentElement.id.split('_')[1]:e.target.parentElement.parentElement.id.split('_')[1];
      let item:any;
      item = this.getSelectedWorkProcess(rowId,uniqueRowId);
      console.log("Row click : ",item);
      this.workProcessToTransfer = item;
   }
   transferWorkProcess(){
     this.commonService.transferOther({option: 'onDoubleClick', value: this.workProcessToTransfer});
   }
   middleTabRowClick(){

   }
   rowClick(){

   }


   @HostListener('dblclick', ['$event']) onDoubleClicked(e) {
     console.log('onDoubleClicked ran!',e);
     this.selectedRowId = e.target.parentElement.id.split('_')[0] != ""?e.target.parentElement.id.split('_')[0]:e.target.parentElement.parentElement.id.split('_')[0];
     this.selectedRowUniqueId = e.target.parentElement.id.split('_')[0] != ""?e.target.parentElement.id.split('_')[1]:e.target.parentElement.parentElement.id.split('_')[1];
     if(this.selectedRowId != null && this.selectedRowId == "firstTableData"){
         this.getSubProcesses(this.selectedRowId,this.selectedRowUniqueId);
     }else if(this.selectedRowId != null && this.selectedRowId == "secondTableData"){
         this.middleTabRowDoubleClick(this.selectedRowId,this.selectedRowUniqueId);
     }
     
     console.log("selectedRowId : ",this.selectedRowId + "selectedUniqueRowId:", this.selectedRowUniqueId);
   }

   @HostListener('click', ['$event']) onClicked(e) {
     let rowId = e.target.parentElement.id.split('_')[0] != ""?e.target.parentElement.id.split('_')[0]:e.target.parentElement.parentElement.id.split('_')[0];
     let uniqueRowId = e.target.parentElement.id.split('_')[0] != ""?e.target.parentElement.id.split('_')[1]:e.target.parentElement.parentElement.id.split('_')[1];
     console.log('onClicked ran!', rowId, ".........",uniqueRowId);
     if(rowId != null && rowId == "thirdTableData"){
      this.finalTabRowClick(rowId,uniqueRowId);
     }
     this.times++;
   }

   processResponse(data){
      //let schedule: new Map(new WorkProcessVO(), any[]);
      console.log("Received value in modal processResponse: ",data);
      this.searchData = [];
      for(let workProcessVO of data){
          this.searchData.push({
            'uniqueId':Math.floor(1000 + Math.random() * 9000),
            'desc':workProcessVO.tEXT,
            'object':workProcessVO.oBJCD1 != null?workProcessVO.oBJCD1:''
            +"|"+ workProcessVO.oBJCD2 != null?workProcessVO.oBJCD2:''
            +"|"+ workProcessVO.oBJCD3 != null?workProcessVO.oBJCD3:'',
            'activity':workProcessVO.aCTIVITY,
            'version':workProcessVO.vERSION,
            'position':workProcessVO.lOCATION,
            'condition':workProcessVO.iNSTALLCON,
            'subWorkProcesses':workProcessVO.subWorkProcessVOs});
          }
          console.log("text:",this.searchData);
   }

   changeValueForQuantity(property: string, event: any) {
    console.log("in change value quantity:",this.searchData);
    this.editField = event.target.textContent;
   }
}
