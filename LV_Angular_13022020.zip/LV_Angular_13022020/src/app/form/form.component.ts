import { Component, OnInit,ViewChild, Input, Renderer2  } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { TreeToTableService } from '../common.service';
import { TreeModel } from 'angular-tree-component';
import { TreeComponent } from '../tree/tree.component';
import { DataTableComponent } from '../data-table/data-table.component';
import { TreeService } from '../tree.service';
import { HttpClient } from '@angular/common/http';
//import { TableToWorkBasketService } from '../table-to-work-basket.service';
import { DataTable,DataTableResource,DataTableTranslations } from 'angular5-data-table';
import { TableData } from '../table-data';
import { UserVO } from '../userVO';
import { FetchSearchVO } from '../fetchSearchVO';
import {BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ModalWindowComponent } from '../modal-window/modal-window.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService,public modalService: BsModalService,private treeService: TreeService,private http: HttpClient,public commonService: TreeToTableService) { 

  }

  quantityCode:string;
  workTypeCode:string;
  conditionCode:string;
  positionCode:string;
  versionCode:string;
  activityCode:string;
  objectCode1:string;
  objectCode2:string;
  objectCode3:string;
  description:string;
  modelCode:string;
  variantCode:string;
  motorTypeCode:string;
  transmissionCode:string;
  rearAxleCode:string;
  disableQuantityBox:boolean;
  searchObjectCode = '';
  searchText = '';
  private parentSubscription:Subscription;
  private quantityboxSubscription:Subscription;
  @ViewChild(TreeModel, {static: false})
  private treeModel: TreeModel;
  items:Array<any> = TableData;
  searchData:Array<any> = [];
  userVO:UserVO;
  fetchSearchVO:FetchSearchVO;
  itemResource: DataTableResource<any>;
  limits = [10, 20, 40, 80];
  bsModalRef: BsModalRef;
  searchDataCount = 0;
  closeResult: string;
  loadComponent:boolean = false;
  renderer:Renderer2;
  faSearch = faSearch;
  //@Input() myForm: FormGroup;
  //@ViewChild(TreeComponent, {static: false})
  //private treeComponent:TreeComponent;

  ngOnInit() {
    this.parentSubscription = this.commonService.notifyObservable$.subscribe((res) => {            
      if (res.hasOwnProperty('option') && res.option === 'onSelect' && res.value != null) {
        console.log("Received value in form: ",res);        
        for(let workProcessVO of res.value){
           //console.log("text:",workProcessVO);
           this.setFormContents(workProcessVO);         
        }
      }      
    });
    this.loadVariantList();
    //this.loadRangeList();
  }

  open(content:string) {
    console.log("in open modal method",content);
    this.bsModalRef = this.modalService.show(ModalWindowComponent, {class: 'modal-lg'});
    this.commonService.notifyOther({option: 'modalType', value:content});
    switch(content){
      
      case 'WP': {
        this.commonService.notifyOther({option: 'title', value:'Labour Value Catalog - Search Workprocesses'});
        this.commonService.notifyOther({option: 'searchResultTitle', value:'Workprocesses search results'});
        break;
      }  
      case 'Object': {
        this.commonService.notifyOther({option: 'title', value:'Look up - Object'});
        this.commonService.notifyOther({option: 'searchResultTitle', value:'Object Code search results'});
        break;
      }
      case 'Activity': {
        this.commonService.notifyOther({option: 'title', value:'Look up - Activity'});
        this.commonService.notifyOther({option: 'searchResultTitle', value:'Activity Code search results'});
        break;
      }
      case 'Version': {
        this.commonService.notifyOther({option: 'title', value:'Look up - Version'});
        this.commonService.notifyOther({option: 'searchResultTitle', value:'Version/Location Code search results'});
        break;
      }
      case 'Position': {
        this.commonService.notifyOther({option: 'title', value:'Look up - Position'});
        this.commonService.notifyOther({option: 'searchResultTitle', value:'Position/Number Code search results'});
        break;
      }
      case 'Condition': {
        this.commonService.notifyOther({option: 'title', value:'Look up - Condition'});
        this.commonService.notifyOther({option: 'searchResultTitle', value:'Condition Code search results'});
        break;
      }
      
  } 
    //this.loadComponent = true;
    console.log("in open modal method 2");
  }

  clearFormContents(treeModel){
    //let formComponent = new FormComponent(this.modalService,this.treeService,this.http,this.commonService,this.tableToWorkBasketService);
    this.quantityCode = '';
    this.workTypeCode = '';
    this.conditionCode = '';
    this.positionCode = '';
    this.versionCode = '';
    this.activityCode = '';
    this.objectCode1 = '';
    this.objectCode2 = '';
    this.objectCode3 = '';
    this.description = '';
    var element = <HTMLInputElement> document.getElementById("quantityCode");
    console.log("element:",element);
    element.disabled = true;
    let tableComponent = new DataTableComponent(this.spinner,this.commonService,this.modalService);
    tableComponent.mainTableData = [];
    tableComponent.mainTableDataCount = 0;
    let treeComponent = new TreeComponent(this.renderer,this.spinner,this.treeService,this.http,this.commonService);
    treeComponent.nodes = [].concat(treeComponent.nodes);
    treeComponent.collapseTree();
    this.commonService.notifyOther({option: 'onSelect', value: []});
  }

  transferWorkProcess(){
    console.log("in transfer work processes form");
    let tableComponent = new DataTableComponent(this.spinner,this.commonService,this.modalService);
    tableComponent.transferSelectedRowToWorkBasket();
  }

 setFormContents(workProcessVO){
    //this.quantityCode = '';
    console.log("workprocessVo: ",workProcessVO);
    this.workTypeCode = workProcessVO.jOBTYPE;
    this.conditionCode = '';// CONDITION CODE NEEDS TO BE SET
    this.positionCode = workProcessVO.pOSITIONTYPE;
    this.versionCode = workProcessVO.vERSION;
    this.activityCode = workProcessVO.aCTIVITY;
    this.objectCode1 = workProcessVO.oBJCD1;
    this.objectCode2 = workProcessVO.oBJCD2;
    this.objectCode3 = workProcessVO.oBJCD3;
    this.description = workProcessVO.tEXT;
    localStorage.clear();
    if(workProcessVO.lBRVALUE == null || workProcessVO.lBRVALUE === "" || workProcessVO.lBRVALUE == "****"){
      var element = <HTMLInputElement> document.getElementById("quantityCode");
      //console.log("element:",element);
      element.disabled = false;
    }
  }

  loadVariantList(){
      console.log("loading variant list...");
      /** this.treeService.getChildObjects(
        'http://localhost:8081/SpringRestHibernateExample/laborval/fetchObjectSearchList', this.fetchSearchVO)
      .pipe()    
      .subscribe(result => {
         this.processSearchResult(result)
      }),
      (error:any) => {console.log(error); return [];};
      */
  }
  
}
