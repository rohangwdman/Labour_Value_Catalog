export class PaginationVO{
    numberOfPages:number;
    currentPage:number;
    pageSize:number;
    rows:any[];
    totalRecords:number;
    isNextEnabled:boolean;
    isPreviousEnabled:boolean;
    isFirstEnabled:boolean;
    isLastEnabled:boolean;
    startRowNum:number;
    endRowNum:number;
    constructor() { 
    }
}