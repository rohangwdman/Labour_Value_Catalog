import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TreeModule } from 'angular-tree-component';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { TreeComponent } from './tree/tree.component';
import { TreeService } from './tree.service';
import { HttpModule } from '@angular/http';
import { Ng2TableModule } from 'ng2-table/ng2-table';
//import { PaginationModule } from 'ngx-bootstrap/pagination';
//import {TableComponent} from './table-component';
import { FormsModule,FormBuilder,ReactiveFormsModule  } from '@angular/forms';
import { TreeToTableService } from './common.service';
import { DataTableModule } from 'angular5-data-table';
import { DataTableComponent } from './data-table/data-table.component';
import { WorkBasketComponent } from './work-basket/work-basket.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormComponent } from './form/form.component';
import { ModalWindowComponent } from './modal-window/modal-window.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ClipboardModule } from 'ngx-clipboard';
import { ClipboardService } from 'ngx-clipboard';
import { WpModalComponent } from './wp-modal/wp-modal.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSelectModule } from '@angular/material';
//import { saveAs } from 'file-saver';

@NgModule({
  declarations: [
    AppComponent,
    TreeComponent,
    DataTableComponent,
    WorkBasketComponent,
    FormComponent,
    ModalWindowComponent,
    WpModalComponent
  ],
  imports: [
    BrowserModule,TreeModule,HttpClientModule,HttpModule,Ng2TableModule,
    FormsModule,ReactiveFormsModule,DataTableModule.forRoot(),ModalModule.forRoot(),
    NgxSpinnerModule,ClipboardModule,BrowserAnimationsModule,MatSelectModule
  ],
  providers: [TreeService,FormBuilder,TreeToTableService,ClipboardService],
  bootstrap: [AppComponent,DataTableComponent],
  entryComponents: [ModalWindowComponent,WpModalComponent]
})
export class AppModule { }
