export class UserVO {
    userID:string;
    language:string;
    model:string;
    variant:string;
    rearAxel1Type:string;
    motorType:string;
    transmissionType:string;
    catalog:string;
    unit:string;
    objectCode1:string;
    objectCode2:string;
    objectCode3:string;
    dmsOrder:string;
    constructor() { 
    }
 } 