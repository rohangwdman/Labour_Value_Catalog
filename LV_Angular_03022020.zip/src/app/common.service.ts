import { Injectable, Inject,Output,EventEmitter } from '@angular/core';
//import { Subject }    from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable()
export class TreeToTableService {

  private messageSource1 = new BehaviorSubject<any>("");
  private messageSource2 = new BehaviorSubject<any>("");
  private messageSource3 = new BehaviorSubject<any>("");
  
  /**
   * Observable string streams
   */
  notifyObservable$ = this.messageSource1.asObservable();


  constructor(){}

  public notifyOther(data: any) {
    if (data) {
      this.messageSource1.next(data);
    }
  }
  
  transferObservable$ = this.messageSource2.asObservable();

  public transferOther(data: any) {
    if (data) {
      this.messageSource2.next(data);
    }
  }

  passDataObservable$ = this.messageSource3.asObservable();

  public passData(data: any) {
    if (data) {
      this.messageSource3.next(data);
    }
  }
}