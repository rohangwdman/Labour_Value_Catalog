import { UserVO } from './userVO';
import { WorkProcessVO } from './workProcessVO';
import { NodeVO } from './nodeVO';


export class FetchChildVO{

    nodeVO:NodeVO;
    workProcessVO:WorkProcessVO;
    userVO:UserVO;
    constructor(){
        
    }
}