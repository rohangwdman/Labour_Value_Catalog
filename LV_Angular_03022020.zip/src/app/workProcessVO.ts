export class WorkProcessVO{
    rANGE:string;
    lBRVARIANT: string;
    oBJCD1: string;
    oBJCD2: string;
    oBJCD3: string;
    vERSION: string;
    lOCATION: string;
    iNSTALLCON: string;
    aCTIVITY: string;
    vKORG: string;
    lBRVALUE: string;
    lABVAL: string;
    pRCSTAT: string;
    tEXT: string;
    tXTTYPE: string;
    nOOFINCLUDEDWP: 0;
    nOOFNOTINCLUDEDWP: 0;
    pOSITIONTYPE: string;
    jOBTYPE:string;
    constructor() { 
    }
}