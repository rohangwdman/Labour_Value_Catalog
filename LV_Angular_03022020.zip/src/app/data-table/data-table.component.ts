import { Component,OnInit,Input } from '@angular/core';
import { DataTable,DataTableResource,DataTableTranslations } from 'angular5-data-table';
import { TableData } from '../table-data';
import { TreeToTableService } from '../common.service';
//import { Subscription } from 'rxjs/Subscription';
//import { TableToWorkBasketService } from '../table-to-work-basket.service';
import { NgxSpinnerService } from 'ngx-spinner';
import {BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { WpModalComponent } from '../wp-modal/wp-modal.component';
import { WorkProcessVO } from '../workProcessVO';

@Component({
    selector: 'data-table-demo-1',
    providers: [],
    templateUrl: './data-table.component.html',
    styleUrls: ['./data-table.component.css']
})


export class DataTableComponent {
   
    items:Array<any> = TableData;
    mainTableData:Array<any> = [];
    itemResource = new DataTableResource(this.mainTableData);
    //itemResource = null;
    //items = null;
    mainTableDataCount = 0;
    selectedRowData:any = [];
    bsModalRef: BsModalRef;
    selectedWorkProcessVO:WorkProcessVO;
    //private subscription: Subscription;
    
    public ngOnInit():void {
          this.commonService.notifyObservable$.subscribe((res) => {
              
            if (res.hasOwnProperty('option') && res.option === 'onSelect') {
              console.log("Received value: ",res);
              // perform your other action from here
              this.mainTableData = [];
              for(let workProcessVO of res.value){
                 console.log("text:",workProcessVO);
                 this.selectedWorkProcessVO = workProcessVO;
                 this.mainTableData.push({'name':workProcessVO.lBRVALUE,'info':workProcessVO.lBRVALUE,'text':workProcessVO.tEXT,
                                          'model':workProcessVO.rANGE,'variant':workProcessVO.lBRVARIANT,'lvcode':workProcessVO.lBRVALUESepratedWithPipe,
                                          'noOfIncludedWPs':workProcessVO.nOOFINCLUDEDWP,'noOfNotIncludedWPs':workProcessVO.nOOFNOTINCLUDEDWP});
                 //this.reloadItems(this.data);
              }
            }
            this.mainTableDataCount = this.mainTableData.length; 
            this.itemResource.count().then(count => this.mainTableDataCount = count);
            this.spinner.hide();
              //console.log("dddd: "+this.data);
          });
          //    this.reloadItems(this.mainTableData);
    }

    constructor(private spinner: NgxSpinnerService,private commonService: TreeToTableService,public modalService: BsModalService) {
        
    }

    reloadItems(params) {
       this.itemResource.query(params).then(items =>{
          this.items = items;
          console.log("params qqq: "+items);  
          this.itemResource.count().then(count => this.mainTableDataCount = count);
        });
    }

    // special properties:
    rowClick(rowEvent) {
        this.selectedRowData = rowEvent.row.item;
        localStorage.setItem('rowSelected',JSON.stringify(rowEvent.row.item));
        console.log('Clicked: ' + localStorage.getItem('rowSelected') );
    }

    transferSelectedRowToWorkBasket(){
        console.log("in transfer work processes data");
        if(localStorage.getItem('rowSelected') != null || localStorage.getItem('rowSelected') != ''){
            console.log("in transfer work processes data 1",localStorage.getItem('rowSelected'));
            this.commonService.transferOther({option: 'onDoubleClick', value:  JSON.parse(localStorage.getItem('rowSelected'))});
        }

        setTimeout(() => {
            localStorage.rowSelected = null;
        }, 2000);
    }

    rowDoubleClick(rowEvent) {  
      console.log("rowEvent : ",rowEvent);
        if(rowEvent.row.item.noOfIncludedWPs > 0 && rowEvent.row.item.noOfNotIncludedWPs == 0){
          this.open('Included');
        }else if(rowEvent.row.item.noOfNotIncludedWPs > 0){
          this.open('Not included');
        }else{
          this.commonService.transferOther({option: 'onDoubleClick', value: rowEvent.row.item});
        }
    }

    rowTooltip(item) { return item.name; }
    clearTableContent(){
        console.log("in clear table content");
        this.items = [];
        this.mainTableData = [];
        //this.reloadItems(this.data);
    }

    open(content:string) {
        console.log("in open modal method of data table ",content);
        this.bsModalRef = this.modalService.show(WpModalComponent, {class: 'modal-lg'});
        this.commonService.passData({option: 'modalType', value:content});
        this.commonService.passData({option: 'workProcessVO', value:this.selectedWorkProcessVO});
        switch(content){
          
          case 'Included': {
            this.commonService.passData({option: 'title', value:'Labour Value Catalog - Included Work Processes'});
            this.commonService.passData({option: 'searchResultTitle', value:'Included Work Processes'});
            break;
          }  
          case 'Not included': {
            this.commonService.passData({option: 'title', value:'Labour Value Catalog - Not Included Work Processes'});
            this.commonService.passData({option: 'searchResultTitle', value:'Not Included Work Processes'});
            break;
          }
       } 
    }  
}