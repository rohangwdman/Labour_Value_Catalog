import { TreeModule, TreeNode, TreeModel,TREE_ACTIONS, KEYS, IActionMapping, ITreeOptions } from 'angular-tree-component';
import { Component,OnInit,EventEmitter,ViewChild, OnDestroy, ElementRef, Renderer2 } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserVO } from '../userVO';
import { WorkProcessVO } from '../workProcessVO';
import { NodeVO } from '../nodeVO';
import { FetchChildVO } from '../fetchChildVO';
import { FetchMostValidWPAttributesVO } from '../fetchMostValidWPAttributesVO';
import { TreeService } from '../tree.service';
//import {Observable, ReplaySubject} from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import { TreeToTableService } from '../common.service';
import { NgxSpinnerService } from 'ngx-spinner';
//import { takeUntil } from 'rxjs/operators/takeUntil';

const actionMapping:IActionMapping = {
  
}

// usage:
@Component({
  selector: 'app-tree',
  template: `<div style="height: 350px; width: 100%; overflow: hidden;"> <tree-root #myTree class="expand-tree" [focused]="true" [nodes]="nodes" [options]="options" (toggleExpanded)="this.treeNodeSelected($event)" > 
            <ng-template #treeNodeWrapperTemplate let-node let-index="index">
            <div class="node-wrapper"  (dblclick)="node.mouseAction('click', this.treeNodeDoubleClick(node))">
            <tree-node-expander [node]="node"></tree-node-expander>
            <div class="node-content-wrapper">             
            <span *ngIf="node.data.type === 1;else second">
            <i  #objectDom class="icon-folder ace-icon fa fa-folder" style="color:orange;margin-right:2px"></i></span> 
            <ng-template #second>
             <span *ngIf="node.data.type === 2;else third">
             <i class="icon-folder ace-icon fa fa-hand-paper-o icon-d" ></i></span>
             </ng-template>
             <ng-template #third><span >
             <i #third class="icon-folder ace-icon fa fa-bolt" style="color:red;margin-right:2px"></i></span></ng-template>
             <span class="nodeDetails"><span>{{ node.data.code }}</span>&nbsp;<span>{{ node.data.name }}</span></span>
             <ng-template #loadingTemplate><span><i class="icon-Kfolder ace-icon fa fa-spinner fa fa-spin" style="color:red;margin-left:20px"></i></span></ng-template> 
             </div></div>
             </ng-template>
            </tree-root></div>`         
})

export class TreeComponent implements OnInit,OnDestroy{
  userVO:UserVO;
  workProcessVO:WorkProcessVO;
  nodeVO : NodeVO;
  fetchChildVO:FetchChildVO;
  fetchMostValidWPAttributesVO:FetchMostValidWPAttributesVO;
  nodes:Array<NodeVO>;
  //childrens:{}[] = [];
  expandedNode = {data:{name:'', level:1,type:1,code:0,id:0}};
  selectedNode = {name:'', level:1,type:1,code:0,id:0};
  //treeModel:TreeModel;
  //@ViewChild(TreeComponent)
  collapseTreeOnClear: boolean = false;
  public nodeExpanded:boolean = false;
  @ViewChild('objectDom') objectDomElement:ElementRef;
  treeModel: TreeModel;
  isTypeUpdated:boolean = false;
  laborCode = '';
  //private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  constructor(private renderer: Renderer2,private spinner: NgxSpinnerService,private treeService: TreeService,private http: HttpClient,public commonService: TreeToTableService){
      
  }

   ngOnInit(): void {
    this.spinner.show();
    this.userVO = {
      userID:'002',
      language:'EN',
      model:'All',
      variant:'All',
      rearAxel1Type:'',
      motorType:'',
      transmissionType:'',
      catalog:'LABORVALCAT',
      unit:null,
      objectCode1:'',
      objectCode2:'',
      objectCode3:'',
      dmsOrder:''
    };
    /* this.treeService.getServiceWithJsonObjectAsQueryString(
      'http://localhost:8081/SpringRestHibernateExample/laborval/fetchRootNodes',this.userVO).subscribe(
        result => this.processResponse(result),
        error => "Error occurred while getting data"
      );*/

    this.treeService.getChildObjects(
        'http://localhost:8081/SpringRestHibernateExample/laborval/fetchRootNodes', this.userVO)
    .pipe()    
    .subscribe(result => {
      this.processResponse(result)
     }),
    (error:any) => {console.log(error); return [];};
   }

   ngOnDestroy(){
     //this.expandedNode = {};
     //this.destroyed$.next(true);
     //this.destroyed$.complete();
   }

  processResponse(result:any[]){
    this.nodes = result;
    this.spinner.hide();
    console.log(this.nodes);
  }

  collapseTree(){
    console.log("in collapse tree");
    //this.nodes = [].concat(this.nodes);
    this.collapseTreeOnClear = true;
  }

  processChildResponse(data){
    this.isTypeUpdated = false;
    console.log("Selected node:",this.expandedNode);
    this.nodes.filter(
      node => {
        if(node.children == null){
          node.children = [];
        }
        if(node.name === this.expandedNode.data.name && 
          node.level === this.expandedNode.data.level &&
          node.type === this.expandedNode.data.type){
            console.log("right aal re first level");
            node.children = data;
        }else if(this.expandedNode.data.level != 0){
          console.log("elese");
          node.children.filter(
            child_1 => { 
              if(child_1.children === null){
                child_1.children = [];
              }           
              if(child_1.name === this.expandedNode.data.name && 
                child_1.level === this.expandedNode.data.level &&
                child_1.type === this.expandedNode.data.type){
                 console.log("right aal re second level");
                 child_1.children = data;
             }else{
              child_1.children.filter(
                child_2 => {
                  if(child_2.children == null){
                    child_2.children = [];
                  }
                  if(child_2.name === this.expandedNode.data.name && 
                    child_2.level === this.expandedNode.data.level &&
                    child_2.type === this.expandedNode.data.type){
                     console.log("right aal re third level");
                     child_2.children = data;
                  }else{
                    child_2.children.filter(
                      child_3 => {
                        if(child_3.children == null){
                          child_3.children = [];
                        }
                        if(child_3.name === this.expandedNode.data.name && 
                          child_3.level === this.expandedNode.data.level &&
                          child_3.type === this.expandedNode.data.type){
                           console.log("right aal re fourth level");
                           child_3.children = data;
                        }else{
                          child_3.children.filter(
                            child_4 => {
                              if(child_4.children == null){
                                child_4.children = [];
                               }
                              if(child_4.name === this.expandedNode.data.name && 
                                child_4.level === this.expandedNode.data.level &&
                                child_4.type === this.expandedNode.data.type){
                                 console.log("right aal re fifth level");
                                 child_4.children = data;
                              }else{
                                child_4.children.filter(
                                  child_5 => {
                                    if(child_5.children == null){
                                      child_5.children = [];
                                     }
                                    if(child_5.name === this.expandedNode.data.name && 
                                      child_5.level === this.expandedNode.data.level &&
                                      child_5.type === this.expandedNode.data.type){
                                       console.log("right aal re sixth level");
                                       child_5.children = data;
                                    }else{
                                      child_5.children.filter(
                                        child_6 => {
                                          if(child_6.children == null){
                                            child_6.children = [];
                                           }
                                          if(child_6.name === this.expandedNode.data.name && 
                                            child_6.level === this.expandedNode.data.level &&
                                            child_6.type === this.expandedNode.data.type){
                                             console.log("right aal re seventh level");
                                             child_6.children = data;
                                          }else{
                                            child_6.children.filter(
                                              child_7 => {
                                                if(child_7.children == null){
                                                  child_7.children = [];
                                                 }
                                                if(child_7.name === this.expandedNode.data.name && 
                                                  child_7.level === this.expandedNode.data.level &&
                                                  child_7.type === this.expandedNode.data.type){
                                                   console.log("right aal re eighth level");
                                                   child_7.children = data;
                                                }
                                              })
                                          }
                                        })
                                    }
                                  })
                              }
                            })
                        }
                      })
                  }
                })  
             }
            })
        }
      });  
      console.log("llo2",this.nodes);
      this.nodes = [].concat(this.nodes);
      this.treeModel.update();
      return data;
  }  
  
  treeNodeSelected(event) {
    if(event.isExpanded == true){
      console.log("Hiiiiiiiiiiiiiiiiooooo",event);
      if(this.expandedNode != null && (this.expandedNode.data.type > event.node.data.type)){
        console.log("Type updated : type",this.expandedNode.data.type);
             this.isTypeUpdated = true;
      }
      this.expandedNode = event.node;
      console.log("Hi8i",this.expandedNode);
      console.log("isTypeUpdated",this.isTypeUpdated);
      this.getChildren(event.node);
      this.renderer.removeClass(this.objectDomElement.nativeElement, 'fa-folder');
      this.renderer.addClass(this.objectDomElement.nativeElement, 'fa-folder-open');
    }else{
      this.renderer.removeClass(this.objectDomElement.nativeElement, 'fa-folder-open');
      this.renderer.addClass(this.objectDomElement.nativeElement, 'fa-folder');
    }
  }

  treeNodeDoubleClick(node){
    
    console.log("tree node double clicked!!!",node);
    let validWorkProcesses = [];
    this.selectedNode = node.data;
    this.getTableInfoToPopulate();
    this.commonService.passData({option: 'selectedData', value:this.expandedNode});
    
    
    //this.myTree.treeModel.collapseAll();
  }

  getTableInfoToPopulate():void{
    let vaildObjectDetails = [];
    this.spinner.show();
    this.fetchMostValidWPAttributesVO = {
    
      userVO: {
        userID:'eoiread',
        language:'EN',
        model:'All',
        variant:'All',
        rearAxel1Type:'',
        motorType:'',
        transmissionType:'',
        catalog:'LABORVALCAT',
        unit:'TU',
        objectCode1:'',
        objectCode2:'',
        objectCode3:'',
        dmsOrder:''
      },
      workProcessVO: {
        rANGE:null,
        lBRVARIANT:null,
        oBJCD1:this.selectedNode.code+" "+this.selectedNode.name,
        oBJCD2:null,
        oBJCD3:null,
        vERSION:null,
        lOCATION:null,
        iNSTALLCON:null,
        aCTIVITY:null,
        vKORG:null,
        lBRVALUE:null,
        lABVAL:null,
        pRCSTAT:null,
        tEXT:null,
        tXTTYPE:null,
        nOOFINCLUDEDWP:0,
        nOOFNOTINCLUDEDWP:0,
        pOSITIONTYPE:null,
        jOBTYPE:null
      },
      nodeVO: {
        type:this.selectedNode.type,
        code:this.selectedNode.code,
        name:this.selectedNode.name,
        toolTipText:null,
        level:this.selectedNode.level,
        hasChildren:null,
        childNodesHaveBeenFetched: false,
        children:[]
      },
      paginationVO: {
        numberOfPages:0,
        currentPage:0,
        pageSize:50,
        rows:[],
        totalRecords:0,
        isNextEnabled:false,
        isPreviousEnabled:false,
        isFirstEnabled:false,
        isLastEnabled:false,
        startRowNum:0,
        endRowNum:0,
      }
     }
      this.treeService.getChildObjects(
          'http://localhost:8081/SpringRestHibernateExample/laborval/fetchWPList', this.fetchMostValidWPAttributesVO)
      .pipe()    
      .subscribe(result => {
        //console.log("Result is:",result.rows);
        //vaildObjectDetails = result.rows;
        this.commonService.notifyOther({option: 'onSelect', value: result.rows});
       }),
      (error:any) => {console.log(error); return [];};
      //this.spinner.hide();
  }

  options = {
    actionMapping,
    useVirtualScroll: true
  }
  getChildren (node: TreeNode){
    if(this.expandedNode.data.level === 0){
       this.expandedNode.data.level += 1;
    }
    this.fetchChildVO = {
    
      userVO: {
        userID:'eoiread',
        language:'EN',
        model:'All',
        variant:'All',
        rearAxel1Type:'',
        motorType:'',
        transmissionType:'',
        catalog:'LABORVALCAT',
        unit:'TU',
        objectCode1:'',
        objectCode2:'',
        objectCode3:'',
        dmsOrder:''
      },
      workProcessVO: {
        rANGE:null,
        lBRVARIANT:null,
        oBJCD1:null,
        oBJCD2:null,
        oBJCD3:null,
        vERSION:null,
        lOCATION:null,
        iNSTALLCON:null,
        aCTIVITY:null,
        vKORG:null,
        lBRVALUE:null,
        lABVAL:null,
        pRCSTAT:null,
        tEXT:null,
        tXTTYPE:null,
        nOOFINCLUDEDWP:0,
        nOOFNOTINCLUDEDWP:0,
        pOSITIONTYPE:null,
        jOBTYPE:null
      },
      nodeVO: {
        type:this.expandedNode.data.type,
        code:this.expandedNode.data.code,
        name:this.expandedNode.data.name,
        toolTipText:null,
        level:this.isTypeUpdated === false?this.expandedNode.data.level:this.expandedNode.data.level+1,
        hasChildren:null,
        childNodesHaveBeenFetched: false,
        children:[]
      }
     }

      return this.treeService.getChildObjects(
          'http://localhost:8081/SpringRestHibernateExample/laborval/fetchChildNodes', this.fetchChildVO)
      .subscribe(result => {
        this.processChildResponse(result);
      }),
      (error:any) => {console.log(error); return [];};
  }
  handleError(error: any): void {
    console.log(error)
  }
}