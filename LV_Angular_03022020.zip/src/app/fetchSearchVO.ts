import { UserVO } from './userVO';
import { WorkProcessVO } from './workProcessVO';
import { NodeVO } from './nodeVO';
import { PaginationVO } from './paginationVO';


export class FetchSearchVO{

    userVO:UserVO;
    paginationVO:PaginationVO;
    searchText:string;
    code:string;
    constructor(){
        
    }
}